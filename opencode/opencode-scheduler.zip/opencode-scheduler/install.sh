#!/bin/bash
# =============================================================================
# install.sh — OpenCode Scheduler 一键安装脚本
#
# 用法:
#   chmod +x install.sh && ./install.sh
#
# 将会:
#   1. 将脚本复制到 ~/.local/bin/
#   2. 将示例配置复制到 ~/.config/opencode/
#   3. 将 nightly 命令复制到 ~/.config/opencode/commands/
#   4. 安装 systemd user service + timer
#   5. 启动 opencode-server 和定时任务
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info()    { echo -e "${GREEN}[✓]${NC} $*"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*"; }
error()   { echo -e "${RED}[✗]${NC} $*"; exit 1; }
section() { echo -e "\n${YELLOW}── $* ──${NC}"; }

# ── 检查依赖 ──────────────────────────────────────────────────────────────────
section "检查依赖"
command -v opencode &>/dev/null || error "未找到 opencode，请先安装: npm install -g opencode"
command -v jq       &>/dev/null || error "未找到 jq，请先安装: sudo apt install jq"
command -v systemctl &>/dev/null || warn "未检测到 systemd，将跳过 service/timer 安装，仅使用 cron"
info "依赖检查通过"
info "opencode 路径: $(which opencode)"

# ── 安装调度脚本 ───────────────────────────────────────────────────────────────
section "安装调度脚本"
mkdir -p "$HOME/.local/bin"
cp "$SCRIPT_DIR/opencode-scheduler.sh" "$HOME/.local/bin/opencode-scheduler.sh"
chmod +x "$HOME/.local/bin/opencode-scheduler.sh"
info "脚本已安装到: ~/.local/bin/opencode-scheduler.sh"

# 确保 ~/.local/bin 在 PATH 中
if ! echo "$PATH" | grep -q "$HOME/.local/bin"; then
    warn "~/.local/bin 不在 PATH 中，请将以下行加入 ~/.bashrc 或 ~/.zshrc:"
    echo '  export PATH="$HOME/.local/bin:$PATH"'
fi

# ── 安装配置文件 ───────────────────────────────────────────────────────────────
section "安装配置文件"
mkdir -p "$HOME/.config/opencode"

if [[ -f "$HOME/.config/opencode/scheduled-tasks.json" ]]; then
    warn "配置文件已存在，跳过覆盖: ~/.config/opencode/scheduled-tasks.json"
    warn "如需重置，手动执行: cp $SCRIPT_DIR/scheduled-tasks.example.jsonc ~/.config/opencode/scheduled-tasks.json"
else
    # 去掉注释，写入标准 JSON
    sed 's|//.*||g' "$SCRIPT_DIR/scheduled-tasks.example.jsonc" | \
        python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(json.dumps(d, ensure_ascii=False, indent=2))" \
        > "$HOME/.config/opencode/scheduled-tasks.json" 2>/dev/null || \
        cp "$SCRIPT_DIR/scheduled-tasks.example.jsonc" "$HOME/.config/opencode/scheduled-tasks.json"
    info "示例配置已安装到: ~/.config/opencode/scheduled-tasks.json"
    warn "!! 请编辑该文件，填入你的项目路径和任务描述 !!"
fi

# ── 安装 nightly 自定义命令 ────────────────────────────────────────────────────
section "安装 opencode 自定义命令"
mkdir -p "$HOME/.config/opencode/commands"

if [[ -f "$HOME/.config/opencode/commands/nightly.md" ]]; then
    warn "nightly 命令已存在，跳过: ~/.config/opencode/commands/nightly.md"
else
    cp "$SCRIPT_DIR/commands/nightly.md" "$HOME/.config/opencode/commands/nightly.md"
    info "nightly 命令已安装到: ~/.config/opencode/commands/nightly.md"
fi

# ── 安装 systemd（如果可用）────────────────────────────────────────────────────
if command -v systemctl &>/dev/null; then
    section "安装 systemd service & timer"
    SYSTEMD_DIR="$HOME/.config/systemd/user"
    mkdir -p "$SYSTEMD_DIR"

    # 替换路径占位符
    OPENCODE_BIN="$(which opencode)"
    sed "s|/usr/local/bin/opencode|$OPENCODE_BIN|g" \
        "$SCRIPT_DIR/systemd/opencode-server.service" > "$SYSTEMD_DIR/opencode-server.service"

    cp "$SCRIPT_DIR/systemd/opencode-nightly.service" "$SYSTEMD_DIR/opencode-nightly.service"
    cp "$SCRIPT_DIR/systemd/opencode-nightly.timer"   "$SYSTEMD_DIR/opencode-nightly.timer"

    systemctl --user daemon-reload

    # 启动 opencode-server 常驻服务
    systemctl --user enable --now opencode-server.service
    info "opencode-server 已启动（常驻后台）"

    # 启动定时器
    systemctl --user enable --now opencode-nightly.timer
    NEXT_RUN=$(systemctl --user show opencode-nightly.timer --property=NextElapseUSecRealtime --value 2>/dev/null || echo "未知")
    info "定时任务已启用，每天凌晨 02:00 自动执行"
    info "下次执行时间: $(systemctl --user list-timers opencode-nightly.timer --no-pager 2>/dev/null | grep opencode | awk '{print $1, $2}' || echo '见 systemctl --user list-timers')"

else
    # ── 回退到 cron ────────────────────────────────────────────────────────────
    section "安装 cron 定时任务（systemd 不可用）"
    CRON_JOB="0 2 * * * $HOME/.local/bin/opencode-scheduler.sh >> $HOME/.local/share/opencode-scheduler/cron.log 2>&1"

    if crontab -l 2>/dev/null | grep -q "opencode-scheduler"; then
        warn "cron 任务已存在，跳过"
    else
        (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
        info "cron 任务已添加：每天凌晨 02:00 执行"
    fi
fi

# ── 完成 ───────────────────────────────────────────────────────────────────────
section "安装完成"
echo ""
echo "  📄 任务配置文件:  ~/.config/opencode/scheduled-tasks.json"
echo "  🔧 调度脚本:       ~/.local/bin/opencode-scheduler.sh"
echo "  📁 日志目录:       ~/.local/share/opencode-scheduler/logs/"
echo ""
echo -e "${YELLOW}下一步：${NC}"
echo "  1. 编辑配置文件，填入你的项目路径:"
echo "     nano ~/.config/opencode/scheduled-tasks.json"
echo ""
echo "  2. 将任务的 \"enabled\" 改为 true"
echo ""
echo "  3. 先 dry-run 验证:"
echo "     opencode-scheduler.sh --dry-run"
echo ""
echo "  4. 手动运行一次完整测试:"
echo "     opencode-scheduler.sh"
echo ""
