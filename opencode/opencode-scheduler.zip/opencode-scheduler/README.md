# OpenCode Scheduler

在 Linux 服务器上为 [opencode](https://opencode.ai) 添加**定时自动化任务**能力。  
每天凌晨指定时间，自动用自然语言驱动 AI 对多个项目执行测试、修复、文档生成等任务。

---

## 目录结构

```
opencode-scheduler/
├── install.sh                        ← 一键安装脚本（推荐）
├── opencode-scheduler.sh             ← 核心调度脚本
├── scheduled-tasks.example.jsonc     ← 任务配置示例
├── commands/
│   └── nightly.md                    ← opencode 自定义命令（可按需修改）
├── systemd/
│   ├── opencode-server.service       ← opencode 后台常驻服务
│   ├── opencode-nightly.service      ← 夜间任务一次性服务
│   └── opencode-nightly.timer        ← 定时触发器（每天凌晨 02:00）
└── README.md                         ← 本文档
```

---

## 前提条件

在 Linux 机器上确保已安装：

```bash
# 1. opencode
npm install -g opencode

# 2. jq（用于解析 JSON 配置）
sudo apt install jq        # Ubuntu/Debian
sudo yum install jq        # CentOS/RHEL
brew install jq            # macOS

# 3. 验证安装
opencode --version
jq --version
```

> opencode 需要配置 API Key（Anthropic / OpenAI 等），  
> 参考官方文档：https://opencode.ai/docs/providers

---

## 快速安装

### 方法一：一键安装（推荐）

```bash
# 将此目录传到服务器（scp / git clone / rsync 均可）
scp -r opencode-scheduler/ user@your-server:~/

# SSH 进入服务器
ssh user@your-server

# 执行安装脚本
cd ~/opencode-scheduler
chmod +x install.sh
./install.sh
```

### 方法二：手动安装

```bash
# 1. 复制调度脚本
mkdir -p ~/.local/bin
cp opencode-scheduler.sh ~/.local/bin/
chmod +x ~/.local/bin/opencode-scheduler.sh

# 确保 PATH 包含 ~/.local/bin
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# 2. 复制示例配置
mkdir -p ~/.config/opencode
cp scheduled-tasks.example.jsonc ~/.config/opencode/scheduled-tasks.json

# 3. 复制 nightly 自定义命令
mkdir -p ~/.config/opencode/commands
cp commands/nightly.md ~/.config/opencode/commands/nightly.md

# 4. 安装 systemd（见下方）
```

---

## 配置任务

编辑 `~/.config/opencode/scheduled-tasks.json`：

```json
{
  "tasks": [
    {
      "name": "my-project-test",
      "project": "/home/leoris/projects/my-project",
      "prompt": "运行测试，分析失败原因并修复",
      "model": "anthropic/claude-sonnet-4-5",
      "timeout": 1800,
      "enabled": true
    }
  ]
}
```

### 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `name` | ✅ | 任务唯一名称，用于日志区分 |
| `project` | ✅ | 项目绝对路径，opencode 在此目录下执行 |
| `prompt` | 二选一 | 发给 AI 的自然语言任务描述 |
| `command` | 二选一 | opencode 自定义命令名（对应 `commands/*.md`） |
| `model` | | 模型名，如 `anthropic/claude-sonnet-4-5`，默认 `auto` |
| `timeout` | | 单任务超时秒数，0 表示不限，默认 3600 |
| `enabled` | | `false` 可临时跳过此任务 |

### 常用 prompt 示例

```json
// 修复测试
"prompt": "运行所有单元测试，分析失败用例，尝试修复，修复后再次运行确认"

// 修复 lint
"prompt": "运行 ESLint / Pylint，自动修复所有可修复的问题，列出无法修复的问题"

// 补充文档
"prompt": "检查 src 目录下所有导出的函数和类，为缺少注释的部分补充 JSDoc / docstring"

// 依赖检查
"prompt": "检查是否有过时的依赖包，列出有安全漏洞的包并尝试升级"

// 使用自定义命令（更复杂的多步骤任务）
"command": "nightly"
```

---

## systemd 定时任务配置

### 安装 service & timer

```bash
SYSTEMD_DIR="$HOME/.config/systemd/user"
mkdir -p "$SYSTEMD_DIR"

# 复制文件（修改 opencode 路径）
OPENCODE_BIN=$(which opencode)
sed "s|/usr/local/bin/opencode|$OPENCODE_BIN|g" \
    systemd/opencode-server.service > "$SYSTEMD_DIR/opencode-server.service"

cp systemd/opencode-nightly.service "$SYSTEMD_DIR/"
cp systemd/opencode-nightly.timer   "$SYSTEMD_DIR/"

systemctl --user daemon-reload

# 启动 opencode 后台服务（常驻，避免每次冷启动）
systemctl --user enable --now opencode-server.service

# 启动定时器
systemctl --user enable --now opencode-nightly.timer
```

### 修改执行时间

编辑 `~/.config/systemd/user/opencode-nightly.timer`：

```ini
[Timer]
# 每天凌晨 02:00（按需修改）
OnCalendar=*-*-* 02:00:00
```

常用时间格式：

```
*-*-* 02:00:00          每天凌晨 02:00
Mon *-*-* 03:00:00      每周一凌晨 03:00
*-*-1 00:00:00          每月 1 日零点
```

修改后重新加载：

```bash
systemctl --user daemon-reload
systemctl --user restart opencode-nightly.timer
```

### 查看状态

```bash
# 查看定时器下次触发时间
systemctl --user list-timers opencode-nightly.timer

# 查看最近的执行日志
journalctl --user -u opencode-nightly.service -n 50

# 查看 opencode-server 状态
systemctl --user status opencode-server.service
```

---

## 备用方案：cron（不使用 systemd）

若系统没有 systemd，使用 cron：

```bash
crontab -e
```

添加：

```cron
# 每天凌晨 02:00
0 2 * * * ~/.local/bin/opencode-scheduler.sh >> ~/.local/share/opencode-scheduler/cron.log 2>&1
```

---

## 手动操作

```bash
# 查看将要执行的任务（不实际运行）
opencode-scheduler.sh --dry-run

# 立即运行所有任务
opencode-scheduler.sh

# 只运行某个任务
opencode-scheduler.sh --task my-project-test

# 指定配置文件
opencode-scheduler.sh --config /path/to/my-config.json
```

---

## 日志

日志保存在 `~/.local/share/opencode-scheduler/logs/`，文件名格式：

```
20260328_020012.log
```

自动清理 30 天前的旧日志。

```bash
# 查看最新日志
ls -lt ~/.local/share/opencode-scheduler/logs/ | head -5

# 实时跟踪（手动执行时）
tail -f ~/.local/share/opencode-scheduler/logs/$(ls -t ~/.local/share/opencode-scheduler/logs/ | head -1)
```

---

## 自定义 nightly 命令

`~/.config/opencode/commands/nightly.md` 是一个多步骤任务模板，  
你可以按项目需求修改步骤内容。参考格式：

```markdown
---
description: 夜间全量检查
agent: build
---

请依次执行：

## 步骤 1
执行 `!npm test`，修复失败用例...

## 步骤 2
...
```

在配置中通过 `"command": "nightly"` 调用，而不是写 `prompt`。

---

## 常见问题

**Q: opencode 命令找不到？**  
A: npm 全局安装路径可能不在 PATH 中。运行 `which opencode` 获取完整路径，  
然后在 service 文件中直接写绝对路径，或在 `.bashrc` 中添加 PATH。

**Q: API Key 配置在哪里？**  
A: opencode 的 API Key 配置在 `~/.config/opencode/` 下，  
参考：https://opencode.ai/docs/providers

**Q: 任务执行超时？**  
A: 增大配置中的 `timeout` 值，或在 `opencode-nightly.service` 中  
增大 `TimeoutStartSec`。

**Q: 机器重启后定时任务还在吗？**  
A: `enable` 过的 systemd timer 重启后自动恢复。  
cron 任务本身就是持久的，重启后自动恢复。

**Q: 想在执行前先 git pull 更新代码？**  
A: 在 `prompt` 中加入：  
`"prompt": "先执行 git pull 更新代码，然后运行测试..."`  
或在 shell 脚本中在 `opencode run` 前加 `git pull`。
