#!/bin/bash
# =============================================================================
# opencode-scheduler.sh
# OpenCode 夜间多项目自动任务调度器
#
# 用法:
#   ./opencode-scheduler.sh [--config path] [--dry-run] [--task name]
#
# 依赖: opencode, jq
# =============================================================================
set -euo pipefail

# ── 默认配置 ─────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${OPENCODE_SCHEDULER_CONFIG:-$HOME/.config/opencode/scheduled-tasks.json}"
LOG_DIR="${OPENCODE_SCHEDULER_LOG_DIR:-$HOME/.local/share/opencode-scheduler/logs}"
ATTACH_URL="${OPENCODE_ATTACH:-}"          # 若设置则连接已运行的 opencode serve
DRY_RUN=false
FILTER_TASK=""

# ── 参数解析 ─────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --config)   CONFIG_FILE="$2"; shift 2 ;;
        --dry-run)  DRY_RUN=true; shift ;;
        --task)     FILTER_TASK="$2"; shift 2 ;;
        --help|-h)
            echo "用法: $0 [--config FILE] [--dry-run] [--task TASK_NAME]"
            echo ""
            echo "选项:"
            echo "  --config FILE    指定配置文件（默认 ~/.config/opencode/scheduled-tasks.json）"
            echo "  --dry-run        只打印将要执行的任务，不实际运行"
            echo "  --task NAME      只执行名称匹配的任务（支持模糊匹配）"
            exit 0
            ;;
        *) echo "[ERROR] 未知参数: $1"; exit 1 ;;
    esac
done

# ── 检查依赖 ─────────────────────────────────────────────────────────────────
check_deps() {
    local missing=()
    command -v opencode &>/dev/null || missing+=("opencode")
    command -v jq       &>/dev/null || missing+=("jq")
    if [[ ${#missing[@]} -gt 0 ]]; then
        echo "[ERROR] 缺少依赖: ${missing[*]}"
        echo "  安装 opencode: npm install -g opencode"
        echo "  安装 jq:       sudo apt install jq  # 或 brew install jq"
        exit 1
    fi
}

# ── 日志工具 ─────────────────────────────────────────────────────────────────
LOG_FILE=""
log() {
    local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $*"
    echo "$msg"
    [[ -n "$LOG_FILE" ]] && echo "$msg" >> "$LOG_FILE"
}

log_section() {
    local sep="$(printf '─%.0s' {1..60})"
    log "$sep"
    log "  $*"
    log "$sep"
}

# ── 初始化日志文件 ────────────────────────────────────────────────────────────
init_log() {
    mkdir -p "$LOG_DIR"
    LOG_FILE="$LOG_DIR/$(date '+%Y%m%d_%H%M%S').log"
    # 保留最近 30 天日志，删除旧日志
    find "$LOG_DIR" -name "*.log" -mtime +30 -delete 2>/dev/null || true
}

# ── 执行单个任务 ──────────────────────────────────────────────────────────────
run_task() {
    local name="$1"
    local project="$2"
    local prompt="$3"
    local model="$4"
    local command_name="$5"   # 可选：opencode 自定义命令名
    local timeout_sec="$6"    # 可选：超时秒数

    log_section "任务: $name"
    log "项目路径: $project"
    log "模型: $model"

    if [[ ! -d "$project" ]]; then
        log "[SKIP] 项目目录不存在: $project"
        return 1
    fi

    local start_ts=$SECONDS
    local exit_code=0

    if [[ "$DRY_RUN" == "true" ]]; then
        log "[DRY-RUN] cd $project"
        if [[ -n "$command_name" ]]; then
            log "[DRY-RUN] opencode run --command $command_name --model $model"
        else
            log "[DRY-RUN] opencode run --model $model \"${prompt:0:80}...\""
        fi
        return 0
    fi

    # 构建 opencode 命令
    local oc_cmd="opencode run"
    [[ -n "$ATTACH_URL" ]] && oc_cmd="$oc_cmd --attach $ATTACH_URL"
    [[ -n "$model" ]]       && oc_cmd="$oc_cmd --model $model"

    if [[ -n "$command_name" ]]; then
        oc_cmd="$oc_cmd --command $command_name"
    else
        oc_cmd="$oc_cmd \"$prompt\""
    fi

    # 执行（带超时）
    (
        cd "$project"
        if [[ -n "$timeout_sec" && "$timeout_sec" -gt 0 ]]; then
            timeout "$timeout_sec" bash -c "$oc_cmd" 2>&1
        else
            bash -c "$oc_cmd" 2>&1
        fi
    ) | tee -a "$LOG_FILE" || exit_code=$?

    local duration=$(( SECONDS - start_ts ))

    if [[ $exit_code -eq 0 ]]; then
        log "✅ 任务完成 (${duration}s)"
    elif [[ $exit_code -eq 124 ]]; then
        log "⏱ 任务超时 (>${timeout_sec}s)"
        return 1
    else
        log "❌ 任务失败，exit=$exit_code (${duration}s)"
        return 1
    fi
}

# ── 主流程 ────────────────────────────────────────────────────────────────────
main() {
    check_deps

    # 检查配置文件
    if [[ ! -f "$CONFIG_FILE" ]]; then
        echo "[ERROR] 配置文件不存在: $CONFIG_FILE"
        echo ""
        echo "请先创建配置文件，可参考示例："
        echo "  cp $(dirname "$CONFIG_FILE")/scheduled-tasks.example.json $CONFIG_FILE"
        echo ""
        echo "或运行安装脚本自动初始化：./install.sh"
        exit 1
    fi

    init_log

    log_section "OpenCode Scheduler 启动"
    log "配置文件: $CONFIG_FILE"
    log "日志文件: $LOG_FILE"
    [[ -n "$ATTACH_URL" ]] && log "连接服务器: $ATTACH_URL"
    [[ "$DRY_RUN" == "true" ]] && log "模式: DRY-RUN（不实际执行）"

    # 读取并过滤任务
    local tasks
    tasks=$(jq -c '.tasks[] | select(.enabled == true)' "$CONFIG_FILE")

    if [[ -z "$tasks" ]]; then
        log "[WARN] 没有启用的任务（enabled: true），请检查配置文件"
        exit 0
    fi

    local total=0 passed=0 failed=0
    local failed_tasks=()

    while IFS= read -r task; do
        local name project prompt model command_name timeout_sec
        name=$(echo "$task"         | jq -r '.name')
        project=$(echo "$task"      | jq -r '.project')
        prompt=$(echo "$task"       | jq -r '.prompt // ""')
        model=$(echo "$task"        | jq -r '.model // "auto"')
        command_name=$(echo "$task" | jq -r '.command // ""')
        timeout_sec=$(echo "$task"  | jq -r '.timeout // 0')

        # 过滤特定任务
        if [[ -n "$FILTER_TASK" && "$name" != *"$FILTER_TASK"* ]]; then
            continue
        fi

        total=$(( total + 1 ))

        if run_task "$name" "$project" "$prompt" "$model" "$command_name" "$timeout_sec"; then
            passed=$(( passed + 1 ))
        else
            failed=$(( failed + 1 ))
            failed_tasks+=("$name")
        fi

    done <<< "$tasks"

    # 汇总
    log_section "执行完毕"
    log "总计: $total  ✅ 通过: $passed  ❌ 失败: $failed"
    if [[ ${#failed_tasks[@]} -gt 0 ]]; then
        log "失败任务: ${failed_tasks[*]}"
    fi
    log "完整日志: $LOG_FILE"

    [[ $failed -gt 0 ]] && exit 1
    exit 0
}

main "$@"
