#!/bin/bash
# qmd 索引重建脚本
# 用法: bash qmd-reindex.sh [WIKI_ROOT]

WIKI_ROOT="${1:-.}"
cd "$WIKI_ROOT"

echo "重建 qmd 索引..."

if ! command -v qmd &> /dev/null; then
    echo "⚠ qmd 未安装，跳过索引重建"
    echo "安装后请手动执行: qmd add wiki/ && qmd status"
    exit 1
fi

qmd add wiki/ 2>/dev/null
qmd status
echo "✅ qmd 索引已更新"
