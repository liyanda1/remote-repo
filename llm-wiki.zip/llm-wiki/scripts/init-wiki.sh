#!/bin/bash
# LLM Wiki 知识库初始化脚本
# 用法: bash init-wiki.sh <WIKI_ROOT> [主题名称]

set -e

WIKI_ROOT="${1:-$HOME/knowledge-base}"
TOPIC="${2:-我的知识库}"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# 颜色输出
red()    { echo -e "\033[31m$1\033[0m"; }
green()  { echo -e "\033[32m$1\033[0m"; }
yellow() { echo -e "\033[33m$1\033[0m"; }
blue()   { echo -e "\033[34m$1\033[0m"; }

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
blue "  LLM Wiki 知识库初始化"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  路径: $WIKI_ROOT"
echo "  主题: $TOPIC"
echo ""

# 1. 创建目录结构
green "▶ 创建目录结构..."
mkdir -p "$WIKI_ROOT/raw/articles"
mkdir -p "$WIKI_ROOT/raw/clippings"
mkdir -p "$WIKI_ROOT/raw/images"
mkdir -p "$WIKI_ROOT/raw/pdfs"
mkdir -p "$WIKI_ROOT/raw/notes"
mkdir -p "$WIKI_ROOT/raw/personal"
mkdir -p "$WIKI_ROOT/wiki/sources"
mkdir -p "$WIKI_ROOT/wiki/concepts"
mkdir -p "$WIKI_ROOT/wiki/entities"
mkdir -p "$WIKI_ROOT/wiki/synthesis"
mkdir -p "$WIKI_ROOT/wiki/templates"
mkdir -p "$WIKI_ROOT/outputs"
mkdir -p "$WIKI_ROOT/scripts"
echo "  ✅ 目录结构已创建"

# 2. 创建系统文件
green "▶ 创建系统文件..."

# wiki/index.md
cat > "$WIKI_ROOT/wiki/index.md" << 'EOF'
---
type: system-index
graph-excluded: true
---

EOF
cat >> "$WIKI_ROOT/wiki/index.md" << EOF
# $TOPIC — 知识库索引

## Sources（按日期倒序）

（暂无）

## Concepts

（暂无）

## Entities

（暂无）

## Recent Synthesis

（暂无）

## Outputs

（暂无）
EOF

# wiki/log.md
cat > "$WIKI_ROOT/wiki/log.md" << 'EOF'
---
type: system-log
graph-excluded: true
---

# 操作日志

EOF

# wiki/overview.md
cat > "$WIKI_ROOT/wiki/overview.md" << 'EOF'
---
type: system-overview
graph-excluded: true
---

EOF
cat >> "$WIKI_ROOT/wiki/overview.md" << EOF
# $TOPIC — 知识库总览

## Knowledge Base Health Dashboard

| 指标 | 值 |
|---|---|
| 总来源数 | 0 |
| 高置信度概念数 | 0 |
| 开放问题数 | 0 |
| Stale 页面数 | 0 |
| 孤立概念数 | 0 |

## 最近更新

（暂无）
EOF

# wiki/QUESTIONS.md
cat > "$WIKI_ROOT/wiki/QUESTIONS.md" << 'EOF'
---
type: system-questions
graph-excluded: true
---

# 开放问题

## Open Questions

（暂无）

## Resolved Questions

（暂无）
EOF

echo "  ✅ 系统文件已创建（index.md, log.md, overview.md, QUESTIONS.md）"

# 3. 复制模板文件
green "▶ 复制页面模板..."
if [ -d "$SKILL_DIR/templates" ]; then
    cp "$SKILL_DIR/templates/"*.md "$WIKI_ROOT/wiki/templates/"
    echo "  ✅ 模板文件已复制: $(ls "$WIKI_ROOT/wiki/templates/" | wc -l) 个"
else
    yellow "  ⚠ 模板目录不存在: $SKILL_DIR/templates"
fi

# 4. 复制 lint.py 和 qmd-reindex.sh
green "▶ 复制脚本文件..."
if [ -f "$SKILL_DIR/scripts/lint.py" ]; then
    cp "$SKILL_DIR/scripts/lint.py" "$WIKI_ROOT/scripts/"
    echo "  ✅ scripts/lint.py 已复制"
else
    yellow "  ⚠ lint.py 不存在: $SKILL_DIR/scripts/lint.py"
fi
if [ -f "$SKILL_DIR/scripts/qmd-reindex.sh" ]; then
    cp "$SKILL_DIR/scripts/qmd-reindex.sh" "$WIKI_ROOT/scripts/"
    chmod +x "$WIKI_ROOT/scripts/qmd-reindex.sh" 2>/dev/null
    echo "  ✅ scripts/qmd-reindex.sh 已复制"
else
    yellow "  ⚠ qmd-reindex.sh 不存在: $SKILL_DIR/scripts/qmd-reindex.sh"
fi

# 5. 创建 CLAUDE.md（行为契约 — 完整版）
green "▶ 创建 CLAUDE.md 行为契约..."
cat > "$WIKI_ROOT/CLAUDE.md" << 'CONTRACT'
# CLAUDE.md — LLM Wiki 行为契约

## 系统概述

三层架构：
- **Raw 原始层**（raw/）：人类拥有，LLM 只读，绝不修改
- **Wiki 编译层**（wiki/）：LLM 完全拥有，人类只读浏览
- **Outputs 层**（outputs/）：LLM 生成，输出必须持久化

核心原则：
1. Raw 层不可变 — 原始来源绝对不修改
2. Wiki 层 LLM 完全拥有 — 你只浏览，不编辑
3. 输出必须持久化 — 答案写入 outputs/，不消失在对话中
4. 矛盾必须显式标注 — 来源分歧明确记录
5. 每次操作都记日志 — 所有操作写入 wiki/log.md

## INGEST 操作规范

触发词：ingest、摄入、处理这个

来源类型判断（优先级由高到低）：
1. frontmatter 含 type: personal-writing → 走「个人写作」流程
2. 文件路径包含 raw/personal/ → 走「个人写作」流程
3. frontmatter 含 type: pdf-reference → 走「PDF 参考」流程
4. 其他 → 走「外部来源」标准流程

缺少 frontmatter 时的处理：
- 从文件第一个 # 标题提取 title；若无标题则从文件名推断
- source 字段留空，在 wiki/sources/<slug>.md 中标注「来源未知」
- date 使用文件系统修改时间
- 不中断 INGEST，但在 log.md 记录「警告：来源文件缺少标准 frontmatter」

外部来源标准流程（12 步）：
1. 读取原始来源（raw/ 中的文件，只读）
2. 计算 SHA-256 哈希（Python hashlib）
3. 与用户确认核心要点（逐一摄入，保持参与感）
4. 生成 slug（小写英文，用连字符）
5. 创建 wiki/sources/<slug>.md，写入 raw_file、raw_sha256、last_verified；超过 2 年标注 possibly_outdated；canonical_source 译文检测：若来源是译文/转载，填入 canonical_source 字段，遍历 wiki/sources/*.md 检查是否有相同 canonical_source → 若匹配则标记为同源译文，不重复提取概念
6. 概念名称对齐检查：映射为英文 slug → 查 wiki/concepts/ 是否已存在 → 同时检查所有已有 concept 页的 aliases 字段 → 匹配则更新，不匹配才新建
7. 为每个概念：已存在则更新（追加来源、Evolution Log、source_count、confidence、last_reviewed），不存在则新建（aliases 填入中英文名）
8. 为每个实体：同上逻辑
9. 更新 wiki/index.md：将来源从 Unprocessed 移动到 Processed
10. 读取 wiki/QUESTIONS.md，检查是否能回答开放问题；若能则提示用户执行 QUERY
11. 在 wiki/log.md 末尾追加日志
12. 执行 qmd update 刷新搜索索引（若 qmd 不可用则跳并记录警告）

URL 直接输入：优先使用 defuddle 抓取网页内容（defuddle <URL> --format markdown），降级使用 WebFetch；保存到 raw/clippings/ 后走标准 INGEST 流程

个人写作流程：
- 不生成 Summary 节，跳过客观摘要
- 核心论点写入相关 concept 页的 ## My Position 节（标注「个人认知」）
- 不参与 confidence 的 source_count 计数
- 若引用了外部来源，尝试与已有 wiki/sources/ 页面建立 wikilinks
- raw_sha256 哈希机制同样适用

## QUERY 操作规范

触发词：直接提问，或「根据我的知识库」

执行步骤：
1. 执行 qmd query "<用户问题>" --json，获取 top 5 相关页面（若 qmd 报错则降级读取 wiki/index.md）
2. 逐一完整读取 top 5 文件
3. 合成答案，每个核心结论必须溯源到具体 wiki/sources/<slug>.md；注明 confidence 级别；矛盾时显式标注
4. 若答案具有复用价值，写入 outputs/YYYY-MM-DD-<topic>.md（frontmatter 含 graph-excluded: true）；包含「⚠ Confidence Notes」节；更新 index.md 和 log.md

输出格式按问题类型：普通问题→Markdown 正文、比较类→表格、演示类→Marp 幻灯片、趋势类→matplotlib 代码块、清单类→bullet list

## LINT 操作规范

触发词：lint、检查、健康检查

执行步骤：
1. 运行 scripts/lint.py（9 项检查）
2. 将报告写入 outputs/lint-YYYY-MM-DD.md（frontmatter 含 graph-excluded: true）
3. 执行 qmd status，对比索引文件数与 wiki/ 实际 .md 文件数（排除系统文件）；若索引落后则执行 qmd add wiki/，在报告中记录
4. 向用户展示摘要并询问是否修复

## AUDIT 操作规范

触发词：audit、系统审计

对当前知识库做完整系统状态核查，输出到 outputs/system-audit-YYYY-MM-DD.md。核查内容：
1. 目录结构完整性：验证 raw/ 和 wiki/ 下所有子目录存在
2. CLAUDE.md 关键规则覆盖（25 项逐项检查）
3. 模板文件完整性（5 个模板逐项验证必需字段）
4. 系统文件隔离状态（4 个系统文件含 graph-excluded: true）
5. scripts/lint.py 检查项（验证 9 项完整）
6. qmd 状态（qmd status + 测试查询 top 3）

每项标注 ✅ 通过 / ❌ 未通过（含缺失内容）/ 建议修复优先级。完成后追加 log.md。

## CALIBRATE 操作规范

触发词：标定、calibrate

首次使用前必做：先交互式摄入 2-3 篇典型来源，审查输出质量（摘要准确性、概念提取合理性、wikilinks 格式、frontmatter 完整性），不满意则调整 CLAUDE.md 对应规则。标定完成后再批量处理，避免风格不一致。

## REFLECT 操作规范

触发词：reflect、综合分析、发现规律

四阶段执行：
- Stage 0（反向检验）：主动搜索反驳证据，若无则标注「⚠ 回音室风险」
- Stage 1（模式扫描）：使用 qmd multi-get 批量扫描 concepts/entities/synthesis，识别跨来源模式、隐性关联、内容空白、矛盾对
- Stage 2（深度合成）：对有证据支撑的候选项，完整读取相关页面，写入 wiki/synthesis/<topic>-synthesis.md
- Stage 3（Gap Analysis）：识别孤立概念、隐性盲区、稀薄领域，输出到 outputs/gap-report-YYYY-MM-DD.md

完成后更新 overview.md、index.md、log.md

## MERGE 操作规范

触发词：merge、去重

同语言合并：确认方案 → 主 slug 保留 → 更新 wikilinks → 被合并文件替换为 redirect → 记日志

跨语言合并专项：主 slug 保留英文 → aliases 取并集 → Key Points/Sources/Evolution Log 按并集去重合并 → My Position 若两页都有先展示对比 → 旧 slug 保留为 redirect → 记日志

## ADD-QUESTION 操作规范

触发词：我想搞清楚、add question、记录一个问题

执行步骤：规范化问题 → 追加到 wiki/QUESTIONS.md（checkbox 格式）→ 追加 log.md

## Wikilink 使用规范

格式铁律：所有 wikilink 目标必须使用英文小写连字符格式
- ✅ [[value-investing]] ✅ [[attention-mechanism]]
- ❌ [[价值投资]]（中文） ❌ [[ValueInvesting]]（驼峰） ❌ [[value_investing]]（下划线）

中文名称处理：写入 concept 页 aliases 字段，正文括号标注，wikilink 始终用英文 slug

禁止 wikilink 系统文件：[[log]] [[index]] [[overview]] [[QUESTIONS]]
禁止 wikilink 操作名称：[[ingest]] [[query]] [[reflect]]
log.md 内部使用纯文本路径，不使用 wikilinks

## Wiki 语言规范

- Wiki 层统一用中文写作
- concept 页 title 用中文主名称
- 英文术语首次出现时括号标注
- slug（文件名）统一用英文小写连字符
- aliases 字段覆盖中英文所有叫法

## Confidence 更新规则

| 来源数量 | Confidence | 处理方式 |
|---|---|---|
| 1 | low | 自动设置 |
| 3+ | medium | 自动设置 |
| 5+ 无重大矛盾 | 候选 high | 需用户确认 |
| 用户明确回复「确认」或「ok」 | high | 才可设置 |

个人写作（raw/personal/）不参与 source_count 计数。

## Source Integrity Rules

- re-ingest 规则：若 lint 报告 ⚠ SOURCE MODIFIED，需重新摄入并更新所有受影响页面
- 来源超过 2 年标注 possibly_outdated: true
- 矛盾来源必须在 source 页和 concept 页的 Contradictions 节显式记录

## 系统文件隔离规则

以下文件 frontmatter 必须含 graph-excluded: true：
- wiki/log.md、wiki/index.md、wiki/overview.md、wiki/QUESTIONS.md
- outputs/ 下所有文件

## 文档维护规则

当 CLAUDE.md 规则更新时，同步更新 USER_GUIDE.md 对应章节，确保两份文档一致。

完整规范见 ~/.workbuddy/skills/llm-wiki/SKILL.md
CONTRACT
echo "  ✅ CLAUDE.md 已创建（完整行为契约）"

# 6. 创建 USER_GUIDE.md
green "▶ 创建 USER_GUIDE.md 用户指南..."
cat > "$WIKI_ROOT/USER_GUIDE.md" << 'GUIDE'
# USER_GUIDE.md — 用户指南

## 快速开始

1. 将文章放入 `raw/articles/` 或 `raw/clippings/`
2. 对 AI 说 "ingest raw/articles/xxx.md"
3. 提问: "根据我的知识库，XXX 是什么？"
4. 健康检查: "lint"
5. 综合分析: "reflect"

## 目录说明

- `raw/` — 你的原始素材（只增不改）
  - `articles/` — 手动保存的文章
  - `clippings/` — Obsidian Web Clipper 剪藏
  - `images/` — 截图和图片
  - `pdfs/` — PDF 文件
  - `notes/` — 随手记录
  - `personal/` — 自己写的文章、分析报告
- `wiki/` — AI 维护的知识库（你只读浏览）
  - `index.md` — 知识库索引
  - `log.md` — 操作日志
  - `overview.md` — 总览 + Health Dashboard
  - `QUESTIONS.md` — 开放问题队列
  - `sources/` — 来源摘要页
  - `concepts/` — 概念页
  - `entities/` — 实体页
  - `synthesis/` — 跨来源合成分析
  - `templates/` — 页面模板
- `outputs/` — 查询答案、图表、幻灯片、lint 报告
- `scripts/` — 健康检查脚本和索引重建脚本
  - `lint.py` — Wiki 健康检查（9 项检查）
  - `qmd-reindex.sh` — qmd 索引重建
- `CLAUDE.md` — AI 行为契约
- `README.md` — 项目说明
- `USER_GUIDE.md` — 本文件

## 操作说明

### INGEST（摄入）
将文件放入 `raw/` 目录，对 AI 说 "ingest" 或 "摄入"。
AI 会：读取文件 → 计算哈希 → 创建来源页 → 提取概念/实体 → 更新索引 → 记日志 → qmd update

### CALIBRATE（标定）
首次使用前必做。对 AI 说 "标定" 或 "calibrate"。
先交互式摄入 2-3 篇典型来源，审查输出质量，调整 CLAUDE.md 后再批量处理。

### QUERY（查询）
直接提问，或说 "根据我的知识库，..."。
AI 会用 qmd 搜索相关页面，合成答案并溯源到具体来源。

### LINT（健康检查）
对 AI 说 "lint" 或 "检查"。
运行 9 项健康检查 + qmd 索引同步。

### AUDIT（全系统审计）
对 AI 说 "audit" 或 "系统审计"。
完整系统状态核查：目录结构、CLAUDE.md 25 项规则覆盖、模板完整性、系统文件隔离、lint.py 检查项、qmd 状态。

### REFLECT（综合分析）
对 AI 说 "reflect" 或 "综合分析"。
四阶段执行：反向检验 → 模式扫描 → 深度合成 → 盲区分析。

### MERGE（去重合并）
对 AI 说 "merge" 或 "去重"。
合并重复概念，支持同语言和跨语言合并。

### ADD-QUESTION（记录问题）
对 AI 说 "我想搞清楚..." 或 "add question"。
将问题追加到开放问题队列，等待未来来源解答。

## 文档维护

当 CLAUDE.md 规则更新时，同步更新本文件对应章节，确保两份文档一致。
GUIDE
echo "  ✅ USER_GUIDE.md 已创建"

# 7. 创建 README.md
green "▶ 创建 README.md..."
cat > "$WIKI_ROOT/README.md" << EOF
# $TOPIC

基于 Karpathy LLM Wiki 模式的个人知识库。

## 快速开始

1. 将文章放入 \`raw/articles/\` 或 \`raw/clippings/\`
2. 对 AI 说 "ingest raw/articles/xxx.md"
3. 提问: "根据我的知识库，XXX 是什么？"
4. 健康检查: "lint"
5. 综合分析: "reflect"

## 目录说明

- \`raw/\` — 你的原始素材（只增不改）
- \`wiki/\` — AI 维护的知识库（你只读浏览）
- \`outputs/\` — 查询答案、图表、幻灯片、lint 报告
- \`scripts/\` — 健康检查脚本（lint.py）和索引重建脚本（qmd-reindex.sh）
- \`CLAUDE.md\` — AI 行为契约
- \`README.md\` — 项目说明
- \`USER_GUIDE.md\` — 用户指南
EOF
echo "  ✅ README.md 已创建"

# 8. 初始化 qmd 索引
green "▶ 初始化 qmd 索引..."
cd "$WIKI_ROOT"
if command -v qmd &> /dev/null; then
    qmd add wiki/ 2>/dev/null && echo "  ✅ qmd 索引已创建" || yellow "  ⚠ qmd add 失败，请手动执行 qmd add wiki/"
    echo "  qmd status:"
    qmd status 2>/dev/null || echo "  (qmd status 不可用)"
else
    yellow "  ⚠ qmd 未安装，跳过索引初始化"
    echo "  安装后请手动执行: qmd add wiki/ && qmd status"
fi

# 9. 初始化 git
green "▶ 初始化 Git..."
cd "$WIKI_ROOT"
if [ ! -d .git ]; then
    git init -q
    # 创建 .gitignore
    cat > .gitignore << 'EOF'
# Obsidian
.obsidian/workspace.json
.obsidian/workspace-mobile.json
.obsidian/cache

# OS
.DS_Store
Thumbs.db
EOF
    git add -A
    git commit -q -m "init: 初始化 LLM Wiki 知识库"
    echo "  ✅ Git 已初始化，首次提交完成"
else
    yellow "  ⚠ Git 已存在，跳过初始化"
fi

# 10. 验证报告
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
green "  ✅ 知识库初始化完成！"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "目录结构："
find "$WIKI_ROOT" -not -path "*/.git/*" -not -name ".git" | sort | head -40 | sed 's|'"$WIKI_ROOT"'||' | head -40
echo ""
echo "系统文件："
ls -1 "$WIKI_ROOT/wiki/"*.md 2>/dev/null | sed 's|.*/||'
echo ""
echo "模板文件："
ls -1 "$WIKI_ROOT/wiki/templates/"*.md 2>/dev/null | sed 's|.*/||'
echo ""
echo "脚本文件："
ls -1 "$WIKI_ROOT/scripts/"*.py "$WIKI_ROOT/scripts/"*.sh 2>/dev/null | sed 's|.*/||'
echo ""
echo "CLAUDE.md 章节："
grep "^## " "$WIKI_ROOT/CLAUDE.md" 2>/dev/null
echo ""
echo "qmd status："
cd "$WIKI_ROOT" && qmd status 2>/dev/null || echo "(qmd 不可用)"
echo ""
echo "lint.py 检查项："
grep "^def check_" "$WIKI_ROOT/scripts/lint.py" 2>/dev/null | sed 's/def check_//' | sed 's/(.*//'
echo ""
echo "下一步："
echo "  1. 用 Obsidian 打开 $WIKI_ROOT"
echo "  2. 把文章放到 raw/articles/ 或 raw/clippings/"
echo "  3. 说 \"ingest raw/articles/你的文章.md\" 开始摄入"
