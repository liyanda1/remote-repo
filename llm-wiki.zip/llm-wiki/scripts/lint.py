#!/usr/bin/env python3
"""
LLM Wiki 健康检查脚本 — 9 项检查
用法: python3 lint.py [WIKI_ROOT]
如果不传 WIKI_ROOT，默认使用当前工作目录。
"""

import os
import sys
import re
import hashlib
import glob
from datetime import datetime, date
from collections import defaultdict

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False


# ── 工具函数 ──────────────────────────────────────────────

WIKI_ROOT = '.'  # 在 main() 中设置

def rel_path(fpath):
    """返回相对于 wiki_root 的路径，用正斜杠。"""
    return os.path.relpath(fpath, WIKI_ROOT).replace('\\', '/')

def parse_frontmatter(content):
    """解析 YAML frontmatter，返回 (frontmatter_dict, body_str)。"""
    if not content.startswith('---'):
        return {}, content
    parts = content.split('---', 2)
    if len(parts) < 3:
        return {}, content
    fm_text = parts[1].strip()
    body = parts[2]
    if HAS_YAML:
        try:
            fm = yaml.safe_load(fm_text)
            if fm is None:
                fm = {}
            return fm, body
        except yaml.YAMLError:
            return {}, content
    else:
        # 简易解析：逐行提取 key: value
        fm = {}
        for line in fm_text.split('\n'):
            line = line.strip()
            if ':' in line and not line.startswith('#'):
                key, _, val = line.partition(':')
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if val.startswith('[') and val.endswith(']'):
                    val = [v.strip().strip('"').strip("'") for v in val[1:-1].split(',') if v.strip()]
                fm[key] = val
        return fm, body


def extract_wikilinks(body):
    """提取 body 中所有 [[wikilink]] 目标。"""
    # 匹配 [[xxx]] 或 [[xxx|alias]]
    pattern = r'\[\[([^\]|]+)(?:\|[^\]]+)?\]\]'
    return re.findall(pattern, body)


def is_english_slug(s):
    """检查字符串是否符合英文小写连字符格式。"""
    return bool(re.match(r'^[a-z0-9]+(-[a-z0-9]+)*$', s))


def jaccard_similarity(a, b):
    """计算两个字符串的 Jaccard 相似度（基于字符 n-gram）。"""
    def ngrams(s, n=2):
        s = s.lower().replace('-', '')
        return set(s[i:i+n] for i in range(len(s)-n+1)) if len(s) >= n else {s}
    ga, gb = ngrams(a), ngrams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def file_sha256(filepath):
    """计算文件的 SHA-256 哈希。"""
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def body_word_count(body):
    """统计 body 的字数（中文按字符，英文按单词）。"""
    # 去掉 markdown 语法
    text = re.sub(r'```.*?```', '', body, flags=re.DOTALL)
    text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)
    text = re.sub(r'[#*\-|>\[\]()]', '', text)
    text = text.strip()
    return len(text)


# ── 检查项 ────────────────────────────────────────────────

def check_1_frontmatter(wiki_files, wiki_root):
    """1. YAML frontmatter 合法性"""
    issues = []
    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        rel = rel_path(fpath)
        if not fm:
            issues.append(f"❌ {rel} — 无合法 YAML frontmatter")
        elif 'type' not in fm:
            issues.append(f"❌ {rel} — frontmatter 缺少 type 字段")
        elif 'date' not in fm:
            # 系统文件（type: system-*）不需要 date 字段
            if not str(fm.get('type', '')).startswith('system-'):
                issues.append(f"❌ {rel} — frontmatter 缺少 date 字段")
    return issues


def check_2_broken_wikilinks(wiki_files, wiki_dir):
    """2. Broken Wikilinks"""
    issues = []
    # 收集所有 wiki 页面的 slug（文件名不含 .md）
    existing_slugs = set()
    for fpath, _ in wiki_files:
        slug = os.path.splitext(os.path.basename(fpath))[0]
        existing_slugs.add(slug)
        # 也记录相对路径形式
        rel = os.path.relpath(fpath, wiki_dir)
        existing_slugs.add(rel)
        existing_slugs.add(rel.replace('\\', '/'))

    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        rel = rel_path(fpath)
        links = extract_wikilinks(body)
        for link in links:
            link = link.strip()
            # 去掉路径前缀
            slug = link.split('/')[-1]
            if slug not in existing_slugs and link not in existing_slugs:
                issues.append(f"❌ {rel} — 断链: [[{link}]]")
    return issues


def check_3_index_consistency(wiki_files, wiki_dir):
    """3. Index 一致性"""
    issues = []
    index_path = os.path.join(wiki_dir, 'index.md')
    if not os.path.exists(index_path):
        return ["❌ wiki/index.md 不存在"]
    
    with open(index_path, 'r', encoding='utf-8') as f:
        index_content = f.read()
    
    # 提取 index.md 中所有 wikilinks
    index_links = extract_wikilinks(index_content)
    existing_slugs = set()
    for fpath, _ in wiki_files:
        slug = os.path.splitext(os.path.basename(fpath))[0]
        existing_slugs.add(slug)
    
    for link in index_links:
        slug = link.strip().split('/')[-1]
        if slug not in existing_slugs:
            issues.append(f"❌ index.md 引用了不存在的页面: [[{link}]]")
    return issues


def check_4_stubs(wiki_files):
    """4. Stub 页面（正文少于 100 字）"""
    issues = []
    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        # 跳过系统文件和模板
        if fm.get('type', '').startswith('system-') or fm.get('type') == 'template':
            continue
        wc = body_word_count(body)
        if wc < 100:
            rel = rel_path(fpath)
            issues.append(f"⚠ {rel} — 正文仅 {wc} 字，疑似空壳页面")
    return issues


def check_5_near_duplicate_concepts(wiki_dir):
    """5. 近重复概念名称（Jaccard 相似度 > 0.7）"""
    issues = []
    concept_dir = os.path.join(wiki_dir, 'concepts')
    if not os.path.isdir(concept_dir):
        return []
    
    slugs = []
    for fname in os.listdir(concept_dir):
        if fname.endswith('.md'):
            slugs.append((fname, os.path.splitext(fname)[0]))
    
    for i in range(len(slugs)):
        for j in range(i+1, len(slugs)):
            sim = jaccard_similarity(slugs[i][1], slugs[j][1])
            if sim > 0.7:
                issues.append(
                    f"⚠ 近重复概念: {slugs[i][0]} ↔ {slugs[j][0]} (相似度 {sim:.2f}) — 建议执行 MERGE"
                )
    return issues


def check_6_sha256_integrity(wiki_files, wiki_root):
    """6. SHA-256 完整性"""
    issues = []
    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        if fm.get('type') != 'source-summary' and fm.get('type') != 'personal-writing':
            continue
        raw_file = fm.get('raw_file', '')
        recorded_hash = fm.get('raw_sha256', '')
        if not raw_file or not recorded_hash:
            continue
        
        raw_path = os.path.join(wiki_root, raw_file)
        if not os.path.exists(raw_path):
            issues.append(f"❌ {rel_path(fpath)} — raw 文件不存在: {raw_file}")
            continue
        
        actual_hash = file_sha256(raw_path)
        if actual_hash != recorded_hash:
            issues.append(
                f"⚠ SOURCE MODIFIED: {rel_path(fpath)} — "
                f"raw 文件哈希变更 (记录: {recorded_hash[:12]}... 实际: {actual_hash[:12]}...) — 需重新摄入"
            )
    return issues


def check_7_stale_pages(wiki_files):
    """7. Stale 页面（超过 domain_volatility 时效阈值）"""
    issues = []
    today = date.today()
    thresholds = {'high': 90, 'medium': 180, 'low': 365}
    
    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        if fm.get('type') != 'concept':
            continue
        
        volatility = fm.get('domain_volatility', 'medium')
        last_reviewed = fm.get('last_reviewed', fm.get('date', ''))
        
        if not last_reviewed or volatility not in thresholds:
            continue
        
        try:
            review_date = datetime.strptime(str(last_reviewed), '%Y-%m-%d').date()
        except (ValueError, TypeError):
            continue
        
        days_since = (today - review_date).days
        threshold = thresholds[volatility]
        
        if days_since > threshold:
            rel = rel_path(fpath)
            issues.append(
                f"⚠ {rel} — Stale: 距上次审查 {days_since} 天，超过 {volatility} 阈值 {threshold} 天"
            )
    return issues


def check_8_cross_language_duplicates(wiki_dir):
    """8. 跨语言重复（aliases 字段重叠检测）"""
    issues = []
    concept_dir = os.path.join(wiki_dir, 'concepts')
    if not os.path.isdir(concept_dir):
        return []
    
    # 收集所有 concept 页的 aliases
    concepts = []
    for fname in os.listdir(concept_dir):
        if not fname.endswith('.md'):
            continue
        fpath = os.path.join(concept_dir, fname)
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        fm, _ = parse_frontmatter(content)
        aliases = fm.get('aliases', [])
        if isinstance(aliases, str):
            aliases = [aliases]
        if aliases:
            slug = os.path.splitext(fname)[0]
            concepts.append((slug, set(a.lower().strip() for a in aliases if a)))
    
    # 检查别名重叠
    for i in range(len(concepts)):
        for j in range(i+1, len(concepts)):
            overlap = concepts[i][1] & concepts[j][1]
            if overlap:
                issues.append(
                    f"⚠ 跨语言重复: {concepts[i][0]} 和 {concepts[j][0]} "
                    f"共享别名: {', '.join(overlap)} — 建议执行跨语言 MERGE"
                )
    return issues


def check_9_wikilink_format(wiki_files):
    """9. Wikilink 格式规范（英文小写连字符）"""
    issues = []
    # 系统文件和操作名不应被 wikilink
    forbidden_targets = {'log', 'index', 'overview', 'QUESTIONS', 'ingest', 'query', 'reflect', 'lint', 'merge'}
    
    for fpath, content in wiki_files:
        fm, body = parse_frontmatter(content)
        rel = rel_path(fpath)
        
        # 跳过 log.md 的检查（它用纯文本路径）
        if os.path.basename(fpath) == 'log.md':
            continue
        
        links = extract_wikilinks(body)
        for link in links:
            link = link.strip()
            slug = link.split('/')[-1]
            
            # 检查是否引用了系统文件
            if slug.lower() in forbidden_targets:
                issues.append(f"❌ {rel} — 禁止 wikilink 系统文件/操作: [[{link}]]")
                continue
            
            # 检查格式
            if not is_english_slug(slug):
                issues.append(f"❌ {rel} — wikilink 格式错误: [[{link}]] (应为英文小写连字符)")
    return issues


# ── 主流程 ────────────────────────────────────────────────

def main():
    global WIKI_ROOT
    wiki_root = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    WIKI_ROOT = wiki_root
    wiki_dir = os.path.join(wiki_root, 'wiki')
    
    if not os.path.isdir(wiki_dir):
        print(f"错误: {wiki_dir} 不存在")
        sys.exit(1)
    
    # 收集所有 wiki 下的 .md 文件
    wiki_files = []
    for root, dirs, files in os.walk(wiki_dir):
        # 跳过 templates 目录
        if 'templates' in root:
            continue
        for fname in files:
            if fname.endswith('.md'):
                fpath = os.path.join(root, fname)
                with open(fpath, 'r', encoding='utf-8') as f:
                    content = f.read()
                wiki_files.append((fpath, content))
    
    print(f"扫描 {len(wiki_files)} 个 wiki 文件...\n")
    
    # 执行 9 项检查
    checks = [
        ("1. YAML Frontmatter 合法性", check_1_frontmatter(wiki_files, wiki_root)),
        ("2. Broken Wikilinks", check_2_broken_wikilinks(wiki_files, wiki_dir)),
        ("3. Index 一致性", check_3_index_consistency(wiki_files, wiki_dir)),
        ("4. Stub 页面", check_4_stubs(wiki_files)),
        ("5. 近重复概念名称", check_5_near_duplicate_concepts(wiki_dir)),
        ("6. SHA-256 完整性", check_6_sha256_integrity(wiki_files, wiki_root)),
        ("7. Stale 页面", check_7_stale_pages(wiki_files)),
        ("8. 跨语言重复", check_8_cross_language_duplicates(wiki_dir)),
        ("9. Wikilink 格式规范", check_9_wikilink_format(wiki_files)),
    ]
    
    # 生成报告
    today_str = date.today().isoformat()
    report_lines = [
        "---",
        f"type: lint-report",
        f"date: {today_str}",
        f"graph-excluded: true",
        "---",
        "",
        f"# Lint 报告 — {today_str}",
        "",
        f"扫描文件数: {len(wiki_files)}",
        "",
    ]
    
    total_issues = 0
    for title, issues in checks:
        report_lines.append(f"## {title}")
        if not issues:
            report_lines.append("✅ 通过")
        else:
            report_lines.extend(issues)
            total_issues += len(issues)
        report_lines.append("")
    
    report_lines.append(f"---")
    report_lines.append(f"**总计: {total_issues} 个问题**")
    
    report_content = '\n'.join(report_lines)
    
    # 写入报告文件
    outputs_dir = os.path.join(wiki_root, 'outputs')
    os.makedirs(outputs_dir, exist_ok=True)
    report_path = os.path.join(outputs_dir, f'lint-{today_str}.md')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    # 打印摘要
    print("=" * 60)
    print(f"Lint 报告 — {today_str}")
    print("=" * 60)
    for title, issues in checks:
        status = "✅ 通过" if not issues else f"❌ {len(issues)} 个问题"
        print(f"  {title}: {status}")
    print(f"\n总计: {total_issues} 个问题")
    print(f"报告已写入: {report_path}")


if __name__ == '__main__':
    main()
