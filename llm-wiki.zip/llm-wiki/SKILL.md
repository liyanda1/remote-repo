---
title: "LLM Wiki 个人知识库"
summary: "基于 Karpathy llm-wiki 模式的个人知识库系统。你只负责剪藏，LLM 负责理解和沉淀。"
triggers:
  - ingest
  - 摄入
  - 处理这个
  - lint
  - 检查
  - 健康检查
  - reflect
  - 综合分析
  - 发现规律
  - merge
  - 去重
  - add question
  - 我想搞清楚
  - 记录一个问题
  - 初始化知识库
  - init wiki
  - audit
  - 系统审计
  - 标定
  - calibrate
---

# LLM Wiki — 个人知识库系统

> 基于 Andrej Karpathy llm-wiki 模式。核心理念：**你只负责剪藏，LLM 负责理解和沉淀。**

## 定位 Wiki 根目录

每次操作前，先定位知识库根目录（下称 `WIKI_ROOT`）：

1. 检查当前工作目录是否包含 `wiki/` 目录 → 是则 `WIKI_ROOT=当前目录`
2. 检查当前工作目录是否包含 `CLAUDE.md` 且其中引用了 wiki → 是则 `WIKI_ROOT=当前目录`
3. 询问用户知识库路径

定位后，所有路径都基于 `WIKI_ROOT`。

---

## 核心架构

| 层级 | 归属者 | 内容 | 不可违反的规则 |
|---|---|---|---|
| Raw 原始层 | 你（人类） | 剪藏文章、PDF、图片、笔记 | IMMUTABLE，LLM 绝不修改 |
| Wiki 编译层 | LLM 完全拥有 | Markdown 实体/概念/来源/合成页 | 全部由 LLM 写入，人类只读浏览 |
| Outputs 层 | LLM 生成 | Q&A 答案、图表、Marp 幻灯片 | 输出必须回写入 Wiki，不消失于对话历史 |

### 核心原则

1. **Raw 层不可变** — 原始来源绝对不修改
2. **Wiki 层 LLM 完全拥有** — 你只浏览，不编辑
3. **输出必须持久化** — 答案写入 outputs/，不消失在对话中
4. **矛盾必须显式标注** — 来源分歧明确记录
5. **每次操作都记日志** — 所有操作写入 wiki/log.md

### 目录结构

```
WIKI_ROOT/
├── raw/                        # 人类所有，LLM 只读
│   ├── articles/               # 手动保存的文章（Markdown）
│   ├── clippings/              # Obsidian Web Clipper 剪藏（主要入口）
│   ├── images/                 # 截图和图片
│   ├── pdfs/                   # PDF 文件及配套元数据文件
│   ├── notes/                  # 随手记录
│   └── personal/               # ★ 自己写的文章、分析报告、投资笔记
├── wiki/                       # LLM 完全拥有
│   ├── index.md                # LLM 读取的第一个文件，面向内容的索引
│   ├── log.md                  # 仅追加的操作日志（含 graph-excluded: true）
│   ├── overview.md             # 高层综述 + Health Dashboard
│   ├── QUESTIONS.md            # 开放问题队列
│   ├── sources/                # 每个来源的摘要页
│   ├── concepts/               # 思想、模式、技术（含 aliases 跨语言字段）
│   ├── entities/               # 人物、工具、机构、论文
│   ├── synthesis/              # 跨来源合成分析
│   └── templates/              # 页面模板（LLM 使用）
├── outputs/                    # 查询答案、图表、幻灯片、lint 报告
│   ├── lint.md                 # lint 报告
│   └── query.md                # 查询答案
├── scripts/
│   ├── lint.py                 # Wiki 健康检查脚本（9 项检查）
│   └── qmd-reindex.sh          # qmd 索引重建脚本
├── CLAUDE.md                   # LLM 行为契约（核心文件）
└── README.md                   # 项目说明
```

---

## INIT WIKI — 初始化知识库

触发词：`初始化知识库`、`init wiki`

执行步骤：

1. 询问用户知识库路径（默认 `~/knowledge-base`）和主题
2. 创建完整目录结构
3. 创建系统文件：
   - `wiki/index.md`（frontmatter 含 `type: system-index, graph-excluded: true`）
   - `wiki/log.md`（frontmatter 含 `type: system-log, graph-excluded: true`）
   - `wiki/overview.md`（frontmatter 含 `type: system-overview, graph-excluded: true`，含 Health Dashboard）
   - `wiki/QUESTIONS.md`（frontmatter 含 `type: system-questions, graph-excluded: true`）
4. 复制模板文件到 `wiki/templates/`
5. 复制 `lint.py` 和 `qmd-reindex.sh` 到 `scripts/`
6. 创建 `CLAUDE.md`（行为契约），必须包含以下所有章节：
   - **系统概述**：三层架构说明（Raw/Wiki/Outputs）、核心原则（raw/ 由人类拥有 LLM 只读，wiki/ 由 LLM 完全拥有）
   - **INGEST 操作规范**：触发词、来源类型判断、缺少 frontmatter 处理、外部来源标准流程（12 步，含 canonical_source 译文检测、URL defuddle 抓取、qmd update）、个人写作流程
   - **CALIBRATE 操作规范**：标定流程（首次使用前必做，2-3 篇测试 → 审查 → 调整 CLAUDE.md）
   - **QUERY 操作规范**：qmd query 优先，降级读 index.md
   - **LINT 操作规范**：lint.py 9 项检查 + qmd status 索引同步
   - **AUDIT 操作规范**：全系统审计（6 类 25 项核查清单，输出到 outputs/system-audit-YYYY-MM-DD.md）
   - **REFLECT 操作规范**：四阶段执行（Stage 0 反向检验 → Stage 1 模式扫描 → Stage 2 深度合成 → Stage 3 Gap Analysis）
   - **MERGE 操作规范**：同语言合并流程、跨语言合并专项流程
   - **ADD-QUESTION 操作规范**
   - **Wikilink 使用规范**：格式铁律、允许/禁止场景
   - **Wiki 语言规范**
   - **Confidence 更新规则**
   - **Source Integrity Rules**
   - **系统文件隔离规则**
   - **文档维护规则**：当 CLAUDE.md 规则更新时，同步更新 USER_GUIDE.md 对应章节，确保两份文档一致
7. 创建 `USER_GUIDE.md`（用户指南，与 CLAUDE.md 对应章节保持一致）
8. 初始化 qmd 索引：执行 `qmd add wiki/` 和 `qmd status`
9. 初始化 git（`git init && git add -A && git commit`）
10. 输出验证报告：
    - 目录结构树（tree -L 3 或 find）
    - CLAUDE.md 包含的章节列表
    - wiki/templates/ 下的模板文件列表
    - qmd status 输出（索引文件数量）
    - scripts/lint.py 包含的检查项列表

### 系统文件内容

**wiki/index.md**：
```markdown
---
type: system-index
graph-excluded: true
---

# 知识库索引

## Sources（按日期倒序）

（暂无）

## Concepts

（暂无）

## Entities

（暂无）

## Recent Synthesis

（暂无）

## Outputs

（暂无）
```

**wiki/log.md**：
```markdown
---
type: system-log
graph-excluded: true
---

# 操作日志

```

**wiki/overview.md**：
```markdown
---
type: system-overview
graph-excluded: true
---

# 知识库总览

## Knowledge Base Health Dashboard

| 指标 | 值 |
|---|---|
| 总来源数 | 0 |
| 高置信度概念数 | 0 |
| 开放问题数 | 0 |
| Stale 页面数 | 0 |
| 孤立概念数 | 0 |
```

**wiki/QUESTIONS.md**：
```markdown
---
type: system-questions
graph-excluded: true
---

# 开放问题

## Open Questions

（暂无）

## Resolved Questions

（暂无）
```

---

## CALIBRATE — 标定（首次使用前必做）

触发词：`标定`、`calibrate`

> Karpathy 原文特别强调：在正式批量处理前，先交互式标定 2-3 篇最典型的来源，审查输出质量后再调整 CLAUDE.md。

### 执行步骤

1. 提示用户放入 1 篇测试文章到 `raw/articles/`
2. 执行 INGEST，**仔细审查**：
   - 摘要质量是否准确
   - 概念提取是否合理（有无遗漏/过度提取）
   - wikilinks 格式是否正确（英文小写连字符）
   - frontmatter 字段是否完整
3. 若不满意，提示用户调整 CLAUDE.md 中对应规则（如「以后处理 [情况] 时要 [规范]」）
4. 重复 2-3 篇，直到输出质量稳定
5. 标定完成后，在 `wiki/log.md` 记录：`YYYY-MM-DD | calibrate | 标定完成，N 篇测试通过`
6. 提示用户：「标定完成，可以开始批量摄入」

**标定后再处理剩余文章，避免大量文章风格不一致。**

---

## INGEST — 摄入

触发词：`ingest`、`摄入`、`处理这个`

### 来源类型判断（优先级由高到低）

1. frontmatter 含 `type: personal-writing` → 走「个人写作」流程
2. 文件路径包含 `raw/personal/` → 走「个人写作」流程
3. frontmatter 含 `type: pdf-reference` → 走「PDF 参考」流程
4. 其他 → 走「外部来源」标准流程

### 缺少 frontmatter 时的处理

- 从文件第一个 `#` 标题提取 title；若无标题则从文件名推断
- source 字段留空，在 `wiki/sources/<slug>.md` 中标注「来源未知」
- date 使用文件系统修改时间
- 不中断 INGEST，但在 log.md 记录「警告：来源文件缺少标准 frontmatter」

### 外部来源标准流程（12 步）

1. **读取原始来源**（raw/ 中的文件，只读）
2. **计算 SHA-256 哈希**（使用 `python3 -c "import hashlib; print(hashlib.sha256(open('FILE','rb').read()).hexdigest())"`）
3. **与用户确认核心要点**（逐一摄入，保持参与感）
4. **生成 slug**（小写英文，用连字符，例如 `attention-is-all-you-need`）
5. **创建 `wiki/sources/<slug>.md`**（使用 source-template.md），frontmatter 中写入：
   - `raw_file`: 相对路径（如 `raw/articles/filename.md`）
   - `raw_sha256`: SHA-256 哈希值
   - `last_verified`: 摄入日期（YYYY-MM-DD）
   - 若来源发表日期超过 2 年前：标注 `possibly_outdated: true`，并在摘要末尾添加提示
   - **canonical_source 译文检测**：若来源是译文/转载，在 `canonical_source` 字段填入原始来源 URL；遍历 `wiki/sources/*.md`，检查是否有其他 source 页的 `canonical_source` 与本次相同 → 若匹配，标记为同源译文，在两个 source 页的 Contradictions 节交叉引用，不重复提取概念
6. **概念名称对齐检查**（提取概念之前必须执行）：
   - 将每个提取到的概念名称统一映射为英文小写连字符 slug（例如「第一性原理」→ `first-principles-thinking`）
   - 在 `wiki/concepts/` 中查找该 slug 是否已存在对应文件
   - **同时检查所有已有 concept 页的 `aliases` 字段**：遍历 `wiki/concepts/*.md`，解析每页 frontmatter 的 aliases 列表，检查是否包含当前概念名称（支持中英文别名匹配）
   - 若通过 slug 匹配或通过 aliases 匹配到已有页面：更新已有页面，不创建新页面
   - 若找不到任何匹配：才创建新页面，并在 frontmatter 的 `aliases` 中同时填入中文名和英文名
7. **为每个提取到的概念**：
   - 如果 `wiki/concepts/<concept>.md` 已存在：更新它，追加新来源引用，在 Evolution Log 追加记录，更新 source_count 和 confidence，同时更新 `last_reviewed` 字段
   - 如果不存在：创建新文件（使用 concept-template.md），同时在 `aliases` 字段填入该概念的中英文名称
   - **Evolution Log 追加规则**：
     - 若本次来源与当前 Definition 一致：写「强化」
     - 若有修正：写「修正：[具体变化]」
     - 若相互矛盾：写「新增分歧：[分歧内容]，见 Contradictions 节」
     - 格式：`- YYYY-MM-DD（N sources）：[本次认知变化的一句话描述]`
8. **为每个提取到的实体**：同上逻辑（使用 entity-template.md）
9. **更新 `wiki/index.md`**：将来源从 Unprocessed 移动到 Processed，新增的 concept/entity 加入对应列表
10. **读取 `wiki/QUESTIONS.md`**，检查本次来源是否能回答开放问题：
    - 若能：提示用户「此来源可能回答了开放问题：[问题描述]，是否立即执行 QUERY？」
    - 用户确认后，执行 QUERY 并将结果写入 `wiki/synthesis/`，同时在 QUESTIONS.md 中将该问题移入 Resolved
11. **在 `wiki/log.md` 末尾追加**：`YYYY-MM-DD HH:MM | ingest | [来源标题]`
12. **执行 `qmd update`** 刷新搜索索引（若 qmd 不可用则跳过，在 log.md 记录「警告：qmd 不可用，索引未更新」）

### 个人写作流程

- 不生成 Summary 节，跳过客观摘要
- 核心论点写入相关 concept 页的 `## My Position` 节（标注「个人认知」）
- 不参与 confidence 的 source_count 计数（避免用自己的文章给自己背书）
- 若文章中引用了外部来源，提取这些引用并尝试与已有 `wiki/sources/` 页面建立 wikilinks
- raw_sha256 哈希机制同样适用
- Evolution Log 记录：「YYYY-MM-DD 个人写作 [[slug]] 确立了对此概念的明确立场」

### URL 直接输入

如果用户直接给一个 URL 而非文件路径：
1. 优先使用 `defuddle` 抓取网页内容（`defuddle <URL> --format markdown`）；若 defuddle 不可用则降级使用 WebFetch 工具
2. 将内容保存到 `raw/clippings/YYYY-MM-DD-<slug>.md`，frontmatter 含 title、source_url、date
3. 然后走标准 INGEST 流程

---

## QUERY — 查询

触发词：直接提问，或「根据我的知识库」

执行步骤：

1. **执行 `qmd query "<用户问题>" --json`**，获取 top 5 相关页面（若 qmd 报错则降级读取 `wiki/index.md`，识别最相关的 3-5 个页面）
2. **逐一完整读取 top 5 文件**
3. **合成答案**，每个核心结论必须溯源到具体 `wiki/sources/<slug>.md`（不允许只引用 concept 页）；注明各来源 confidence 级别；来源相互矛盾时显式标注分歧
4. **若答案具有复用价值**，写入 `outputs/YYYY-MM-DD-<topic>.md`，文件 frontmatter 含 `graph-excluded: true`；在输出末尾包含「⚠ Confidence Notes」节；更新 `wiki/index.md` 的 Recent Synthesis 列表；追加 `wiki/log.md`

### 输出格式（按问题类型）

| 问题类型 | 输出格式 |
|---|---|
| 普通问题 | Markdown 正文 |
| 比较类 | Markdown 表格 |
| 演示类 | Marp 幻灯片（frontmatter 加 `marp: true`） |
| 趋势类 | Python matplotlib 代码块 |
| 清单类 | 结构化 bullet list |

---

## LINT — 健康检查

触发词：`lint`、`检查`、`健康检查`

执行步骤：

1. 运行 `python3 scripts/lint.py`（传入 WIKI_ROOT 路径）
2. 将报告写入 `outputs/lint-YYYY-MM-DD.md`（frontmatter 含 `graph-excluded: true`）
3. 执行 `qmd status`，对比索引文件数与 `wiki/` 实际 `.md` 文件数（排除系统文件）；若索引落后则执行 `qmd add wiki/`，在报告中记录
4. 向用户展示摘要并询问是否修复

### lint.py 检查项（9 项）

| # | 检查项 | 说明 |
|---|---|---|
| 1 | YAML frontmatter 合法性 | 所有 wiki/ 下的 .md 文件是否有合法 YAML frontmatter（含 type 和 date） |
| 2 | Broken Wikilinks | `[[xxx]]` 引用了不存在的页面 |
| 3 | Index 一致性 | wiki/index.md 中标记的文件是否都实际存在 |
| 4 | Stub 页面 | 正文少于 100 字的空壳页面 |
| 5 | 近重复概念名称 | slug 名称 Jaccard 相似度 > 0.7 的 concept 页对 |
| 6 | SHA-256 完整性 | raw 文件哈希与 source 页 raw_sha256 字段比对（⚠ SOURCE MODIFIED） |
| 7 | Stale 页面 | 超过 domain_volatility 时效阈值（high=90天, medium=180天, low=365天） |
| 8 | 跨语言重复 | source URL 相似度检测 + 不同 concept 页的 aliases 字段重叠检测 |
| 9 | Wikilink 格式规范 | 检测非英文小写连字符格式的 wikilink（如中文词汇 `[[价值投资]]`）及别名断链 |

---

## AUDIT — 全系统审计

触发词：`audit`、`系统审计`

对当前知识库做一次完整的系统状态核查，逐项验证以下内容，输出核查报告到 `outputs/system-audit-YYYY-MM-DD.md`（frontmatter 含 `graph-excluded: true`）。

### 一、目录结构完整性

验证 `raw/` 和 `wiki/` 下所有子目录是否存在。

### 二、CLAUDE.md 关键规则覆盖（逐项输出是/否）

- [ ] Raw 层不可变原则
- [ ] INGEST 来源类型判断（personal-writing vs 外部来源）
- [ ] INGEST SHA-256 哈希记录规则
- [ ] INGEST 去重检测（含 canonical_source 译文检测）
- [ ] INGEST 概念名称对齐检查（aliases 匹配）
- [ ] INGEST QUESTIONS.md 匹配检查
- [ ] INGEST 缺少 frontmatter 的处理规则
- [ ] INGEST URL 直接输入的 defuddle 调用规则
- [ ] INGEST 最后一步执行 qmd update
- [ ] QUERY 使用 qmd query 优先（含 fallback）
- [ ] QUERY 来源溯源要求（追溯到 sources 页）
- [ ] QUERY Confidence Notes 输出要求
- [ ] QUERY 高价值答案持久化规则
- [ ] confidence: high 必须用户确认，禁止自动晋升
- [ ] LINT 运行 scripts/lint.py（9 项检查）
- [ ] LINT 执行 qmd 索引同步验证
- [ ] REFLECT Stage 0 反向检验
- [ ] REFLECT Stage 1 使用 qmd multi-get 批量扫描
- [ ] REFLECT Stage 3 Gap Analysis
- [ ] MERGE 跨语言合并专项流程（redirect 文件保留）
- [ ] Wikilink 格式铁律（英文小写连字符）
- [ ] Wikilink 禁止清单（系统文件不得被 wikilink）
- [ ] Wiki 语言规范（中文写作，英文 slug，aliases 跨语言）
- [ ] 系统文件隔离规则（graph-excluded: true）
- [ ] 文档维护规则（CLAUDE.md 更新时同步 USER_GUIDE.md）

### 三、模板文件完整性（逐项验证必需字段）

- [ ] source-template.md 含 `language` / `canonical_source`
- [ ] personal-writing-template.md 含 `type: personal-writing` / `confidence_at_writing`
- [ ] concept-template.md 含 `aliases` / `domain_volatility` / `last_reviewed` / Evolution Log
- [ ] entity-template.md 含 `aliases`
- [ ] synthesis-template.md 含 `Counter-evidence` / `Confidence Notes` / `Limitations`

### 四、系统文件隔离状态

- [ ] `wiki/log.md` 含 `graph-excluded: true`
- [ ] `wiki/index.md` 含 `graph-excluded: true`
- [ ] `wiki/overview.md` 含 `graph-excluded: true`
- [ ] `wiki/QUESTIONS.md` 含 `graph-excluded: true`

### 五、scripts/lint.py 检查项

验证是否包含全部 9 项检查（列出每项名称）。

### 六、qmd 状态

- 执行 `qmd status`，输出索引文件数量
- 执行一次测试查询（`qmd query "test" --json`），输出 top 3 结果

### 输出格式

每项标注：✅ 通过 / ❌ 未通过（含缺失内容） / 建议修复优先级

完成后追加 `wiki/log.md`：`YYYY-MM-DD | audit | 全系统审计完成`

---

## REFLECT — 二阶合成

触发词：`reflect`、`综合分析`、`发现规律`

四阶段执行：

### Stage 0 — 反向检验

在生成任何合成结论之前，主动搜索反驳证据。若无反对来源，在 Limitations 节标注「⚠ 回音室风险：未找到反驳来源，结论可能存在确认偏差」

### Stage 1 — 模式扫描

使用 qmd 批量扫描：

```
qmd multi-get "wiki/concepts/*.md" -l 40
qmd multi-get "wiki/entities/*.md" -l 40
qmd multi-get "wiki/synthesis/*.md" -l 60
```

（若 qmd 不可用则降级为逐个读取）

识别：
- 跨来源模式
- 隐性关联
- 内容空白
- 矛盾对

### Stage 2 — 深度合成

对有证据支撑的候选项，完整读取相关页面，写入 `wiki/synthesis/<topic>-synthesis.md`（使用 synthesis-template.md）

### Stage 3 — Gap Analysis

- `source_count = 1` 且创建超过 30 天的孤立概念
- 多处提及但无独立页面的概念/实体（隐性盲区）
- 覆盖明显稀薄的主题领域
- 输出到 `outputs/gap-report-YYYY-MM-DD.md`（frontmatter 含 `graph-excluded: true`）

### 完成后

更新 `wiki/overview.md` 的 Health Dashboard，更新 `wiki/index.md` 的 Recent Synthesis，追加 `wiki/log.md`

---

## MERGE — 去重合并

触发词：`merge`、`去重`

### 同语言合并流程

1. 与用户确认合并方案（绝不自动合并）
2. 主 slug 保留，被合并页面的 wikilinks 全部更新
3. 被合并文件替换为重定向文件（内容：`redirect: [[wiki/concepts/主slug]]`）
4. log.md 记录：`YYYY-MM-DD | merge | [旧slug] → [主slug]`

### 跨语言合并专项流程

1. 主 slug 保留英文
2. aliases 取两个页面的并集
3. Key Points / Sources / Evolution Log 按并集+去重合并
4. My Position 若两页都有，先向用户展示对比后再合并
5. 被合并的旧 slug 文件保留为 redirect 文件（确保旧 wikilinks 不 broken）
6. log.md 记录：`YYYY-MM-DD | merge | [旧slug] → [主slug]（跨语言合并）`

---

## ADD-QUESTION — 记录问题

触发词：`我想搞清楚`、`add question`、`记录一个问题`

执行步骤：

1. 将问题规范化（提取核心疑问）
2. 追加到 `wiki/QUESTIONS.md` 的 Open Questions：
   ```
   - [ ] 问题内容（opened YYYY-MM-DD）
   ```
3. 追加 `wiki/log.md`

---

## Wikilink 使用规范

### 格式铁律（不可违反）

所有 wikilink 目标必须使用英文小写连字符格式：

- ✅ `[[value-investing]]` ✅ `[[attention-mechanism]]` ✅ `[[warren-buffett]]`
- ❌ `[[价值投资]]`（中文词汇） ❌ `[[ValueInvesting]]`（驼峰） ❌ `[[value_investing]]`（下划线）

### 中文名称的正确处理方式

- 写入 concept 页 frontmatter 的 `aliases` 字段
- concept 页正文第一行使用括号标注：「价值投资（Value Investing）」
- wikilink 始终用英文 slug

### 允许使用 wikilinks 的场景

- concept 页引用其他 concept/entity 页
- source 页引用 concept/entity 页
- synthesis 页引用 concept/source/entity 页

### 禁止使用 wikilinks 的场景

- 任何页面不得引用系统文件：`[[log]]` `[[index]]` `[[overview]]` `[[QUESTIONS]]`
- 任何页面不得引用 lint 报告：`[[outputs/lint-xxx]]`
- 任何页面不得以操作名称作为 wikilink：`[[ingest]]` `[[query]]` `[[reflect]]`
- log.md 内部记录使用纯文本路径（如 `wiki/sources/xxx.md`），不使用 wikilinks

---

## Wiki 语言规范

- Wiki 层（concept/entity/synthesis 页）统一用中文写作
- concept 页 title 字段使用中文主名称（图谱节点显示）
- 英文术语在 concept 页首次出现时括号标注：「注意力机制（Attention Mechanism）」
- 所有 slug（文件名）统一用英文小写连字符，不使用中文文件名
- aliases 字段覆盖中英文所有叫法

---

## Confidence 更新规则

| 来源数量 | Confidence | 处理方式 |
|---|---|---|
| 1 个来源 | low | 自动设置 |
| 3+ 个来源 | medium | 自动设置 |
| 5+ 个来源且无重大矛盾 | 候选 high | 向用户展示 Definition 和 Sources 列表，等待确认 |
| 用户明确回复「确认」或「ok」 | high | 才可设置 |

**注意**：个人写作（raw/personal/）不参与 source_count 计数

---

## Source Integrity Rules

- **re-ingest 规则**：若 lint 报告 ⚠ SOURCE MODIFIED，需重新摄入该文件并更新所有受影响的 concept/entity 页面，Evolution Log 记录「YYYY-MM-DD 来源更新：[[slug]] 哈希变更，内容已重新提取」
- 来源超过 2 年标注 `possibly_outdated: true`
- 矛盾来源必须在 source 页和 concept 页的 Contradictions 节显式记录，不得静默覆盖

---

## 系统文件隔离规则

以下文件的 frontmatter 必须含 `graph-excluded: true`，不参与 Obsidian 图谱：

- `wiki/log.md`
- `wiki/index.md`
- `wiki/overview.md`
- `wiki/QUESTIONS.md`
- `outputs/` 下所有文件

---

## 文档维护规则

当 CLAUDE.md 规则更新时，同步更新 USER_GUIDE.md 对应章节，确保两份文档一致。

---

## 模板文件

模板位于 `~/.workbuddy/skills/llm-wiki/templates/`，初始化知识库时复制到 `wiki/templates/`：

| 模板 | 用途 |
|---|---|
| `source-template.md` | 外部来源摘要页 |
| `personal-writing-template.md` | 个人写作来源页 |
| `concept-template.md` | 概念页（含 aliases, confidence, Evolution Log） |
| `entity-template.md` | 实体页 |
| `synthesis-template.md` | 综合分析页（含 Counter-evidence） |

---

## Redirect 文件处理

当读到 redirect 文件（内容为 `redirect: [[wiki/concepts/xxx]]`）时，跟随到目标页面读取实际内容，不把 redirect 文件当普通页面使用。
