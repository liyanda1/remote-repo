---
type: concept
title: "中文概念名"
date: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [wiki, wiki/concept]
source_count: 0
confidence: low
domain_volatility: medium
last_reviewed: YYYY-MM-DD
aliases: ["中文名", "English Name"]
---

## Definition

中文名（English Name）

<!-- 概念定义，一段话讲清楚是什么 -->

## Key Points

<!-- 3-5 个要点 -->

- 

## My Position

<!-- 个人立场，由个人写作 ingest 时填入，标注「个人认知」 -->

## Contradictions

<!-- 来源之间的分歧，若无则写「无」 -->

## Sources

<!-- 引用此概念的来源页面 wikilink 列表 -->

- [[source-slug]]

## Evolution Log

<!-- 每次更新此概念页时追加一条 -->
