---
type: synthesis
title: "{{title}}"
date: YYYY-MM-DD
tags: [wiki, wiki/synthesis]
source_count: 0
confidence: low
---

## Thesis

<!-- 核心论点 -->

## Evidence

<!-- 支撑论点的证据，每个追溯到 source 页 -->

- 

## Counter-evidence

<!-- Stage 0 反向检验结果：反驳证据 -->

## Synthesis

<!-- 综合分析结论 -->

## Confidence Notes

<!-- 置信度说明：哪些来源是 low/medium/high，有哪些不确定性 -->

## Limitations

<!-- 局限性，包括回音室风险标注 -->

## Sources

<!-- 引用的来源页面 wikilink 列表 -->

- [[source-slug]]
