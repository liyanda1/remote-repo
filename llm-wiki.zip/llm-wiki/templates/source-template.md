---
type: source-summary
title: "{{title}}"
date: YYYY-MM-DD
source_url: "{{url}}"
domain: "{{domain}}"
author: "{{author}}"
tags: [wiki, wiki/source]
processed: true
raw_file: "raw/articles/filename.md"
raw_sha256: "<64-char-hex>"
last_verified: YYYY-MM-DD
possibly_outdated: false
language: zh
canonical_source: ""
---

## Summary

<!-- 一段话概括这篇文章的核心内容 -->

## Key Points

<!-- 3-5 个关键要点 -->

- 

## Concepts Extracted

<!-- 本文涉及的概念，使用英文 slug wikilink -->

- [[concept-slug]]

## Entities Extracted

<!-- 本文涉及的实体，使用英文 slug wikilink -->

- [[entity-slug]]

## Contradictions

<!-- 与其他来源的分歧，若无则写「无」 -->

## My Notes

<!-- 个人补充笔记，可选 -->
