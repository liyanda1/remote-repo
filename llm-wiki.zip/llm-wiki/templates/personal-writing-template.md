---
type: personal-writing
title: "{{title}}"
date: YYYY-MM-DD
status: draft
topic_tags: []
confidence_at_writing: medium
superseded_by: ""
raw_file: "raw/personal/filename.md"
raw_sha256: "<64-char-hex>"
last_verified: YYYY-MM-DD
tags: [wiki, wiki/source]
processed: true
---

## Core Argument

<!-- 这篇文章的核心论点 -->

## Key Claims

<!-- 主要论点列表 -->

- 

## Evidence Referenced

<!-- 引用的外部来源，尝试建立 wikilinks -->

## Limitations

<!-- 自我审视的局限性 -->
