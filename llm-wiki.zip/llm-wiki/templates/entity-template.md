---
type: entity
title: "{{title}}"
date: YYYY-MM-DD
tags: [wiki, wiki/entity]
entity_type: person
aliases: []
---

## Description

<!-- 实体描述 -->

## Key Contributions

<!-- 主要贡献/特点 -->

- 

## Related Concepts

<!-- 相关概念 wikilink -->

- [[concept-slug]]

## Sources

<!-- 引用此实体的来源页面 wikilink 列表 -->

- [[source-slug]]
