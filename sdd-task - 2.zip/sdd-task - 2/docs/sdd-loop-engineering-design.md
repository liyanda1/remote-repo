# SDD + Loop Engineering 融合设计

> **核心理念**：你不应该再给 Agent 写分步指令，而应该设计一套让 Agent 自主迭代的循环系统。
> —— Peter Steinberger, OpenClaw 创始人, 2026.06

---

## 1. 什么是 Loop Engineering

Loop Engineering 是 2026 年 6 月正式命名的 AI Agent 工程范式。核心主张：

```
传统方式：人写 prompt → Agent 执行 → 人看结果 → 人再写 prompt → ...
Loop 方式：人定义目标 → Agent 自己执行→观察→评估→修正→再执行 → 直到达标
```

### 五要素骨架

| 要素 | 含义 | SDD 中的映射 |
|------|------|-------------|
| **Goal**（目标） | 可验证的结果定义 | 每个阶段的可量化产出标准 |
| **Context**（上下文） | 动态更新的信息窗口 | AR 目录文件 + compaction 插件 |
| **Tool**（工具） | Agent 可调用的能力 | 读写文件、运行测试、子 Agent |
| **Eval**（评估） | 判断产出质量的机制 | LLM 打分 / 测试通过 / 覆盖率检测 |
| **Termination**（停止） | 何时结束循环 | 达标 / 最大迭代 / 成本上限 |

### 三个高度

| 高度 | 描述 | 当前 SDD 处于 |
|------|------|-------------|
| 高度 1 | 手写代码 + 自动补全 | — |
| 高度 2 | 并行 Agent + 人 Prompt | **← SDD 当前状态（skill = 人的指令）** |
| 高度 3 | 循环驱动 Agent + 人只设计系统 | **← 目标状态** |

---

## 2. 变革：从线性指令到嵌套循环

### 当前 SDD 架构（高度 2）

```
人 → /sdd → router → requirements skill（人写的步骤）
                            ↓ Agent 逐条执行
                    → design skill（人写的步骤）
                            ↓ Agent 逐条执行
                    → develop skill（人写的步骤 + 子 Agent）
                            ↓ Agent 逐条执行
                    → review skill（人写的步骤）
                            ↓ Agent 逐条执行
                    → st skill（人写的步骤）
                            ↓ Agent 逐条执行
                    → 完成
```

**问题**：Agent 是执行者，人是编排者。质量依赖人写的指令是否完备。指令有遗漏 → Agent 产出有缺陷 → 需要人介入修正。

### 目标 SDD 架构（高度 3：Loop Engineering）

```
人 → 定义 Meta-Loop 参数：
        - 阶段序列：[req, design, develop, review, st]
        - 全局迭代上限：每阶段 5 次
        - 全局成本上限：$20
        - 全局质量标准：所有 Eval ≥ 80 分
        ↓
Meta-Loop 自动运行：
  FOR EACH phase:
    Phase-Loop:
      Goal: 产出符合质量标准的阶段文档/代码
      WHILE (Eval < 标准 AND 迭代 < 上限):
        Execute: Agent 执行本阶段工作
        Eval: 评估产出质量（LLM 打分/测试/覆盖率）
        IF 达标: BREAK → 下一阶段
        IF 不达标: Correct → 重试
      IF 达到上限仍未达标: Escalate → 人介入
```

**关键变化**：
- 人从"写指令"变成"定义目标+标准"
- Agent 从"执行者"变成"自驱动循环体"
- 质量由 Eval 机制保证，不依赖指令完备性

---

## 3. SDD Loop 架构全景

```
┌──────────────────────────────────────────────────────────────┐
│                    SDD Meta-Loop（外层）                      │
│                                                              │
│  Input: AR 编号、确认模式、全局参数                           │
│  Termination: 所有阶段通过 OR 成本超限 OR 阶段阻塞            │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  Phase 1: Requirements Loop                             │ │
│  │  Goal: srs.md 完整性 ≥ 90%, 澄清项 = 0                 │ │
│  │  Eval: LLM 语义评分 + TBD/TODO 检测                    │ │
│  │  Max Iter: 3                                           │ │
│  ├─────────────────────────────────────────────────────────┤ │
│  │  Phase 2: Design Loop                                  │ │
│  │  Goal: design.md 需求覆盖率 100%, 接口签名完整性 100%   │ │
│  │  Eval: 需求回溯 + 模板完整性检测                        │ │
│  │  Max Iter: 3                                           │ │
│  ├─────────────────────────────────────────────────────────┤ │
│  │  Phase 3: Develop Loop                                 │ │
│  │  Goal: tasks.md 所有 task 状态 = passing               │ │
│  │  ┌─────────────────────────────────────────────────┐   │ │
│  │  │  Inner Task Loop (TDD)                          │   │ │
│  │  │  Goal: 当前 task 测试通过                        │   │ │
│  │  │  Eval: 测试 exit code = 0                       │   │ │
│  │  │  Max Iter: 5 per task                           │   │ │
│  │  │  Red → Green → Refactor → (repeat if fail)      │   │ │
│  │  └─────────────────────────────────────────────────┘   │ │
│  ├─────────────────────────────────────────────────────────┤ │
│  │  Phase 4: Review Loop                                  │ │
│  │  Goal: S/D/C 三维全部 ≥ PASS 阈值                      │ │
│  │  Eval: 子 Agent 独立评分 + 人工确认                    │ │
│  │  Max Iter: 2（修复 → 重新审查）                        │ │
│  ├─────────────────────────────────────────────────────────┤ │
│  │  Phase 5: ST Loop                                      │ │
│  │  Goal: st-cases.md 所有用例通过                         │ │
│  │  Eval: 每个 case 的 expected = actual                   │ │
│  │  Max Iter: 3                                           │ │
│  └─────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

---

## 4. 每个阶段 Loop 的详细设计

### 4.1 Requirements Loop

```
LOOP requirements(AR):
  Goal = {
    completeness: ≥ 90%,      // srs.md 覆盖域知识的所有关键点
    resolved: 0,               // 无未解决的澄清项
    consistency: "pass"        // 无自相矛盾
  }
  
  MaxIter = 3
  
  FOR iteration IN [1..MaxIter]:
    // Execute
    IF iteration == 1:
      读取 AGENTS.md 域知识
      读取 specs/component-detail-design/ 已有 spec
      生成 srs.md 初稿
    ELSE:
      根据 Eval 反馈修正 srs.md
    
    // Eval
    score = LLM_Evaluate(srs.md, criteria={
      "域知识覆盖": "检查是否覆盖 AGENTS.md 中所有关键领域概念",
      "澄清完整": "检查是否还有 TBD/TODO/待澄清",
      "无矛盾": "检查需求之间是否存在冲突",
      "可测试": "检查每条需求是否可转化为测试用例"
    })
    
    // Decide
    IF score.meets(Goal):
      生成 tasks.md（从 srs.md 提取任务列表）
      RETURN {status: "pass", artifact: srs.md}
    
    IF score < Goal AND iteration == MaxIter:
      ESCALATE(score, feedback)  // 升级给人
      RETURN {status: "escalated"}
    
    // Continue loop with correction feedback
    feedback = score.detailed_feedback
```

**现有 skill 的迁移**：当前 `sdd-task-requirements/SKILL.md`（328 行）中的步骤变为：
- **步骤** → **Eval 的 feedback 修正策略**（Agent 迭代时参考）
- **模板** → **Goal 的输出格式约束**
- **Checklist** → **Eval 的检查项**

### 4.2 Design Loop

```
LOOP design(AR, srs.md):
  Goal = {
    coverage: 100%,             // 每条需求有对应设计
    interface_completeness: 100%, // 所有接口有签名
    template_completeness: "pass" // 所有章节存在
  }
  
  MaxIter = 3
  
  FOR iteration IN [1..MaxIter]:
    // Execute
    IF iteration == 1:
      读取 srs.md
      读取 design 模板（外置）
      生成 design.md 初稿
    ELSE:
      根据 Eval 反馈修正 design.md
    
    // Eval
    score = LLM_Evaluate(design.md, criteria={
      "需求回溯": "srs.md 的每条需求 → design.md 是否有对应设计",
      "接口完整性": "每个对外接口是否有签名、参数、返回值说明",
      "数据结构": "每个关键数据实体是否有字段定义",
      "模板完整性": "模板要求的章节是否都存在且非空",
      "可行性与一致性": "设计是否自洽且可实现"
    })
    
    // Decide
    IF score.meets(Goal):
      更新 tasks.md（设计阶段可能产生新 task）
      RETURN {status: "pass", artifact: design.md}
    
    IF score < Goal AND iteration == MaxIter:
      ESCALATE(score, feedback)
      RETURN {status: "escalated"}
```

### 4.3 Develop Loop（含 TDD 内层循环）

```
LOOP develop(AR, design.md, tasks.md):
  Goal = {
    all_tasks_passing: true     // tasks.md 中所有 task 状态 = passing
  }
  
  MaxIter = 1  // develop 不整体重试，而是 task 级别重试
  
  FOR EACH task IN tasks.md:
    IF task.status == "pending":
      result = INNER_TDD_LOOP(task, design.md)
      IF result == "fail":
        ESCALATE(task, "TDD loop exhausted")
        RETURN {status: "escalated"}
  
  RETURN {status: "pass"}
```

**TDD 内层循环**：

```
INNER_TDD_LOOP(task, design.md):
  Goal = {
    tests_pass: true,           // 测试 exit code = 0
    coverage: ≥ 阈值             // 代码覆盖率（若有工具）
  }
  
  MaxIter = 5
  
  FOR iteration IN [1..MaxIter]:
    // Red Phase
    IF iteration == 1:
      派发 TDD-Test 子 Agent 写测试
      运行测试 → 期望失败（Red）
    // (后续迭代中，测试已在，只修改实现)
    
    // Green Phase
    主 Agent 写/修改实现代码
    运行测试 → 期望通过（Green）
    
    // Eval
    test_result = run_tests()
    
    IF test_result.passed:
      // Refactor Phase
      重构代码（保持测试通过）
      更新 tasks.md（mark task as passing）
      RETURN "pass"
    
    IF NOT test_result.passed AND iteration < MaxIter:
      // 分析失败原因，修正实现
      feedback = test_result.failure_details
      CONTINUE  // → Green Phase with feedback
    
    // MaxIter exhausted
    RETURN "fail"
```

### 4.4 Review Loop

```
LOOP review(AR, tasks.md):
  Goal = {
    spec_compliance: "pass",    // S 维度：符合 srs.md + design.md
    design_conformance: "pass", // D 维度：实现符合设计
    code_quality: "pass"        // C 维度：代码质量达标
  }
  
  MaxIter = 2  // 一次审查 + 一次修复后重新审查
  
  FOR iteration IN [1..MaxIter]:
    // Execute
    派发 sdd-reviewer 子 Agent
    子 Agent 对 S/D/C 三维独立打分
    
    // Eval
    results = {
      S: sub_agent_score("spec_compliance"),
      D: sub_agent_score("design_conformance"),
      C: sub_agent_score("code_quality")
    }
    
    // Decide
    IF results.all_pass:
      RETURN {status: "pass"}
    
    IF iteration == 1 AND results.has_issues:
      // 有可修复的问题 → 修复后重新审查
      主 Agent 根据审查意见修复代码
      CONTINUE
    
    IF iteration == MaxIter:
      // 仍有问题 → 升级
      ESCALATE(results)
      RETURN {status: "escalated"}
```

### 4.5 ST Loop

```
LOOP st(AR, tasks.md):
  Goal = {
    all_cases_pass: true,       // st-cases.md 所有用例通过
    critical_cases: 100%        // 关键用例 100% 通过
  }
  
  MaxIter = 3
  
  FOR iteration IN [1..MaxIter]:
    // Execute
    IF iteration == 1:
      生成 st-cases.md（基于 srs.md + design.md）
      运行全部 ST 用例
    ELSE:
      对失败用例修复代码
      重新运行失败用例
    
    // Eval
    运行 st-cases.md 中所有测试
    results = 每个用例的 expected vs actual
    
    // Decide
    IF results.all_pass:
      归档：specs/changes/ARxxx/ → specs/archive/ARxxx/
      RETURN {status: "pass"}
    
    IF iteration == MaxIter:
      ESCALATE(results)
      RETURN {status: "escalated"}
```

---

## 5. Meta-Loop：全局编排器

Meta-Loop 管理所有 Phase Loop 的执行顺序、状态传递和异常处理。

```
META_LOOP(AR, config):
  GlobalConfig = {
    max_total_cost: $20,
    max_phase_iter: 5,
    escalation_behavior: "pause",  // or "skip", "abort"
    quality_threshold: 80,         // 最低质量标准（百分制）
    confirm_mode: "per-phase"      // auto | per-phase | per-loop
  }
  
  phases = [requirements, design, develop, review, st]
  
  FOR EACH phase IN phases:
    // Pre-check
    IF phase blocked by missing dependency:
      ESCALATE("Phase {phase} blocked: missing {dependency}")
      IF confirm_mode == "auto": SKIP
      ELSE: WAIT for human input
    
    // Run phase loop
    result = phase_loop(phase, AR, GlobalConfig)
    
    // Post-check
    IF result.status == "escalated":
      IF confirm_mode == "auto":
        LOG("Phase {phase} escalated, continuing")
        IF phase is critical (design/develop): RETURN "abort"
        CONTINUE
      ELSE:
        WAIT for human decision: retry | skip | abort
    
    IF confirm_mode == "per-phase":
      ASK human: "Phase {phase} complete. Continue to {next_phase}?"
    
    // Check cost
    IF accumulated_cost > GlobalConfig.max_total_cost:
      RETURN {status: "cost_limit", progress: completed_phases}
  
  RETURN {status: "complete", all_phases: completed_phases}
```

---

## 6. 现有 Skill 的迁移路径

**不是废弃现有 6 个 Skill，而是"提升"它们的角色**：

```
当前：Skill = 线性指令集（Agent 照做）
       ↓
目标：Skill = {
  Goal 定义（Agent 追求的目标）,
  Eval 标准（如何判断是否达标）,
  Correction Strategies（不达标时的修正策略，来自原步骤）,
  Termination 条件（何时停止）
}
```

| 现有 Skill | 当前角色 | 新角色（Loop 模式） |
|-----------|---------|-------------------|
| sdd-router | 分发器 | **Meta-Loop 编排器** |
| sdd-task-requirements | 步骤指令 | **Requirements Loop**（Goal + Eval + 修正策略） |
| sdd-task-design | 步骤指令 | **Design Loop**（Goal + Eval + 修正策略） |
| sdd-task-develop | 步骤指令 + TDD | **Develop Loop**（含 TDD Inner Loop） |
| sdd-task-review | 步骤指令 + 子 Agent | **Review Loop**（含子 Agent 评估） |
| sdd-task-st | 步骤指令 | **ST Loop**（用例驱动的验收循环） |

### 现有步骤的价值

当前的详细步骤不会消失，而是成为 **Correction Strategies（修正策略）**：
- 当 Eval 判定某项不达标时，Agent 参考对应的修正策略来改进
- 步骤从"必须执行的流程"变成"按需查阅的参考"

### 现有模板的价值

模板成为 **Goal 的输出格式约束**，确保 Agent 在达到质量标准的同时也符合格式规范。

---

## 7. 与确认模式的融合

之前设计的 3 种确认模式（auto / per-task / per-stage）在 Loop 架构中升华为：

| Loop 确认模式 | 含义 |
|-------------|------|
| **auto** | Meta-Loop 自动运行所有阶段，只在 Escalate 时暂停 |
| **per-phase** | 每个 Phase Loop 完成后暂停，等待人工确认 |
| **per-loop-iteration** | 每次循环迭代（Red/Green/Refactor 每个子步骤）后暂停 |

这是对原确认模式的自然扩展：把确认粒度从"Task 级"扩展到"Loop 迭代级"，实现更精细的控制。

---

## 8. 与 sdd-compaction.js 插件的协同

Loop Engineering 下，compaction 变得更加重要：

- **循环级压缩**：每次 Loop 迭代完成后主动压缩，只保留 Goal + Eval 结果 + 关键决策
- **上下文窗口管理**：每个 Phase Loop 启动时自动清理上一阶段的冗余上下文
- **决策链记录**：Eval 的结果和修正策略作为"关键决策"注入压缩上下文

```
compaction 触发时机（Loop 模式）：
  ─ 每个 Phase Loop 结束时
  ─ TDD Inner Loop 每 5 次迭代后
  ─ Meta-Loop 阶段切换时
  ─ context 超限时（自动触发，原有机制）
```

---

## 9. Loop Engineering 收益量化

| 维度 | 当前 SDD | Loop SDD | 提升 |
|------|---------|----------|------|
| 人介入次数 | 每个阶段 1-3 次 | 只在不达标/超标时介入 | **减少 60-80%** |
| 质量保证 | 依赖指令完备性 | Eval 机制自动保证 | **系统性提升** |
| 迭代成本 | 人发现问题→重新发起 | Agent 自检自修 | **减少 3-5 轮人机交互** |
| 长任务稳定性 | context 超限后失忆 | Loop + compaction 保持状态 | **大幅提升** |
| 技能维护成本 | 每次优化要改细节步骤 | 只调整 Goal 和 Eval 标准 | **降低 50%** |

---

## 10. 风险和缓解

| 风险 | 缓解措施 |
|------|---------|
| Token 消耗增加 | 每层 Loop 设 MaxIter + Token 预算；Eval 用轻量模型 |
| Eval 不可靠 | 多维度 Eval + 关键节点人工校验；不使用单一 LLM 评估 |
| 死循环 | 严格的 Termination 条件 + 超时 + 成本上限三重保护 |
| 原有步骤丢失 | 步骤转为 Correction Strategy 引用，不删除 |
| 用户不信任自动循环 | confirm_mode 可选 auto 或 per-phase，渐进式信任建立 |

---

## 11. 实施路线图

> **状态：全部完成（2026-07-01）** ✅

### Phase A：Eval 基础设施 ✅

优先构建评估机制，因为它是整个 Loop 架构的核心。

- ✅ 设计 Eval 协议：`lib/eval/protocol.md`（含 JSON Schema、评分规则、Escalation 标准）
- ✅ 实现 5 个阶段 Eval 模板：`requirements-eval.md`、`design-eval.md`、`develop-eval.md`、`review-eval.md`、`st-eval.md`
- ✅ Eval 执行器指南：`lib/eval/runner.md`

### Phase B：Router → Meta-Loop ✅

- ✅ 创建 `skills/sdd-meta-loop/SKILL.md`（263 行）：五层嵌套循环编排器
- ✅ sdd-router 新增模式选择：AskUserQuestion 询问 Classic / Loop
- ✅ GlobalConfig 内存参数（不依赖外部文件）
- ✅ Escalation 升级逻辑

### Phase C：阶段 Skill Loop 化 ✅

逐个阶段改造，从简到难：

1. ✅ **ST Loop**（最简单）— Step 6a：Go/No-Go 结果格式化为 Eval JSON
2. ✅ **Review Loop**（中等）— Step 4d：审查结果 + Eval JSON 规范化
3. ✅ **Design Loop**（中等）— Step 8：子 Agent 独立 Eval + 重试/升级
4. ✅ **Requirements Loop**（中等）— Step 8：子 Agent 独立 Eval + 重试/升级
5. ✅ **Develop Loop**（最复杂）— Step 4d：Task级+阶段级 Eval，确定性+LLM 双模式

### Phase D：Compaction 协同升级 ✅

- ✅ sdd-compaction.js v1.1.0：Loop 模式检测改为 `eval/` 目录存在性判断（不依赖 `.loop-config.json`）
- ✅ 注入 Eval 历史记录（`eval/*.json` → Compact Markdown 表格）
- ✅ 注入 Loop 迭代状态（已完成阶段、当前阶段、最后 Eval 结果）
- ✅ 注入 Escalation 上下文（阻塞原因、推荐操作、修复成本估算）
- ✅ 非 Loop 项目透明（Classic 模式不受影响）

---

## 12. 总结

Loop Engineering 不是 SDD 的可选增强，而是**范式升级**：

| | 当前 SDD | Loop SDD |
|---|---|---|
| **人的角色** | 指令编写者 + 质量检查者 | 目标定义者 + 系统设计者 |
| **Agent 的角色** | 被动执行者 | 自主迭代者 |
| **质量模型** | "人觉得对不对" | "Eval 说达不达标" |
| **失败处理** | 人发现问题 → 重新发起 | Agent 自检 → 自修 → 重试 |
| **技能内容** | "第 1 步做什么，第 2 步做什么" | "目标是什么，怎么判断达标" |

**核心理念**：**把 SDD 从一个"人类写好的剧本"变成一个"Agent 自导自演的闭环"**。人不再需要出现在每一个决策点，而只需要定义好舞台（目标）、灯光（评估）和谢幕条件（停止标准）。
