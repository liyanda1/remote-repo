# HarnessX 框架优化分析报告

> 基于 2026 年 AI 编程 Agent 范式，对当前 HarnessX 框架的现状评估与优化建议。
> 
> 日期：2026-07-01

---

## 一、当前工程现状

### 1.1 架构总览

```
sdd-task - 2/
├── skills/                          # 6 个 WorkBuddy Skill（1936 行）
│   ├── sdd-router/SKILL.md          # 140 行 — 阶段检测与路由
│   ├── sdd-task-requirements/SKILL.md # 328 行 — 需求准备与澄清
│   ├── sdd-task-design/SKILL.md     # 325 行 — AR 详细设计
│   ├── sdd-task-develop/SKILL.md    # 440 行 — TDD 双 Agent 开发
│   ├── sdd-task-review/SKILL.md     # 390 行 — S/D/C 三维合规审查
│   └── sdd-task-st/SKILL.md         # 313 行 — ST 验收测试与归档
│
├── plugins/                         # 2 个 OpenCode 插件
│   ├── sdd-task.js                  # 原有 bootstrap 插件
│   └── sdd-compaction.js            # 上下文压缩增强（2026-05-23 新增）
│
├── agents/                          # 2 个 OpenCode Agent 定义
│   ├── sdd-build.md                 # 主流程代理
│   └── sdd-reviewer.md              # 只读审查子代理
│
├── commands/                        # 7 个 Slash Command
│   ├── sdd.md                       # 主入口（自动路由）
│   ├── sdd-req.md                   # 需求阶段直连
│   ├── sdd-design.md                # 设计阶段直连
│   ├── sdd-dev.md                   # 开发阶段直连
│   ├── sdd-review.md                # 审查阶段直连
│   ├── sdd-st.md                    # ST 阶段直连
│   └── sdd-reactivate.md            # 归档 AR 返工
│
└── docs/                            # 设计文档
    ├── sdd-loop-engineering-design.md  # Loop Engineering 融合设计
    ├── sdd-optimization-analysis.md     # 优化分析（本文档）
    └── sdd-compaction-plugin.md         # 压缩插件说明
```

### 1.2 六阶段流程

```
requirements → design → develop → review → ST → archive
    328行        325行     440行      390行   313行
```

### 1.3 已有的优化成果

| 日期 | 优化项 | 状态 |
|------|--------|------|
| 2026-04-18 | OpenCode 三维适配（commands/agents/plugins） | ✅ |
| 2026-04-22 | skill-creator OpenCode 适配 | ✅ |
| 2026-05-17 | 高优 Bug 修复（long-task-guide.md / PowerShell 混写） | ✅ |
| 2026-05-23 | TDD 双 Agent 重构（Red/Green 分离 + 确认粒度） | ✅ |
| 2026-05-23 | sdd-compaction.js 上下文压缩插件 | ✅ |

---

## 二、2026 年 AI 编码 Agent 核心范式

### 2.1 五大范式转变

| 范式 | 2024-2025（旧） | 2026（新） | HarnessX 框架对齐度 |
|------|----------------|-----------|--------------|
| **1. 上下文管理** | 迷信大窗口，能塞的都塞 | **上下文工程**：AGENTS.md、rules、memories、skills、subagents、hooks 构建可复用工程上下文 | ⚠️ 部分对齐（有 compaction 但缺少 RAG） |
| **2. 任务委派** | Agent 写代码 | **任务委派**：像发 issue 一样发任务，有验收标准、边界、权限 | ⚠️ 部分对齐（有 tasks.md 但缺少子 Agent 编排层） |
| **3. 工具治理** | 能跑就行 | **MCP 基础设施**：按需加载、最小权限、可审计、可回滚 | ❌ 未引入 MCP |
| **4. 安全边界** | 次要因素 | **产品竞争力**：沙箱、权限、审计、策略下发 | ❌ 无安全治理层 |
| **5. 评估体系** | 靠感觉判断 | **工程化评估**：evals、回归测试、质量门禁持续验证 | ❌ skill-guard 提及但未集成 |

### 2.2 关键洞察

> "2026 年选 AI 编程工具，不再是问「哪个模型最强」，而是问「哪套 Agent 工作流最适合我的代码库、预算和风险边界」。"

> "高质量 AI 编程工作流的三个共同点：任务写得像 issue、权限给得像生产系统、结果审得像新人提交的 PR。"

> "上下文工程取代无限上下文迷信：把一次性的聊天 prompt，沉淀为可复用的工程上下文。"

---

## 三、差距分析

### 3.1 结构性问题

| 问题 | 严重度 | 现状 | 影响 |
|------|--------|------|------|
| **Skill 臃肿** | P1 | 6 个 skill 共 1936 行，平均 323 行；develop 达 440 行 | 加载后占大量上下文，留给实际工作的空间不足 |
| **模板内嵌** | P1 | srs/tasks/design/st-cases 等模板 ~165 行直接写在 skill 中 | 每次加载 skill 都重复读取模板，浪费 token |
| **子 Agent prompt 重复** | P1 | review 中单模型/多模型 prompt 有 ~170 行重复 | 维护成本高，修改一个要同步改另一个 |
| **无评估框架** | P0 | skill-guard 在用户规划中但未集成到工程 | skills 修改后无法回归验证 |
| **无业务知识图谱** | P1 | 用户在记忆中提到 RAG+向量检索但未实现 | 大代码库场景下 AI 难以理解业务全貌 |
| **硬编码路由** | P2 | sdd-router 用硬编码文件检测（existsSync），而非可配置规则 | 新增文件类型或调整阶段逻辑需改代码 |
| **OpenCode 强耦合** | P2 | Skill 中大量引用 OpenCode 内部概念（AskUserQuestion、TodoWrite） | 移植到其他平台（Claude Code、Codex）成本高 |

### 3.2 架构灵活性不足

| 维度 | 当前 | 2026 范式期望 |
|------|------|-------------|
| 需求来源 | 手动用户问答（sdd-task-requirements） | 可从 Jira/Issue 自动拉取需求 |
| 测试执行 | 依赖 AGENTS.md 硬编码命令 | 可接入 CI/CD 管线自动反馈 |
| 审查模型 | 硬编码 opencode.json review.models 配置 | 可动态选择审查策略（轻量/深度/安全） |
| 归档 | 本地文件系统 cp/rm | 可推送至文档平台（如通过 MCP） |
| 上下文压缩 | 被动触发（compaction hook） | 可在阶段切换时主动触发 |

### 3.3 渐进式披露不足

回顾 2026-05-17 的分析结论（当时就指出过）：

> sdd-task-develop 最长（440 行），包含 Step 0 确认模式 + 3a/3b/3c TDD 循环 + 降级流程完整逻辑 + Agent prompt 模板 + 确认模式 × 测试可用性的分支矩阵

这个问题**至今未解决**：

- sdd-task-develop 从 ~300 行增长到 440 行（新增 Step 0 + 双 Agent 逻辑）
- sdd-task-review 的 S/D/C 审查维度 prompt 重复了 ~170 行
- 模板（srs/tasks/design/st-cases）合计 ~165 行直接嵌在 skill 中

**可立即减少的行数**：模板外置 ~165 行 + prompt 外置 ~170 行 = **~335 行**，约占总体的 17%。

---

## 四、优化建议（按优先级排列）

### P0：高回报、低成本（推荐立即执行）

#### 4.1 模板外置化

**做法**：创建 `specs/templates/` 目录，存放所有模板文件

```
specs/templates/
├── srs-template.md          # srs.md 模板（从 sdd-task-requirements 移出）
├── tasks-template.md        # tasks.md 模板
├── design-template.md       # design.md 默认模板（从 sdd-task-design 移出）
└── st-cases-template.md     # st-cases.md 模板（从 sdd-task-st 移出）
```

**改动量**：在 4 个 skill 中将内嵌模板替换为 `读取 specs/templates/xxx-template.md` 引用

**收益**：
- 减少 skill 约 165 行（模板代码）
- 模板可独立版本管理、评审、部门定制
- 部门提供 design.md 模板时，直接替换 `specs/templates/design-template.md` 即可

#### 4.2 子 Agent Prompt 外置化

**做法**：创建 `.opencode/prompts/` 目录存放审查 prompt

```
.opencode/prompts/
├── review-single-model.md   # 单模型审查 prompt 模板
└── review-multi-model.md    # 多模型审查 prompt 模板
```

**改动量**：在 sdd-task-review 中将内嵌 prompt 替换为读取引用

**收益**：
- 减少 skill 约 170 行（重复 prompt）
- 审查维度可独立调整，不频繁修改 skill 主流程

#### 4.3 Skill 评估框架（skill-guard 集成）

**做法**：在当前工程中集成 skill-guard 评估框架

```
skill-guard/
├── evals/
│   ├── sdd-router/
│   │   └── phase-detection.eval.md
│   ├── sdd-task-develop/
│   │   ├── tdd-red-green.eval.md
│   │   └── confirm-mode.eval.md
│   └── sdd-task-review/
│       └── sdc-compliance.eval.md
├── run_eval.py              # 评估运行脚本
└── config.yaml              # 评估配置
```

**收益**：
- 每次修改 skill 后自动验证核心流程
- 防止 skill 优化引入回归
- 可与 CI 集成，PR 时自动运行

---

### P1：中等回报、中等成本

#### 4.4 业务知识图谱（RAG + 向量检索）

**做法**：在 sdd-task-requirements 和 sdd-task-design 阶段注入业务知识

```
知识图谱结构：
组件详设（specs/component-detail-design/）
  ↓ 解析 → 模块描述、接口签名、数据结构
AGENTS.md
  ↓ 解析 → 开发规范、测试框架、构建命令
已归档 AR（specs/archive/）
  ↓ 解析 → 历史设计决策、常见模式、已知约束
```

**实现方式**：
1. 在 compaction 插件中增加 RAG 检索能力（读取 archive 中的历史 AR）
2. 或：创建独立的 `.opencode/knowledge/` 目录，存储结构化领域知识摘要
3. skills 在加载时读取知识摘要而非完整详设文档

**收益**：
- 大代码库场景下，AI 能快速理解业务全貌
- 历史设计决策可被新 AR 复用
- 减少每次会话"重建领域知识"的上下文消耗

#### 4.5 阶段切换主动压缩

**做法**：在 sdd-router 或各阶段 skill 结束时，主动触发 compaction

当前状态：sdd-compaction.js 只在 token 超限时被动触发

改进：
```javascript
// 在每个阶段 skill 的"移交"步骤中增加钩子
// 例如 sdd-task-design Step 8 移交开发前：
// 可选：提醒用户执行 /compact 释放上下文
```

**收益**：
- 长流程中主动释放上下文，避免"阶段 3 才开始压缩，前 2 个阶段的工作丢失"
- 与 sdd-compaction.js 协同，压缩时保留关键阶段产出

#### 4.6 简化 sdd-task-develop 分支逻辑

**问题**：Step 3a/3b/3c 中有大量嵌套的"自动化 vs 降级 × 3 种确认模式"分支矩阵

**做法**：将确认模式和测试可用性的分支逻辑提取为简洁的规则表

```markdown
### 确认行为矩阵（引用）

| {confirm_mode} × {test_available} | Red 后 | Green 后 | Refactor 后 |
|-----------------------------------|--------|----------|------------|
| auto × true  | 自动进入 Green | 自动进入 Refactor | 自动下一 task |
| auto × false | 提示 + 继续 | 提示 + 继续 | 自动下一 task |
| per-task × * | 自动进入 Green | 确认后 Refactor | 确认后下一 task |
| per-stage × * | 确认后 Green | 确认后 Refactor | 确认后下一 task |

* 表示不区分 test_available
```

**收益**：减少 Step 3 约 40-60 行重复分支描述

---

### P2：战略级、高成本

#### 4.7 MCP 工具集成

**做法**：通过 MCP 连接工程工具链

| MCP Server | 作用 |
|-----------|------|
| Jira/Issue Tracker | AR 来源自动关联（需求溯源） |
| CI/CD | 测试执行状态自动反馈（无需用户手动确认 Red/Green） |
| 文档平台 | ST 通过后自动归档到知识库 |
| 代码仓库 | PR 创建、CR 流程集成 |

**收益**：流程自动化从"Agent 内部"扩展到"工程工具链"

#### 4.8 多 Agent 编排层

**做法**：创建 sdd-orchestrator skill，负责多 Agent 协调

```
sdd-orchestrator
├── 需求 Agent（sdd-task-requirements）
├── 设计 Agent（sdd-task-design）
├── 开发 Agent（sdd-task-develop + TDD-Test 子 Agent）
├── 审查 Agent（sdd-task-review，多模型并行）
└── 测试 Agent（sdd-task-st）
```

**收益**：
- 像"分配任务给不同的同事"而非"自己做完所有事"
- 符合 2026 年"任务委派"范式
- 每个 Agent 上下文更小、职责更聚焦

#### 4.9 平台无关抽象层

**做法**：将 Skill 中 OpenCode 特化指令（AskUserQuestion、TodoWrite、Agent 派发语法）抽象为通用 DSL

```markdown
## 平台适配层
- WorkBuddy: Skill 工具调用
- OpenCode: Command + Agent 配置
- Claude Code: CLAUDE.md 指令
```

**收益**：HarnessX 框架可移植到不同平台

---

## 五、实施路线图

```
第 1 周（P0，立即执行）✅ 已完成
├── ✅ 模板外置化          → specs/templates/{srs,tasks,design,st-cases}-template.md
├── ✅ 子 Agent Prompt 外置化 → .opencode/prompts/{review-dimensions,review-single-model,review-multi-model}.md
└── ⬜ Skill 评估框架集成   → 待规划

第 2 周（P1）
├── ⬜ 业务知识图谱方案设计
├── ⬜ 阶段切换主动压缩
└── ✅ 简化 sdd-task-develop 分支逻辑 → 确认行为矩阵替换嵌套分支描述

第 3 周+（P2，远期规划）
├── ⬜ MCP 工具集成调研
├── ⬜ 多 Agent 编排层设计
└── ⬜ 平台无关抽象层
```

> 实施日期：2026-07-01 | 实际减少：Skills 总行数从 1936 降至 1866（-70 行），剔除 Loop Engineering 新增内容后净减少约 270 行。

---

## 六、总结

### 当前框架的优势（保留）

| 优势 | 说明 |
|------|------|
| 结构化六阶段流程 | 需求→设计→开发→审查→ST→归档，流程清晰可追溯 |
| 双 Agent TDD | Red Agent 写测试 + 主 Agent 写实现，防止自我验证 |
| 灵活的确认粒度 | 全自动 / 按 task / 按阶段，适应不同用户需求 |
| 上下文压缩 | sdd-compaction.js 被动注入 SDD 领域上下文 |
| OpenCode 全适配 | commands/agents/plugins 三层适配 |
| 多模型审查 | S/D/C 三维 + 可配并行模型 |

### 需要优化的短板

| 短板 | 建议 | 优先级 | 状态 |
|------|------|--------|------|
| Skill 臃肿（模板内嵌） | 模板外置到 specs/templates/ | P0 | ✅ 已完成 |
| 子 Agent prompt 重复 | prompt 外置到 .opencode/prompts/ | P0 | ✅ 已完成 |
| 无评估回归 | 集成 skill-guard | P0 | ⬜ 待规划 |
| 无 RAG 知识图谱 | 知识提取 + 向量检索 | P1 | ⬜ |
| 缺乏 MCP 工具集成 | 连接 CI/CD、Jira 等 | P2 | ⬜ |
| 分支嵌套复杂 | 简化为规则表 | P1 | ✅ 已完成 |

### 核心判断

> HarnessX 框架已经是一个**工程设计良好**的 AI 编码流程框架，核心流程（六阶段 + TDD 双 Agent + 确认粒度）在 2026 年范式中属于**领先实践**。但 skill 的"渐进式披露"和"上下文效率"方面还有明显优化空间。P0 三项优化可以**立即实施**，在不改变核心流程的前提下减少约 335 行冗余内容。
