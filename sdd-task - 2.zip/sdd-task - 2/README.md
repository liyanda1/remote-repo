# HarnessX 框架

基于 IPD/SDD 规范的 **AI 辅助结构化开发流程框架**，将组件开发拆解为 5 个标准阶段，通过 Skill、Agent、Eval 三层机制实现自动化质量门禁和持续交付。

---

## 目录

- [1. 项目概述](#1-项目概述)
- [2. 核心架构](#2-核心架构)
- [3. 运行模式](#3-运行模式)
- [4. 组件详解](#4-组件详解)
  - [4.1 Skills（技能）](#41-skills技能)
  - [4.2 Eval 评估基础设施](#42-eval-评估基础设施)
  - [4.3 Commands（命令入口）](#43-commands命令入口)
  - [4.4 Agents（代理）](#44-agents代理)
  - [4.5 Plugins（插件）](#45-plugins插件)
  - [4.6 Templates（模板）](#46-templates模板)
  - [4.7 References（参考文件）](#47-references参考文件)
- [5. 开发流程详解](#5-开发流程详解)
  - [5.1 阶段 1：Requirements（需求澄清）](#51-阶段-1requirements需求澄清)
  - [5.2 阶段 2：Design（详细设计）](#52-阶段-2design详细设计)
  - [5.3 阶段 3：Develop（TDD 开发）](#53-阶段-3developtdd-开发)
  - [5.4 阶段 4：Review（三维审查）](#54-阶段-4review三维审查)
  - [5.5 阶段 5：ST（验收测试 + 归档）](#55-阶段-5st验收测试--归档)
- [6. TDD 双 Agent 防自欺机制](#6-tdd-双-agent-防自欺机制)
- [7. Eval 质量门禁](#7-eval-质量门禁)
- [8. 部署指南](#8-部署指南)
- [9. 快速开始](#9-快速开始)
- [10. 目录结构](#10-目录结构)
- [11. 约定与规范](#11-约定与规范)

---

## 1. 项目概述

### 背景

大型组件的 AI 辅助开发面临以下挑战：

| 挑战 | 表现 | HarnessX 解决方案 |
|------|------|-------------|
| 上下文爆炸 | 多轮对话超出 Token 限制 | 分阶段 Skill + Compaction 插件 |
| 质量失控 | AI 生成代码未经验证 | TDD 双 Agent + Eval 质量门禁 |
| 流程不一致 | 不同开发者不同习惯 | 标准化 5 阶段 + 模板驱动 |
| 自欺审查 | 写代码的 Agent 也写测试 | Red Agent（独立）写测试，Green Agent 写实现 |
| 无法回归 | 修改代码导致已修复问题重现 | Eval 自动回归评分 |

### 设计目标

- **规范化**：符合部门 IPD/SDD 规范，每个 AR 从需求到归档有标准路径
- **自动化**：Loop 模式下全流程无人干预（仅在 Escalate 时介入）
- **可验证**：每个阶段产出物有明确的 Eval 评分标准
- **可移植**：一键部署到任一组件工程，支持 Windows 和 Linux

### 运行环境

- **平台**：OpenCode（华为内部 AI 开发平台）
- **系统**：Windows 11（开发）/ Linux（远端构建）
- **语言支持**：C/C++（主），可通过模板扩展其他语言

---

## 2. 核心架构

HarnessX 框架采用 **五层嵌套循环架构**，从外到内：

```
/sdd（入口命令）
  └─ sdd-router（模式分发）
       ├─ Classic 模式：线性逐阶段分发
       └─ Loop 模式 → sdd-meta-loop（Meta Loop 层）
            └─ FOR EACH phase（Phase Loop 层）
                 ├─ invoke_phase_skill → 阶段 Skill 执行
                 │    ├─ requirements → srs.md + tasks.md
                 │    ├─ design       → design.md（8 章节）
                 │    ├─ develop      → TDD 双 Agent（Task Loop 层）
                 │    │    └─ FOR EACH task:
                 │    │         Red(独立Agent写测试) → Green(主Agent写实现) → Refactor
                 │    ├─ review       → S/D/C 三维审查（子 Agent）
                 │    └─ st           → st-cases.md + 归档
                 ├─ run_eval（Eval Loop 层）
                 │    └─ pass → next | fail+retry → 修正 | fail×3 → Escalate
                 └─ save_eval_result → eval/ 目录
  └─ sdd-compaction.js（始终运行：上下文压缩时注入 HarnessX 关键信息）
```

### 架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                        HarnessX 框架五层架构                           │
├─────────────────────────────────────────────────────────────────┤
│  L1: Meta Loop (sdd-meta-loop)                                  │
│      FOR phase IN [req, design, develop, review, st]            │
│      ├── 阶段成功 → 下一阶段                                     │
│      ├── Eval 失败 + 有余量 → 重试（最多 3 次）                   │
│      └── 迭代用尽 → Escalate 给人                                │
├─────────────────────────────────────────────────────────────────┤
│  L2: Phase Loop (阶段 Skill)                                     │
│      sdd-task-requirements / design / develop / review / st     │
│      每个 Skill 内部有独立的质量自检步骤                           │
├─────────────────────────────────────────────────────────────────┤
│  L3: Task Loop (develop 内)                                      │
│      FOR EACH task IN tasks.md:                                 │
│      Red(子Agent) → Green(主Agent) → Refactor                    │
├─────────────────────────────────────────────────────────────────┤
│  L4: Eval Loop (lib/eval/)                                       │
│      子 Agent 独立运行评估 → JSON 结果 → score >= 80 达标         │
├─────────────────────────────────────────────────────────────────┤
│  L5: Compaction Hook (sdd-compaction.js)                        │
│      上下文压缩时自动注入 HarnessX 领域上下文                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. 运行模式

### 3.1 Classic 模式

传统线性分发，Router 检测 `specs/changes/ARxxx/` 目录的文件存在性，自动分发到对应阶段 Skill。每个阶段完成后需要人工确认。

**适用场景**：需要逐阶段精细控制，或调试某个特定阶段。

### 3.2 Loop 模式（推荐）

Meta-Loop 完全自动驱动所有 5 个阶段，每阶段完成后 Eval 自评质量：

- **达标（score >= 80）**：自动进入下一阶段
- **未达标 + 有迭代余量**：自动重试修正（每阶段最多 3 次）
- **迭代用尽**：Escalate，暂停请求人工介入

**人只在 Escalate 时介入**，正常流程完全自动化。

---

## 4. 组件详解

### 4.1 Skills（技能）

Skills 是 HarnessX 框架的核心执行单元，位于 `skills/` 目录，共 7 个：

| Skill | 文件 | 职责 |
|-------|------|------|
| `sdd-router` | `skills/sdd-router/SKILL.md` | 入口路由器：检测 AR 目录状态 → 分发到对应阶段 Skill |
| `sdd-task-requirements` | `skills/sdd-task-requirements/SKILL.md` | 需求澄清：读组件详设 → 交互澄清 → 生成 srs.md + tasks.md |
| `sdd-task-design` | `skills/sdd-task-design/SKILL.md` | 详细设计：基于 srs.md 生成 design.md（8 章节） |
| `sdd-task-develop` | `skills/sdd-task-develop/SKILL.md` | TDD 开发：逐任务实现（Red → Green → Refactor） |
| `sdd-task-review` | `skills/sdd-task-review/SKILL.md` | 审查：派发子 Agent 进行 S/D/C 三维合规性检查 |
| `sdd-task-st` | `skills/sdd-task-st/SKILL.md` | 验收测试：生成 st-cases.md → 执行 ST → 归档 |
| `sdd-meta-loop` | `skills/sdd-meta-loop/SKILL.md` | Loop 模式编排器：驱动阶段流转 + Eval + 迭代控制 |

### 4.2 Eval 评估基础设施

位于 `lib/eval/`，是 Loop 模式的质量门禁系统，共 7 个文件：

| 文件 | 对应阶段 | 评估方式 | 核心指标 | 达标阈值 |
|------|---------|---------|---------|---------|
| `protocol.md` | 通用 | — | Eval JSON 格式规范 | — |
| `requirements-eval.md` | Requirements | LLM | 域知识覆盖 / 澄清完整性 / 一致性 / 可测试性 | ≥80 |
| `design-eval.md` | Design | LLM | 需求回溯 / 接口签名 / 边界覆盖 / 模板完整性 | ≥80 |
| `develop-eval.md` | Develop | 确定性+LLM | Task Eval(测试通过) + Phase Eval(综合质量) | ≥80 |
| `review-eval.md` | Review | 子 Agent | S1-S5 / D1-D4 / C1-C3 YES-NO 判分 | ≥80 |
| `st-eval.md` | ST | 确定性 | 需求覆盖 / 回归 / 用例通过率 / 缺陷严重性 | ≥80 |
| `runner.md` | 通用 | — | Eval 子 Agent 派发执行器 | — |

**Eval JSON 输出格式**（`protocol.md` 定义）：

```json
{
  "phase": "requirements|design|develop|review|st",
  "iteration": 1,
  "overall": "pass|fail",
  "score": 85,
  "dimensions": [
    { "name": "维度名", "pass": true, "score": 90, "weight": 0.3, ... }
  ],
  "blocking_issues": [],
  "recommendation": "next|retry|escalate"
}
```

### 4.3 Commands（命令入口）

位于 `commands/`，部署到组件工程的 `.opencode/commands/`，提供 7 个 slash command：

| 命令 | 功能 | 用法 |
|------|------|------|
| `/sdd` | 主入口（自动路由 + 模式选择） | `/sdd` |
| `/sdd-req` | 直连需求阶段 | `/sdd-req` |
| `/sdd-design` | 直连设计阶段 | `/sdd-design` |
| `/sdd-dev` | 直连开发阶段 | `/sdd-dev [任务ID]` |
| `/sdd-review` | 直连审查阶段 | `/sdd-review` |
| `/sdd-st` | 直连验收阶段 | `/sdd-st` |
| `/sdd-reactivate` | 恢复中断的流程 | `/sdd-reactivate` |

### 4.4 Agents（代理）

位于 `agents/`，部署到组件工程的 `.opencode/agents/`，共 2 个：

| Agent | 类型 | 权限 | 用途 |
|-------|------|------|------|
| `@sdd-build` | primary | 全工具 + sdd-* skill allow | 主流程代理，执行开发/设计/需求等任务 |
| `@sdd-reviewer` | subagent | 只读（全工具关闭） | 审查子代理，用于 S/D/C 三维审查 |

### 4.5 Plugins（插件）

| 文件 | 用途 |
|------|------|
| `plugins/sdd-compaction.js` | 上下文压缩钩子：OpenCode compaction 时自动注入 HarnessX 领域上下文 |
| `plugins/sdd-task.js` | 任务跟踪辅助插件 |

**sdd-compaction.js 工作机制**：

- **触发时机**：OpenCode 上下文窗口接近上限时自动触发 `experimental.session.compacting` 钩子
- **追加模式**：在系统压缩后，自动向上下文追加关键信息（当前阶段、AR 编号、产出文件路径、Eval 状态）
- **Loop 感知**：通过 `eval/` 目录存在性感知当前是 Loop 模式，追加对应的 Loop 上下文

### 4.6 Templates（模板）

位于 `specs/templates/`，部署到组件工程的 `specs/templates/`，共 4 个：

| 模板 | 使用者 | 用途 |
|------|--------|------|
| `srs-template.md` | sdd-task-requirements | 需求设计说明书模板 |
| `tasks-template.md` | sdd-task-requirements | 任务跟踪表模板 |
| `design-template.md` | sdd-task-design | 详细设计文档模板（8 章节） |
| `st-cases-template.md` | sdd-task-st | ST 验收测试用例模板 |

### 4.7 References（参考文件）

位于 `lib/references/`，存放各 Skill 中体积大、不总是需要加载到常驻 context 的参考性内容。Agent 执行到对应步骤时按需读取。

| 文件 | 所属 Skill | 内容 |
|------|------------|------|
| `sdd-task-develop/tdd-test-prompt.md` | sdd-task-develop | TDD-Test 子 Agent prompt 模板 |
| `sdd-task-develop/confirm-matrix.md` | sdd-task-develop | 确认行为矩阵（confirm_mode × test_available） |
| `sdd-task-develop/error-handling.md` | sdd-task-develop | 调试规范 + 返工流程 + 红旗警告 |
| `sdd-task-design/plantuml-guide.md` | sdd-task-design | PlantUML 图表规范（含语法速查） |

**路径解析**：Agent 先查找本地 `lib/references/`，找不到则回退到全局 `~/.config/opencode/lib/references/`。

---

## 5. 开发流程详解

### 5.1 阶段 1：Requirements（需求澄清）

```
读取 AGENTS.md（如有）
  → 读取 specs/component-detail-design/组件_spec.md（领域知识）
  → 逐功能需求交互澄清（AskUserQuestion）
  → 生成 srs.md（使用 specs/templates/srs-template.md）
  → 从 srs.md 提取任务到 tasks.md（使用 specs/templates/tasks-template.md）
  → [Loop] Eval：域知识覆盖 / 澄清完整性 / 一致性 / 可测试性
```

**产出物**：`specs/changes/ARxxx-topic/srs.md` + `tasks.md`

### 5.2 阶段 2：Design（详细设计）

```
读取 srs.md + 组件详设 + CMakeLists.txt
  → 发现可复用组件接口
  → 提案 ≥2 个设计方案 + 推优
  → 生成 design.md（使用 specs/templates/design-template.md）
     ├── §1 设计概述
     ├── §2 模块影响分析
     ├── §3 接口设计
     ├── §4 核心算法/流程设计
     ├── §5 边界条件矩阵
     ├── §6 错误处理设计
     ├── §7 测试设计
     └── §8 设计决策记录
  → [Loop] Eval：需求回溯 / 接口签名 / 边界覆盖 / 模板完整性
```

**产出物**：`specs/changes/ARxxx-topic/design.md`

### 5.3 阶段 3：Develop（TDD 开发）

最复杂的阶段，实现 **TDD 双 Agent 防自欺机制**：

```
FOR EACH task IN tasks.md WHERE status = pending:
  ├─ 3a. Red：派发独立子 Agent 写测试
  │        └─ 主 Agent 运行测试 → 确认失败（Red 状态）
  ├─ 3b. Green：主 Agent 按 design.md 写最少实现代码
  │        └─ 运行测试 → 确认通过（Green 状态）
  └─ 3c. Refactor：在测试全绿的前提下重构
       └─ 消除重复、改善命名、拆分函数

确认模式（可通过 AskUserQuestion 切换）：
  auto    → 全程自动，不问用户
  per-task → 每个 task 完成后确认
  per-stage → 每个阶段（Red/Green/Refactor）完成后确认

[Loop] Task Eval（确定性：测试 pass 即过）+ Phase Eval（LLM 综合评分）
```

**产出物**：修改后的源码 + 测试文件 + `tasks.md` 状态更新

### 5.4 阶段 4：Review（三维审查）

```
派发子 Agent → 按 S/D/C 三维审查：
  ├─ S（需求符合性）：S1-S5（测试覆盖/行为验证/副作用/边界/错误处理）
  ├─ D（设计符合性）：D1-D4（签名/算法/影响范围/偏离记录）
  └─ C（组件规范符合性）：C1-C3（接口稳定性/架构/代码风格）

支持模式：
  - 单模型：1 个子 Agent，当前主模型审查
  - 多模型：N 个子 Agent 并行，多模型独立判断（交叉验证）

[Loop] Eval：按 YES/NO 判定计算加权得分
```

**产出物**：审查结论 + 问题列表

### 5.5 阶段 5：ST（验收测试 + 归档）

```
1. 就绪检查（所有 tasks passing，Review PASS）
2. 基于 srs.md 验收标准生成 st-cases.md
3. 执行 ST（自动化 + 集成 + 回归测试）
4. 缺陷分类（Critical/Major → 必须修复）
5. 生成 ST 报告 + Go/No-Go 决策
6. Go → 归档：
   specs/changes/ARxxx/ → specs/archive/ARxxx/
   （tasks.md 不归档）
```

**产出物**：`st-cases.md`（含报告） + 归档

---

## 6. TDD 双 Agent 防自欺机制

### 问题

单 Agent 模式下，Agent 既是"写测试的人"也是"写实现的人"，可能：
- 写"配合实现"的弱测试（只测 happy path）
- 实现只求"让测试过"，忽略边界条件
- 测试和实现在同一个上下文中互相影响

### 解决方案

```
Red Agent（独立子 Agent）           Green Agent（主 Agent）
        │                                   │
  只有 design.md + 需求                    有 design.md + Red 写的测试
  不知道实现代码                            不参与测试编写
        │                                   │
  写测试文件                                读测试文件
  定义测试意图                              写最少实现代码
        │                                   │
        └──────── 测试文件 ────────────────→  │
                                         运行测试
                                         确认 Green
```

**关键原则**：测试 Agent 和实现 Agent 是**独立上下文**，测试 Agent 没有看到实现代码，无法"配合实现写测试"。

### 确认粒度矩阵

| confirm_mode | test_available | Red 后 | Green 后 | Refactor 后 |
|-------------|-----------------|--------|----------|-------------|
| auto        | true            | 自动   | 自动     | 自动        |
| auto        | false           | 提示   | 提示     | 自动        |
| per-task    | *               | 自动   | 确认     | 确认        |
| per-stage   | *               | 确认   | 确认     | 确认        |

---

## 7. Eval 质量门禁

### 治理规则

| 规则 | 说明 |
|------|------|
| 评分阈值 | `score >= 80` → `overall: pass` |
| 加权计算 | `score = Σ(dimension.score × dimension.weight)` |
| 阻塞项 | 任一 `blocking_issues` 存在 → `overall: fail`（无论 score 多少） |
| 重试上限 | 每阶段最多 3 次迭代 |
| Escalation | 3 次迭代后仍未达标 → 暂停，输出问题摘要，等待人工介入 |
| 降级路径 | Escalation 后人工可选择：跳过（force-next）、修复后重试、放弃（abort） |

### 双重 Eval 机制

| 层级 | 执行者 | 目的 | 优先级 |
|------|--------|------|--------|
| Skill 级 Eval | 阶段 Skill 内部自查 | 快速发现明显问题，预过滤 | 低 |
| Meta-Loop Eval | Meta-Loop 独立派发子 Agent | 独立、权威的最终质量判定 | **高（最终仲裁）** |

Meta-Loop Eval 覆盖 Skill 级 Eval 的结果。两者互补不冲突：Skill 级发现的问题在 Meta-Loop 级会被重新评估。

---

## 8. 部署指南

HarnessX 框架支持**全局安装**（推荐）和**项目级安装**两种方式。

### 8.1 全局安装（推荐）

全局安装后，所有组件工程都能使用 HarnessX 框架，无需每个工程都复制一份。框架文件安装在 OpenCode 全局配置目录 `~/.config/opencode/` 下。

**Linux / macOS：**

```bash
# 克隆或下载 HarnessX 框架源码
git clone <sdd-repo-url> sdd-framework
cd sdd-framework

# 全局安装（安装到 ~/.config/opencode/）
bash deploy.sh
```

**Windows（PowerShell）：**

```powershell
# 克隆或下载 HarnessX 框架源码
git clone <sdd-repo-url> sdd-framework
cd sdd-framework

# 全局安装
.\deploy.ps1
```

**安装位置：**

```
~/.config/opencode/              ← OpenCode 全局配置目录
├── skills/sdd-router/
├── skills/sdd-task-requirements/
├── ...
├── commands/sdd.md
├── commands/sdd-req.md
├── ...
├── agents/sdd-build.md
├── agents/sdd-reviewer.md
├── prompts/review-dimensions.md
├── specs/templates/srs-template.md
├── lib/eval/protocol.md
└── plugins/sdd-compaction.js
```

**安装后：** 重启 OpenCode，在任何组件工程目录下运行 `/sdd` 即可使用。

**自定义部门模板：** 在全局目录下放一份部门定制版即可覆盖默认模板：

```bash
cp your-dept-design-template.md ~/.config/opencode/docs/templates/design-template.md
```

---

### 8.2 项目级安装（不推荐）

如果某些工程需要使用不同版本的 HarnessX 框架，可以项目级安装：

```bash
# Linux / macOS
bash deploy.sh --local /path/to/your-component-project

# Windows (PowerShell)
.\deploy.ps1 -Local
```

这会将框架文件复制到目标工程的 `.opencode/` 目录下（项目级覆盖，优先级高于全局）。

---

### 8.3 部署内容一览

| 类型 | 全局路径 | 项目级路径 | 说明 |
|------|---------|-----------|------|
| Skill | `~/.config/opencode/skills/` | `.opencode/skills/` | 7 个 Skill |
| Command | `~/.config/opencode/commands/` | `.opencode/commands/` | 6 个 Slash Command |
| Agent | `~/.config/opencode/agents/` | `.opencode/agents/` | 2 个 Agent |
| Prompt | `~/.config/opencode/prompts/` | `.opencode/prompts/` | 3 个审查模板 |
| 模板 | `~/.config/opencode/specs/templates/` | `specs/templates/` | 4 个文档模板 |
| Eval | `~/.config/opencode/lib/eval/` | `lib/eval/` | 7 个 Eval 文件 |
| References | `~/.config/opencode/lib/references/` | `lib/references/` | 参考文件（按需读取） |
| 插件 | `~/.config/opencode/plugins/` | `plugins/` | 1 个压缩插件 |

---

### 8.4 手动部署

如果只需更新特定文件：

```bash
# 全局安装模式：手动复制
cp -r sdd-framework/skills/* ~/.config/opencode/skills/

# 项目级安装模式：手动复制
cp -r sdd-framework/skills/* your-component/.opencode/skills/
```

---

### 8.5 部署后验证

**全局安装验证：**

```bash
# 检查全局目录是否包含所有必要文件
ls ~/.config/opencode/skills/sdd-*/SKILL.md       # 应有 7 个 Skill
ls ~/.config/opencode/commands/sdd*.md             # 应有 6 个 command
ls ~/.config/opencode/agents/sdd-*.md              # 应有 2 个 Agent
ls ~/.config/opencode/specs/templates/*.md         # 应有 4 个模板
ls ~/.config/opencode/lib/eval/*.md                # 应有 7 个 Eval 文件
ls ~/.config/opencode/lib/references/sdd-task-develop/*.md  # 应有 3 个参考文件
ls ~/.config/opencode/lib/references/sdd-task-design/*.md    # 应有 1 个参考文件
```

**项目级安装验证：**

```bash
cd your-component-project
ls .opencode/skills/sdd-*/SKILL.md
ls .opencode/commands/sdd*.md
```

---

## 9. 快速开始

### 9.1 前置条件

1. HarnessX 框架已**全局安装**（见[部署指南](#8-部署指南)），或项目级安装
2. 组件工程满足目录约定（见[目录结构约定](#111-组件工程约定)）
3. 已有 AR 编号（格式自由，如 `AR001-fix-timeout`）

### 9.2 启动第一个 AR（Classic 模式）

```bash
# 在组件工程根目录下
/sdd
```

当 Router 询问模式时选择 **Classic**，然后按提示输入 AR 编号。Router 会自动引导你进入需求阶段。

### 9.3 启动第一个 AR（Loop 模式，推荐）

```bash
# 在组件工程根目录下
/sdd
```

当 Router 询问模式时选择 **Loop**。Meta-Loop 接管后自动运行所有 5 个阶段：

```
[Phase 1/5] Requirements  → 交互澄清 → 生成 srs.md + tasks.md → Eval
[Phase 2/5] Design        → 提案方案 → 生成 design.md → Eval
[Phase 3/5] Develop       → TDD 逐任务实现 → Eval
[Phase 4/5] Review        → S/D/C 三维审查 → Eval
[Phase 5/5] ST            → 验收测试 → 归档
```

### 9.4 直连特定阶段

```bash
/sdd-req                    # 直接进入需求阶段
/sdd-design                 # 直接进入设计阶段
/sdd-dev T003               # 直接开发任务 T003
/sdd-review                 # 直接进入审查阶段
/sdd-st                     # 直接进入 ST 阶段
```

### 9.5 恢复中断的流程

```bash
/sdd-reactivate             # 检测当前进度，从中断处继续
```

---

## 10. 目录结构

### 10.1 HarnessX 框架源码

```
sdd-framework/
├── README.md                     # 本文档
├── deploy.sh                     # Linux 部署脚本
├── deploy.ps1                    # Windows 部署脚本
├── skills/                       # Skill 定义（7 个）
│   ├── sdd-router/SKILL.md
│   ├── sdd-meta-loop/SKILL.md
│   ├── sdd-task-requirements/SKILL.md
│   ├── sdd-task-design/SKILL.md
│   ├── sdd-task-develop/SKILL.md
│   ├── sdd-task-review/SKILL.md
│   └── sdd-task-st/SKILL.md
├── commands/                     # OpenCode slash commands（7 个）
│   ├── sdd.md
│   ├── sdd-req.md
│   ├── sdd-design.md
│   ├── sdd-dev.md
│   ├── sdd-review.md
│   ├── sdd-st.md
│   └── sdd-reactivate.md
├── agents/                       # OpenCode Agent 定义（2 个）
│   ├── sdd-build.md
│   └── sdd-reviewer.md
├── .opencode/prompts/            # 审查 prompt 模板（3 个）
│   ├── review-dimensions.md
│   ├── review-single-model.md
│   └── review-multi-model.md
├── specs/templates/              # 文档模板（4 个）
│   ├── srs-template.md
│   ├── tasks-template.md
│   ├── design-template.md
│   └── st-cases-template.md
├── lib/eval/                     # Eval 评估基础设施（7 个）
│   ├── protocol.md
│   ├── requirements-eval.md
│   ├── design-eval.md
│   ├── develop-eval.md
│   ├── review-eval.md
│   ├── st-eval.md
│   └── runner.md
├── plugins/                      # OpenCode 插件（2 个）
│   ├── sdd-compaction.js
│   └── sdd-task.js
└── docs/                         # 设计文档
    ├── sdd-loop-engineering-design.md
    ├── sdd-optimization-analysis.md
    └── sdd-compaction-plugin.md
```

### 10.2 目标组件工程（部署后）

```
your-component/
├── .opencode/
│   ├── commands/                 # ← 部署自 commands/
│   └── agents/                   # ← 部署自 agents/
│   └── prompts/                  # ← 部署自 .opencode/prompts/
├── skills/                       # ← 部署自 skills/
├── specs/
│   ├── templates/                # ← 部署自 specs/templates/
│   ├── component-detail-design/  # 已有：组件详设
│   ├── changes/                  # 进行中的 AR
│   │   └── ARxxx-topic/
│   │       ├── srs.md
│   │       ├── design.md
│   │       └── tasks.md
│   └── archive/                  # 已归档的 AR
│       └── ARxxx-topic/
│           ├── srs.md
│           ├── design.md
│           └── st-cases.md
├── lib/
│   └── eval/                     # ← 部署自 lib/eval/
├── plugins/                      # ← 部署自 plugins/
├── include/                      # 组件头文件
├── src/                          # 组件源文件
├── tests/                        # 组件测试
└── AGENTS.md                     # 可选：AI 编码规范
```

---

## 11. 约定与规范

### 11.1 组件工程约定

目标组件工程需满足以下目录结构（HarnessX 框架不会创建这些目录）：

```
component/
├── AGENTS.md                    # 可选：AI 编码规范（有则读）
├── include/                     # 头文件
├── src/                         # 源文件
├── tests/                       # 测试文件
└── specs/
    ├── component-detail-design/ # 已有：组件详设（必读）
    ├── changes/                 # 进行中的 AR
    └── archive/                 # 已归档的 AR
```

### 11.2 文档模板约定

| 文档 | 有无部门模板 | 格式 | 说明 |
|------|------------|------|------|
| srs.md | 无 → 用内置 | — | 框架提供 `specs/templates/srs-template.md` |
| design.md | 有（待提供）→ 优先用部门模板 | — | 框架提供 `specs/templates/design-template.md` 作为后备 |
| tasks.md | — | Markdown | 非 JSON，ID 格式 `T001`/`T002`... |
| st-cases.md | — | — | 框架提供 `specs/templates/st-cases-template.md` |

### 11.3 AR 编号

- 由用户提供，格式自由（如 `AR001`、`AR-2026-05-17-fix-timeout`）
- Router 会提示用户输入 AR 编号

### 11.4 归档规则

- ST 通过后：`specs/changes/ARxxx/` → `specs/archive/ARxxx/`
- 归档文件：`srs.md`、`design.md`、`st-cases.md`
- **不归档**：`tasks.md`（仅过程文件）

### 11.5 命名规范

- Skill 命名：`sdd-task-{phase}`（小写，用连字符）
- Command 命名：`/sdd-{phase}`（小写，用连字符）
- Agent 命名：`@sdd-{role}`（小写，用连字符）
- Eval 文件命名：`{phase}-eval.md`

---

## 附录 A：常见问题

**Q：Classic 和 Loop 模式如何选择？**

- 第一次使用、调试某个阶段、需要精细控制 → Classic
- 正常开发、追求自动化、信任 Eval 机制 → Loop

**Q：Eval 评分不准确怎么办？**

- Classic 模式下手动确认
- Loop 模式下 Eval 失败 3 次后 Escalate，人工介入

**Q：可以只用一个阶段吗？**

可以。使用 `/sdd-req`、`/sdd-design`、`/sdd-dev`、`/sdd-review`、`/sdd-st` 直连任意阶段。

**Q：如何在 Loop 模式下暂停？**

Loop 模式不支持中途暂停。如需暂停，使用 Classic 模式逐阶段执行。

**Q：TDD 双 Agent 为什么不合并为一个？**

防止自欺：写测试的 Agent 如果知道实现细节，会趋向于写"配合实现"的弱测试。独立 Agent 确保测试的"外源有效性"。

**Q：Compaction 插件什么时候触发？**

OpenCode 在上下文窗口接近上限时自动触发 `experimental.session.compacting`。插件在系统压缩完成后追加 HarnessX 关键信息，防止丢失领域上下文。

---

## 附录 B：版本历史

| 日期 | 版本 | 变更 |
|------|------|------|
| 2026-04-16 | v0.1 | 创建 6 个阶段 Skill（requirements/design/develop/review/st/router） |
| 2026-04-18 | v0.2 | OpenCode 三维适配（Commands/Agents/Plugin） |
| 2026-04-22 | v0.3 | skill-creator OpenCode 适配 |
| 2026-05-17 | v0.4 | 高优 Bug 修复（Linux 兼容性） |
| 2026-07-01 | v1.0 | Loop Engineering 集成、Eval 基础设施、compaction 插件、模板外置化、部署脚本 |
