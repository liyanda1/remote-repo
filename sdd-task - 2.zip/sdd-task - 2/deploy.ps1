# HarnessX Framework — Global Install Script (Windows PowerShell)
# Installs SDD framework to $HOME\.config\opencode\ for global availability across all projects
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File deploy.ps1              # Global install (default)
#   powershell -ExecutionPolicy Bypass -File deploy.ps1 -Local       # Local install (deprecated)
#
# After installation, restart OpenCode to load the globally installed skills/commands/agents.

param(
    [switch]$Local = $false
)

# Colors
$Red = "Red"
$Green = "Green"
$Yellow = "Yellow"
$Blue = "Blue"

# Determine global install directory
# OpenCode global config is at ~/.config/opencode/ (same as git, vim, etc.)
$HomeDir = $env:USERPROFILE
$GLOBAL_DIR = Join-Path $HomeDir ".config\opencode"

if ($Local) {
    $MODE = "local"
    $TARGET_DIR = Get-Location
    Write-Host "⚠️  Local mode is deprecated. Use global install instead." -ForegroundColor Yellow
} else {
    $MODE = "global"
    $TARGET_DIR = $GLOBAL_DIR
}

$SOURCE_DIR = Get-Location

Write-Host "════════════════════════════════════════" -ForegroundColor Blue
Write-Host "  HarnessX Framework — Global Install" -ForegroundColor Blue
Write-Host "════════════════════════════════════════" -ForegroundColor Blue
Write-Host ""
Write-Host "Source : $SOURCE_DIR"
Write-Host "Target : $TARGET_DIR"
Write-Host "Mode   : $MODE"
Write-Host ""

# Step 1: Verify source files exist
Write-Host "[1/4] Verifying source files..." -ForegroundColor Yellow

$ERRORS = 0

# Check skills (7)
$skills = @("sdd-router", "sdd-task-requirements", "sdd-task-design", "sdd-task-develop", "sdd-task-review", "sdd-task-st", "sdd-meta-loop")
foreach ($skill in $skills) {
    $filePath = Join-Path $SOURCE_DIR "skills\$skill\SKILL.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: skills/$skill/SKILL.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check commands (6)
$commands = @("sdd", "sdd-req", "sdd-design", "sdd-dev", "sdd-review", "sdd-st")
foreach ($cmd in $commands) {
    $filePath = Join-Path $SOURCE_DIR "commands\$cmd.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: commands/$cmd.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check agents (2)
$agents = @("sdd-build", "sdd-reviewer")
foreach ($agent in $agents) {
    $filePath = Join-Path $SOURCE_DIR "agents\$agent.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: agents/$agent.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check prompts (3)
$prompts = @("review-dimensions", "review-single-model", "review-multi-model")
foreach ($prompt in $prompts) {
    $filePath = Join-Path $SOURCE_DIR ".opencode\prompts\$prompt.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: .opencode/prompts/$prompt.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check templates (4)
$templates = @("srs-template", "tasks-template", "design-template", "st-cases-template")
foreach ($tmpl in $templates) {
    $filePath = Join-Path $SOURCE_DIR "specs\templates\$tmpl.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: specs/templates/$tmpl.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check references
$refFiles = Get-ChildItem -Path "$SOURCE_DIR\lib\references\**\*.md" -Recurse -ErrorAction SilentlyContinue
if ($refFiles.Count -eq 0) {
    Write-Host "  ✗ Missing: lib/references/ (no .md files)" -ForegroundColor Red
    $ERRORS++
} else {
    Write-Host "  ✓ References: $($refFiles.Count) file(s)" -ForegroundColor Green
}

# Check eval (7)
$evals = @("protocol", "requirements-eval", "design-eval", "develop-eval", "review-eval", "st-eval", "runner")
foreach ($eval in $evals) {
    $filePath = Join-Path $SOURCE_DIR "lib\eval\$eval.md"
    if (-not (Test-Path $filePath)) {
        Write-Host "  ✗ Missing: lib/eval/$eval.md" -ForegroundColor Red
        $ERRORS++
    }
}

# Check plugin (1)
$pluginPath = Join-Path $SOURCE_DIR "plugins\sdd-compaction.js"
if (-not (Test-Path $pluginPath)) {
    Write-Host "  ✗ Missing: plugins/sdd-compaction.js" -ForegroundColor Red
    $ERRORS++
}

if ($ERRORS -gt 0) {
    Write-Host "✗ $ERRORS source file(s) missing. Abort." -ForegroundColor Red
    exit 1
}

Write-Host "✓ All source files verified (30+ files)" -ForegroundColor Green

# Step 2: Confirm
Write-Host ""
Write-Host "[2/4] Confirm installation" -ForegroundColor Yellow
Write-Host ""
Write-Host "This will install SDD framework to:"
Write-Host "  $TARGET_DIR"
Write-Host ""
Write-Host "The following directories will be created/updated:"
Write-Host "  $TARGET_DIR\skills\         (7 skills)"
Write-Host "  $TARGET_DIR\commands\       (6 commands)"
Write-Host "  $TARGET_DIR\agents\         (2 agents)"
Write-Host "  $TARGET_DIR\prompts\        (3 prompt templates)"
Write-Host "  $TARGET_DIR\specs\templates\  (4 doc templates)"
Write-Host "  $TARGET_DIR\lib\eval\       (7 eval files)"
Write-Host "  $TARGET_DIR\lib\references\ (reference files)"
Write-Host "  $TARGET_DIR\plugins\        (1 plugin)"
Write-Host ""

$confirm = Read-Host "Proceed with installation? (yes/no)"
if ($confirm -ne "yes") {
    Write-Host "Installation cancelled." -ForegroundColor Yellow
    exit 0
}

# Step 3: Install
Write-Host ""
Write-Host "[3/4] Installing..." -ForegroundColor Yellow

# Create target directories
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\skills" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\commands" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\agents" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\prompts" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\specs\templates" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\lib\eval" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\plugins" | Out-Null
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\docs\templates" | Out-Null

# Install skills (7)
Write-Host "  Installing skills..."
foreach ($skill in $skills) {
    New-Item -ItemType Directory -Force -Path "$TARGET_DIR\skills\$skill" | Out-Null
    Copy-Item "$SOURCE_DIR\skills\$skill\SKILL.md" "$TARGET_DIR\skills\$skill\SKILL.md"
    # Copy evals if exists
    if (Test-Path "$SOURCE_DIR\skills\$skill\evals") {
        New-Item -ItemType Directory -Force -Path "$TARGET_DIR\skills\$skill\evals" | Out-Null
        Copy-Item "$SOURCE_DIR\skills\$skill\evals\*" "$TARGET_DIR\skills\$skill\evals\" -Recurse -ErrorAction SilentlyContinue
    }
    Write-Host "    ✓ $skill" -ForegroundColor Green
}

# Install commands (6)
Write-Host "  Installing commands..."
foreach ($cmd in $commands) {
    Copy-Item "$SOURCE_DIR\commands\$cmd.md" "$TARGET_DIR\commands\$cmd.md"
    Write-Host "    ✓ $cmd" -ForegroundColor Green
}

# Install agents (2)
Write-Host "  Installing agents..."
foreach ($agent in $agents) {
    Copy-Item "$SOURCE_DIR\agents\$agent.md" "$TARGET_DIR\agents\$agent.md"
    Write-Host "    ✓ $agent" -ForegroundColor Green
}

# Install prompts (3)
Write-Host "  Installing prompts..."
foreach ($prompt in $prompts) {
    Copy-Item "$SOURCE_DIR\.opencode\prompts\$prompt.md" "$TARGET_DIR\prompts\$prompt.md"
    Write-Host "    ✓ $prompt" -ForegroundColor Green
}

# Install templates (4 + 1 department)
Write-Host "  Installing templates..."
foreach ($tmpl in $templates) {
    Copy-Item "$SOURCE_DIR\specs\templates\$tmpl.md" "$TARGET_DIR\specs\templates\$tmpl.md"
    Write-Host "    ✓ $tmpl" -ForegroundColor Green
}
# Install department design template if exists
if (Test-Path "$SOURCE_DIR\docs\templates\design-template.md") {
    Copy-Item "$SOURCE_DIR\docs\templates\design-template.md" "$TARGET_DIR\docs\templates\design-template.md"
    Write-Host "    ✓ department design-template (docs/templates/)" -ForegroundColor Green
}

# Install eval (7)
Write-Host "  Installing eval..."
foreach ($eval in $evals) {
    Copy-Item "$SOURCE_DIR\lib\eval\$eval.md" "$TARGET_DIR\lib\eval\$eval.md"
    Write-Host "    ✓ $eval" -ForegroundColor Green
}

# Install references
Write-Host "  Installing references..."
New-Item -ItemType Directory -Force -Path "$TARGET_DIR\lib\references" | Out-Null
Copy-Item "$SOURCE_DIR\lib\references\**" "$TARGET_DIR\lib\references\" -Recurse -ErrorAction SilentlyContinue
Write-Host "    ✓ references/" -ForegroundColor Green

# Install plugin (1)
Write-Host "  Installing plugins..."
Copy-Item "$SOURCE_DIR\plugins\sdd-compaction.js" "$TARGET_DIR\plugins\sdd-compaction.js"
Write-Host "    ✓ sdd-compaction.js" -ForegroundColor Green

Write-Host ""
Write-Host "✓ Installation complete!" -ForegroundColor Green

# Step 4: Verify
Write-Host ""
Write-Host "[4/4] Verifying..." -ForegroundColor Yellow

$VERIFY_ERRORS = 0

# Verify skills
foreach ($skill in $skills) {
    if (-not (Test-Path "$TARGET_DIR\skills\$skill\SKILL.md")) {
        Write-Host "  ✗ Verify failed: skills/$skill/SKILL.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify commands
foreach ($cmd in $commands) {
    if (-not (Test-Path "$TARGET_DIR\commands\$cmd.md")) {
        Write-Host "  ✗ Verify failed: commands/$cmd.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify agents
foreach ($agent in $agents) {
    if (-not (Test-Path "$TARGET_DIR\agents\$agent.md")) {
        Write-Host "  ✗ Verify failed: agents/$agent.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify prompts
foreach ($prompt in $prompts) {
    if (-not (Test-Path "$TARGET_DIR\prompts\$prompt.md")) {
        Write-Host "  ✗ Verify failed: prompts/$prompt.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify templates
foreach ($tmpl in $templates) {
    if (-not (Test-Path "$TARGET_DIR\specs\templates\$tmpl.md")) {
        Write-Host "  ✗ Verify failed: specs/templates/$tmpl.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify eval
foreach ($eval in $evals) {
    if (-not (Test-Path "$TARGET_DIR\lib\eval\$eval.md")) {
        Write-Host "  ✗ Verify failed: lib/eval/$eval.md" -ForegroundColor Red
        $VERIFY_ERRORS++
    }
}

# Verify plugin
if (-not (Test-Path "$TARGET_DIR\plugins\sdd-compaction.js")) {
    Write-Host "  ✗ Verify failed: plugins/sdd-compaction.js" -ForegroundColor Red
    $VERIFY_ERRORS++
}

# Verify references
$refFiles = Get-ChildItem -Path "$TARGET_DIR\lib\references\**\*.md" -Recurse -ErrorAction SilentlyContinue
if ($refFiles.Count -eq 0) {
    Write-Host "  ⚠ Verify warning: lib\references\ has no .md files" -ForegroundColor Yellow
} else {
    Write-Host "  ✓ References: $($refFiles.Count) file(s)" -ForegroundColor Green
}

if ($VERIFY_ERRORS -gt 0) {
    Write-Host "✗ $VERIFY_ERRORS file(s) failed to install. Please check." -ForegroundColor Red
    exit 1
}

Write-Host "✓ All files verified (30+ files)" -ForegroundColor Green

# Done
Write-Host ""
Write-Host "════════════════════════════════════════" -ForegroundColor Blue
Write-Host "  ✅ HarnessX Framework installed successfully!" -ForegroundColor Green
Write-Host "════════════════════════════════════════" -ForegroundColor Blue
Write-Host ""
Write-Host "Next steps:"
Write-Host ""
Write-Host "  1. Restart OpenCode to load the globally installed skills"
Write-Host "     opencode run"
Write-Host ""
Write-Host "  2. In any component project, run:"
Write-Host "     /sdd"
Write-Host ""
Write-Host "  3. To customize department template, create:"
Write-Host "     $TARGET_DIR\docs\templates\design-template.md"
Write-Host ""
Write-Host "  Global install directory: $TARGET_DIR"
Write-Host ""
