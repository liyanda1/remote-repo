# HarnessX Eval Runner

Loop Engineering 核心组件：在独立上下文中运行阶段评估，确保公正性。

---

## 使用方法

在 Meta-Loop 执行每个阶段后，用以下 prompt 启动一个**独立的子 Agent** 来运行 Eval：

```
你是一个独立的 SDD 阶段评估 Agent。你的任务是不受主 Agent 影响的、公正地评估 {phase} 阶段的产出质量。

请按以下流程执行：

## 1. 读取 Eval 模板
读取 lib/eval/{phase}-eval.md 了解评估维度和标准。

## 2. 读取评估对象
- specs/changes/{AR}/srs.md
- specs/changes/{AR}/design.md（如有）
- specs/changes/{AR}/tasks.md（如有）
- AGENTS.md（如有）

## 3. 逐维度评估
严格按照 Eval 模板中定义的每个维度：
- 读取相关文件内容
- 按 pass 条件判断
- 给出 0-100 的评分
- 记录具体的 feedback 和 gap

## 4. 输出结果
将评估结果写入 specs/changes/{AR}/eval/eval-{phase}-{iteration}.json

## 重要规则
- 不要读取或参考之前对话中主 Agent 的任何观点
- 只看文件内容，独立判断
- 如果某些维度无法评估（如缺少参考文件），标注为 N/A 而非强行给分
```

---

## 子 Agent 派发参数

| 参数 | 来源 | 示例 |
|------|------|------|
| phase | Meta-Loop 当前阶段 | "requirements" |
| AR | Meta-Loop 当前 AR | "AR001-add-retry" |
| iteration | Meta-Loop 当前迭代 | 1 |
| AR_PATH | specs/changes/{AR} | "specs/changes/AR001-add-retry" |

---

## 确定性 Eval 的特殊处理

develop 和 st 阶段的 Eval 不使用 LLM 子 Agent，而是直接在 Meta-Loop 中运行：

### develop Eval
```
1. 读取 tasks.md 获取所有 task 状态
2. 运行测试命令（从 AGENTS.md 或用户提供）
3. 检查测试 exit code
4. 生成 Eval JSON
```

### st Eval
```
1. 读取 st-cases.md 获取所有用例
2. 运行 ST 测试
3. 比对每个用例的 expected vs actual
4. 生成 Eval JSON
```

---

## Eval 结果文件命名规则

```
specs/changes/{AR}/eval/
├── eval-{phase}-{iteration}.json    # LLM Eval 阶段
├── eval-develop-task-{id}-{n}.json   # develop task 级
└── eval-develop-phase-{n}.json       # develop 阶段汇总
```

示例：
```
specs/changes/AR001-add-retry/eval/
├── eval-requirements-1.json
├── eval-design-1.json
├── eval-develop-task-T001-1.json
├── eval-develop-task-T002-1.json
├── eval-develop-task-T002-2.json
├── eval-develop-task-T003-1.json
├── eval-develop-phase-1.json
├── eval-review-1.json
├── eval-review-2.json
├── eval-st-1.json
└── eval-st-2.json
```
