# HarnessX Eval Protocol v1.0

Loop Engineering 核心：每个阶段 Loop 通过统一的 Eval 协议判断是否达标。

---

## 评估输出格式

所有阶段的 Eval 必须输出以下 JSON 结构：

```json
{
  "phase": "requirements|design|develop|review|st",
  "iteration": 1,
  "max_iterations": 3,
  "overall": "pass|fail",
  "score": 85,
  "dimensions": [
    {
      "name": "维度名称（中文，≤15字）",
      "pass": true,
      "score": 90,
      "weight": 0.25,
      "feedback": "具体反馈：做得好的地方",
      "gap": "缺失项或不足（仅 fail 时填写）",
      "fix_hint": "修正建议：参考 skills/sdd-task-xxx/SKILL.md 中 Step X"
    }
  ],
  "summary": "一段话总结整体评估结果",
  "blocking_issues": ["阻塞性问题1", "阻塞性问题2"],
  "recommendation": "next|retry|escalate",
  "next_phase": "design"
}
```

---

## 全局评分规则

### Overall 判定

| 条件 | overall |
|------|---------|
| 所有 `dimensions[].pass == true` | `pass` |
| 任一维度 fail | `fail` |

### Score 计算

```
score = Σ(dimensions[i].score × dimensions[i].weight)
```

- 权重之和必须 = 1.0
- 每维度 0-100 分
- score 用于判断是否需要人工审查（默认可不审查）

### Recommendation 规则

| overall | 条件 | recommendation |
|---------|------|----------------|
| pass | 当前阶段非最后阶段 | `next` |
| pass | 当前阶段是 ST（最后阶段） | `archive` |
| fail | iteration < max_iterations | `retry` |
| fail | iteration == max_iterations | `escalate` |

---

## 维度定义规范

每个阶段定义 3-5 个评估维度。维度定义必须满足：

1. **可量化**：不能是"代码质量好"，而应是"圈复杂度 ≤ 15"
2. **有明确 pass/fail 标准**：每个维度必须有清晰的 pass 阈值
3. **有修正路径**：fail 时必须能指出参考哪个 Skill 的哪一步来修正
4. **权重合理**：核心维度权重高，辅助维度权重低

| 属性 | 含义 | 示例 |
|------|------|------|
| name | 维度名称（中文） | "域知识覆盖" |
| pass | 是否达标 | true |
| score | 0-100 | 85 |
| weight | 0-1，阶段内权重和=1 | 0.3 |
| feedback | 正向反馈 + 具体问题 | "覆盖了 A、B，但缺失 C" |
| gap | 未达标的缺口 | "缺少并发安全性需求" |
| fix_hint | 修正步骤参考 | "参考 skills/sdd-task-requirements 的 Step 2a" |

---

## Escalation 升级协议

当 `recommendation == "escalate"` 时，必须输出升级信息：

```json
{
  "escalation": {
    "reason": "3 次迭代后仍存在 blocking_issues",
    "blocking_issues": ["需求 R5 的接口定义与设计 D3 不一致"],
    "completed_dimensions": ["域知识覆盖", "澄清完整"],
    "failed_dimensions": ["可测试性"],
    "recommended_action": "人工审查需求 R5 和设计 D3 的冲突点",
    "estimated_fix_cost": "small|medium|large"
  }
}
```

---

## 各阶段默认阈值

| 阶段 | pass 阈值 | 默认 max_iterations | 关键阻断维度 |
|------|-----------|-------------------|-------------|
| requirements | score ≥ 80 | 3 | 域知识覆盖、无 TBD |
| design | score ≥ 85 | 3 | 需求回溯完整、接口签名 |
| develop | 测试全通过 | 5 per task | 测试 exit code=0 |
| review | S/D/C 三维全 pass | 2 | S 维度（该通过必须通过） |
| st | 关键用例全通过 | 3 | 关键用例 |

---

## Eval 执行规范

### LLM Eval（requirements / design / review）

- 使用独立会话评估，避免主 Agent 自评 bias
- Eval prompt 模板见各阶段 Eval 文件
- Eval 结果写入 `specs/changes/ARxxx/eval/`

### 确定性 Eval（develop / st）

- develop：测试 exit code + 覆盖率（若可用）
- st：st-cases.md 的 expected vs actual 比对
- 不依赖 LLM，直接由测试框架输出

---

## Eval 结果存储

```
specs/changes/ARxxx/eval/
├── eval-requirements-1.json     # requirements 第 1 次评估
├── eval-requirements-2.json     # requirements 第 2 次评估（如有）
├── eval-design-1.json
├── eval-review-1.json
└── eval-st-1.json
```

- 命名格式：`eval-{phase}-{iteration}.json`
- 每次迭代独立存储，可追溯决策链
- compaction 插件可读取这些文件注入关键决策
