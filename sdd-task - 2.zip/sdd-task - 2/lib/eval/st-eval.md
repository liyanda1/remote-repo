# HarnessX Eval — ST Phase

评估对象：`specs/changes/{AR}/st-cases.md` + 测试运行结果

> **注意**：ST 阶段使用**确定性 Eval**（用例 expected vs actual），不依赖 LLM 评估。

---

## 评估机制

ST 阶段的 Eval 直接对比 st-cases.md 中每个用例的预期结果和实际测试结果。

---

## st-cases.md 用例格式要求

```markdown
## ST-001: 用例名称

**来源需求**: R1, R2
**前置条件**: 系统已初始化
**操作步骤**:
1. 调用 API-A
2. 传入参数 X=1
**预期结果**: 返回 code=200, data.id 不为空
**实际结果**: [由测试运行时填充]
**状态**: pending|pass|fail
```

---

## Eval 维度

| 维度 | 评估方式 | pass 条件 | weight |
|------|---------|-----------|--------|
| 关键用例通过率 | 运行测试 | 100% | 0.50 |
| 全部用例通过率 | 运行测试 | ≥ 95% | 0.30 |
| 用例完整性 | 检查覆盖 | ≥ 80% 需求有 ST 用例 | 0.15 |
| 归档就绪 | 检查文件完整性 | 所有文档齐备 | 0.05 |

---

## 关键用例定义

关键用例 = srs.md 中标记为"核心需求"或"安全关键"的需求对应的 ST 用例。

如果没有显式标记，默认：
- 对外 API 接口的用例
- 涉及数据持久化的用例
- 涉及错误处理的用例

---

## 输出格式

```json
{
  "phase": "st",
  "iteration": 1,
  "max_iterations": 3,
  "overall": "pass|fail",
  "score": 95,
  "dimensions": [
    {
      "name": "关键用例通过率",
      "pass": true|false,
      "score": 100,
      "weight": 0.50,
      "feedback": "5/5 关键用例通过",
      "gap": "失败的关键用例 ID 列表（仅 fail 时）",
      "fix_hint": "修复对应的实现代码"
    },
    {
      "name": "全部用例通过率",
      "pass": true|false,
      "score": 95,
      "weight": 0.30,
      "feedback": "19/20 用例通过",
      "gap": "失败的用例 ID",
      "fix_hint": "修复失败的 ST-012 用例相关代码"
    },
    {
      "name": "用例完整性",
      "pass": true,
      "score": 90,
      "weight": 0.15,
      "feedback": "覆盖 90% 需求（9/10）",
      "gap": "未覆盖的需求：R7",
      "fix_hint": "为 R7 新增 ST 用例"
    },
    {
      "name": "归档就绪",
      "pass": true|false,
      "score": 100,
      "weight": 0.05,
      "feedback": "所有文档齐备",
      "gap": "缺失的文件（仅 fail 时）",
      "fix_hint": "确保 srs.md、design.md、st-cases.md 都存在"
    }
  ],
  "test_results": [
    {
      "case_id": "ST-001",
      "name": "正常调用返回成功",
      "source_requirements": ["R1"],
      "status": "pass",
      "expected": "code=200",
      "actual": "code=200"
    },
    {
      "case_id": "ST-012",
      "name": "并发调用不冲突",
      "source_requirements": ["R7"],
      "status": "fail",
      "expected": "data.id 唯一",
      "actual": "data.id 重复（两次调用返回相同 id）",
      "error": "并发场景未加锁"
    }
  ],
  "summary": "19/20 用例通过，ST-012 并发场景失败，需修复",
  "blocking_issues": ["ST-012: 并发场景数据竞争"],
  "recommendation": "retry|archive|escalate",
  "next_phase": null
}
```

---

## 失败处理

```
FOR EACH failed_case IN test_results WHERE status == "fail":
  IF failed_case.source_requirements 中包含关键需求:
    → 必须修复（blocking）
  ELSE:
    → 标记为 known_issue，记录到 st-cases.md

修复后：
  → 重新运行所有测试（确保无回归）
  → 更新 Eval 结果
```

---

## 归档条件

只有当以下条件全部满足时，才能执行归档：

1. `overall == "pass"`
2. 关键用例 100% 通过
3. 所有文档齐全（srs.md、design.md、st-cases.md）

归档操作：
```bash
# 在组件工程根目录下执行
cp -r specs/changes/ARxxx-topic specs/archive/ARxxx-topic
rm -rf specs/changes/ARxxx-topic
```

> 注意：tasks.md 不归档到 archive 中。

---

## st-cases.md 自动更新

每次 Eval 完成后，更新 st-cases.md：

```markdown
## ST-001: 正常调用返回成功
**状态**: ✅ pass

## ST-012: 并发调用不冲突
**状态**: ❌ fail
**失败原因**: 并发场景未加锁
**实际结果**: data.id 重复
```
