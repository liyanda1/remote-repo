# HarnessX Eval — Develop Phase

评估对象：`specs/changes/{AR}/tasks.md` + 测试运行结果

> **注意**：Develop 阶段使用**确定性 Eval**（测试 exit code），不依赖 LLM 评估。
> 以下模板用于 Agent 执行评估逻辑。

---

## 评估机制

Develop 阶段的 Eval 是**两层嵌套**的：

```
Outer Layer: 逐个 task 评估
  ├─ Task Loop Eval: 当前 task 是否完成？
  └─ Phase Eval: 所有 task 是否完成？
```

---

## Task Loop Eval（TDD 内层）

### 维度定义

| 维度 | 评估方式 | pass 条件 | weight |
|------|---------|-----------|--------|
| 测试编写（Red） | 文件存在 + 编译通过 | 测试文件存在且可编译 | 0.25 |
| Red 验证 | 运行测试 → exit code ≠ 0 | 测试失败（但非编译错误） | 0.10 |
| 实现代码（Green） | 运行测试 → exit code = 0 | 全部测试通过 | 0.45 |
| 代码覆盖率 | 覆盖率工具输出（若有） | ≥ 阈值（默认 70%） | 0.10 |
| 无回归 | 之前通过的 task 用例仍通过 | 无新增失败 | 0.10 |

### 输出格式

```json
{
  "phase": "develop",
  "subphase": "task",
  "task_id": "T003",
  "iteration": 2,
  "max_iterations": 5,
  "overall": "pass",
  "score": 100,
  "dimensions": [
    {
      "name": "测试编写",
      "pass": true,
      "score": 100,
      "weight": 0.25,
      "feedback": "测试文件已生成且编译通过",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "Red 验证",
      "pass": true,
      "score": 100,
      "weight": 0.10,
      "feedback": "测试按预期失败（Red）",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "实现代码",
      "pass": true,
      "score": 100,
      "weight": 0.45,
      "feedback": "全部 5 个测试用例通过",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "代码覆盖率",
      "pass": true,
      "score": 85,
      "weight": 0.10,
      "feedback": "行覆盖率 85%",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "无回归",
      "pass": true,
      "score": 100,
      "weight": 0.10,
      "feedback": "T001-T002 的测试用例全部通过",
      "gap": null,
      "fix_hint": null
    }
  ],
  "summary": "T003 实现完成，5/5 测试通过，覆盖率 85%",
  "blocking_issues": [],
  "recommendation": "next",
  "next_task": "T004"
}
```

---

## Phase Eval（外层）

当所有 task 完成后：

```json
{
  "phase": "develop",
  "subphase": "phase",
  "iteration": 1,
  "max_iterations": 1,
  "overall": "pass|fail",
  "score": 95,
  "dimensions": [
    {
      "name": "Task 完成率",
      "pass": true,
      "score": 100,
      "weight": 0.50,
      "feedback": "全部 N 个 task 状态为 passing",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "整体测试通过",
      "pass": true,
      "score": 100,
      "weight": 0.30,
      "feedback": "全量测试通过，无回归",
      "gap": null,
      "fix_hint": null
    },
    {
      "name": "代码变更审查就绪",
      "pass": true,
      "score": 90,
      "weight": 0.20,
      "feedback": "代码变更已提交（commit），准备进入 review",
      "gap": null,
      "fix_hint": null
    }
  ],
  "summary": "所有 task 完成，全量测试通过，可进入 review 阶段",
  "blocking_issues": [],
  "recommendation": "next",
  "next_phase": "review"
}
```

---

## 降级流程（无测试命令时）

当 AGENTS.md 中无测试编译命令时：

1. Agent 提示用户手动运行测试
2. 等待用户回复："Red 确认" 或 "Green 确认"
3. 用户确认后继续下一阶段

此时 Eval 格式简化为：

```json
{
  "phase": "develop",
  "subphase": "task",
  "task_id": "T003",
  "eval_mode": "manual",
  "overall": "pass",
  "dimensions": [
    {
      "name": "人工验证",
      "pass": true,
      "score": 100,
      "feedback": "用户确认 Green 通过"
    }
  ],
  "recommendation": "next"
}
```

---

## 失败处理

当测试失败时：

1. Agent 分析 test output，提取 error message 和 stack trace
2. 根据错误信息修正实现代码
3. 重新运行测试
4. 如果同一 task 连续 5 次失败 → escalate

```json
{
  "overall": "fail",
  "recommendation": "retry|escalate",
  "failure_details": {
    "failed_tests": ["test_retry_on_timeout", "test_max_retries"],
    "error_messages": ["AssertionError: expected 3 but got 5", "..."],
    "fix_direction": "RetryManager 的 max_retries 默认值设置错误"
  }
}
```
