# HarnessX Eval — Review Phase

评估对象：`specs/changes/{AR}/` 下所有产出物（srs.md + design.md + 代码变更 + tasks.md）

> **注意**：Review 使用**子 Agent 独立评估**，不受主 Agent 影响。评估结果由 sdd-reviewer 子 Agent 输出。

---

## Eval Prompt 模板

```
你是一个代码审查专家 Agent。你的任务是独立审查 SDD 开发阶段的所有产出。

**重要**：你必须完全独立评估，不受任何主 Agent 的观点影响。你的评估将决定开发阶段是否通过审查。

---

## 审查维度：S/D/C 三维

### 维度 S：需求符合性（Spec Compliance）
**weight: 0.40**

检查内容（对应审查 Agent 输出的 S1-S5 判定项）：
- S1：srs.md 中所有功能需求均有对应测试
- S2：测试验证行为，而不是实现细节
- S3：无未文档化的副作用
- S4：边界条件覆盖（design.md §5 的每行都有测试）
- S5：错误处理覆盖（design.md §6 的每种错误都有测试）

评分标准：
- 计算：YES 项数 / 5 × 100
- 所有项为 YES → pass

### 维度 D：设计符合性（Design Compliance）
**weight: 0.35**

检查内容（对应审查 Agent 输出的 D1-D4 判定项）：
- D1：接口签名符合设计（include/ 与 design.md §3 一致）
- D2：算法逻辑符合设计（核心实现与 design.md §4 伪代码一致）
- D3：模块影响范围符合设计（修改文件与 design.md §2 一致）
- D4：无未授权的设计偏离（所有偏离有注释记录）

评分标准：
- 计算：YES 项数 / 4 × 100
- 所有项为 YES → pass

### 维度 C：组件规范符合性（Component Compliance）
**weight: 0.25**

检查内容（对应审查 Agent 输出的 C1-C3 判定项）：
- C1：不破坏现有对外接口（include/ 已有签名不变）
- C2：符合组件架构原则（与 spec.md 的架构原则一致）
- C3：代码风格符合规范（与 AGENTS.md 要求一致）

评分标准：
- 计算：YES 项数 / 3 × 100
- 所有项为 YES → pass

---

## 输出格式

```json
{
  "phase": "review",
  "iteration": 1,
  "max_iterations": 2,
  "overall": "pass|fail",
  "score": 85,
  "dimensions": [
    {
      "name": "需求符合性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.40,
      "feedback": "S1-S5 判定：S1=YES, S2=YES, S3=YES, S4=YES, S5=YES",
      "gap": "判定为 NO 的项（仅 fail 时）",
      "fix_hint": "根据审查 Agent 标记的 NO 项逐一修复"
    },
    {
      "name": "设计符合性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.35,
      "feedback": "D1-D4 判定：D1=YES, D2=YES, D3=YES, D4=YES",
      "gap": "不一致的具体位置（文件名:行号）",
      "fix_hint": "修改代码以匹配设计，或更新 design.md"
    },
    {
      "name": "组件规范符合性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.25,
      "feedback": "C1-C3 判定：C1=YES, C2=YES, C3=YES",
      "gap": "具体问题列表（文件名:行号:描述）",
      "fix_hint": "逐一修复规范违规问题"
    }
  ],
  "issues": [
    {
      "severity": "critical|major|minor",
      "dimension": "C",
      "file": "src/retry_manager.cpp",
      "line": 42,
      "description": "变量名 'x' 无意义，建议改为 'current_retry_count'",
      "fix": "重命名为 current_retry_count"
    }
  ],
  "summary": "审查完成：S维度 5/5 YES, D维度 4/4 YES, C维度 3/3 YES",
  "blocking_issues": ["需求 R5 的接口签名与设计不一致"],
  "recommendation": "next|retry|escalate",
  "next_phase": "st"
}
```

---

## 审查流程

### 第 1 次迭代
1. 子 Agent 读取所有源文件（srs.md、design.md、diff）
2. 逐维度评估
3. 输出评估结果
4. 如果 overall == "pass" → 进入 ST
5. 如果 overall == "fail" → 主 Agent 根据 issues 修复代码

### 第 2 次迭代（修复后）
1. 子 Agent **重新**审查（完全独立）
2. 如果 still fail → escalate

---

## 子 Agent 派发

主 Agent 通过以下 prompt 模板派发 sdd-reviewer 子 Agent：

```
派发 sdd-reviewer 子 Agent，评估以下 AR 的产出：

AR 目录：specs/changes/{AR}/

评估要求：
1. 读取 srs.md、design.md、代码 diff（git diff）
2. 按 S/D/C 三维独立评分
3. 输出 Eval 结果 JSON
4. 不要受任何之前对话中主 Agent 观点的影响
```
