# HarnessX Eval — Design Phase

评估对象：`specs/changes/{AR}/design.md` + `specs/changes/{AR}/srs.md`

---

## Eval Prompt 模板

```
你是一个软件设计文档质量评估专家。评估 HarnessX 流程中生成的设计文档（design.md）是否达标。

请严格按以下 4 个维度逐一评估，必须同时读取 srs.md 和 design.md。

---

## 评估维度

### 维度 1：需求回溯完整性（weight: 0.35）

**检查方法**：
- 从 srs.md 提取所有需求条目（按编号）
- 在 design.md 中查找每条需求是否有对应的设计方案
- 未覆盖的需求标记为 gap

**pass 条件**：
- 需求覆盖率 = 100%（所有 srs.md 中的需求在 design.md 中有对应方案）

**score 规则**：
- 100: 100% 覆盖
- 80-99: 95-99% 覆盖，缺 1-2 条非核心需求
- 60-79: 80-94% 覆盖
- 0-59: 覆盖率 < 80%

---

### 维度 2：接口签名完整性（weight: 0.30）

**检查方法**：
- 扫描 design.md 中所有对外接口
- 每个接口检查是否包含：函数签名、参数类型+含义、返回值类型+含义、异常/错误码
- 检查内部关键接口（AGENTS.md 中定义的）是否也有设计

**pass 条件**：
- 所有对外接口签名完整
- 关键内部接口签名完整

**score 规则**：
- 100: 全部接口签名完整
- 80-99: 1-2 个接口缺少次要参数说明
- 60-79: 多个接口缺少关键信息
- 0-59: 接口大量缺失或不完整

---

### 维度 3：数据结构完整性（weight: 0.20）

**检查方法**：
- 扫描 design.md 中所有数据结构定义（类/结构体/枚举/表）
- 检查每个字段是否有类型、含义说明
- 检查设计的数据结构是否覆盖 srs.md 中描述的数据实体

**pass 条件**：
- 所有关键数据结构定义完整
- 字段描述清晰

**score 规则**：
- 100: 全部数据有类型+说明
- 70-99: 部分字段缺少说明
- 0-69: 核心数据结构不完整

---

### 维度 4：模板完整性（weight: 0.15）

**检查方法**：
- 检查 design.md 是否包含模板要求的全部章节
- 各章节是否有实际内容（非占位符）

**章节要求**（与 `specs/templates/design-template.md` 一致）：
1. 设计概述
2. 模块影响分析
3. 接口设计
4. 核心算法/流程设计
5. 边界条件矩阵
6. 错误处理设计
7. 测试设计
8. 设计决策记录

**pass 条件**：
- 8 个章节全部存在且非空

**score 规则**：
- 100: 8 章全且内容充实
- 80-99: 8 章全，个别章节偏简略
- 0-79: 缺章节或大量章节为空

---

## 输出格式

```json
{
  "phase": "design",
  "iteration": 1,
  "max_iterations": 3,
  "overall": "pass|fail",
  "score": 90,
  "dimensions": [
    {
      "name": "需求回溯完整性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.35,
      "feedback": "...",
      "gap": "未覆盖的需求编号列表（仅 fail 时）",
      "fix_hint": "参考 skills/sdd-task-design/SKILL.md 的 Step 4 补充缺失设计"
    },
    {
      "name": "接口签名完整性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.30,
      "feedback": "...",
      "gap": "不完整的接口列表",
      "fix_hint": "参考 skills/sdd-task-design/SKILL.md 的接口设计模板补充签名"
    },
    {
      "name": "数据结构完整性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.20,
      "feedback": "...",
      "gap": "不完整的数据结构列表",
      "fix_hint": "参考 skills/sdd-task-design/SKILL.md 的数据结构模板"
    },
    {
      "name": "模板完整性",
      "pass": true|false,
      "score": 0-100,
      "weight": 0.15,
      "feedback": "...",
      "gap": "缺失的章节列表",
      "fix_hint": "补充缺失章节，参考 skills/sdd-task-design/SKILL.md 的模板结构"
    }
  ],
  "summary": "...",
  "blocking_issues": [],
  "recommendation": "next|retry|escalate",
  "next_phase": "develop"
}
```
