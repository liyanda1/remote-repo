# PlantUML 图表规范

所有架构图和流程图必须使用 **PlantUML** 格式，以 ` ```plantuml ` 代码块写入 design.md，渲染器（GitLab、IDE 插件等）可直接渲染。

## 基本格式

```
@startuml
' 图表内容写在这里
@enduml
```

## 必要图表类型

| 设计节 | 图表类型 | PlantUML 关键字 | 必要性 |
|-------|---------|----------------|-------|
| 模块关系 | 组件依赖图 | `component` / `package` | 当涉及 3 个以上文件 |
| 核心流程 | 活动图（流程图） | `@startuml` + `start` / `stop` / `if` | 每个有分支逻辑的功能 |
| 接口交互 | 时序图 | `@startuml` + `->` / `-->` | 跨模块调用链路 |
| 状态机 | 状态图 | `@startuml` + `state` | 有状态变迁的功能 |
| 类/结构关系 | 类图 | `@startuml` + `class` | 新增数据结构时 |

## 常用语法速查

### 活动图（流程图）

```
@startuml
start
:步骤1;
if (条件) then (是)
  :分支A;
else (否)
  :分支B;
endif
:步骤2;
stop
@enduml
```

### 时序图

```
@startuml
participant "客户端" as Client
participant "服务端" as Server

Client -> Server: 请求
Server --> Client: 响应
@enduml
```

### 组件图

```
@startuml
package "模块A" {
  [ComponentX]
  [ComponentY]
}

[ComponentX] --> [ComponentY]: 依赖
@enduml
```

### 状态图

```
@startuml
state "状态1" as S1
state "状态2" as S2

S1 --> S2: 事件触发
@enduml
```

## 设计节与图表对应关系

| design.md 章节 | 推荐图表 |
|---------------|---------|
| §2 模块影响分析 | 组件依赖图 |
| §4 核心算法/流程设计 | 活动图（流程图）|
| §4 接口交互 | 时序图 |
| §5 边界条件矩阵 | （无需图表）|
| §6 错误处理设计 | 状态图（如有状态机）|
