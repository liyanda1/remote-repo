# 确认行为矩阵

`{confirm_mode}` × `{test_available}` 的确认行为矩阵。每完成 TDD 的一个阶段后查此矩阵决定下一步。

## 矩阵

| confirm_mode | test_available | Red 后 | Green 后 | Refactor 后 |
|-------------|-----------------|--------|----------|------------|
| `auto` | `true` | 自动 → Green | 自动 → Refactor | 自动 → 下一 task |
| `auto` | `false` | 提示用户 + 自动 → Green | 提示用户 + 自动 → Refactor | 自动 → 下一 task |
| `per-task` | `*` | 自动 → Green | 确认后 → Refactor | 确认后 → 下一 task |
| `per-stage` | `*` | 确认后 → Green | 确认后 → Refactor | 确认后 → 下一 task |

`*` = 不区分 test_available。降级流程（`test_available = false`）下用户需手动验证 Red/Green 状态。

## 字段说明

| 字段 | 含义 |
|------|------|
| `auto` | 全自动模式：自动走完所有 task，最后统一确认 |
| `per-task` | 按 task 确认：每个 task 的 Red+Green+Refactor 完成后确认一次 |
| `per-stage` | 按阶段确认：Red、Green、Refactor 每个阶段都确认 |
| `test_available = true` | 自动化流程：编译/测试命令可用 |
| `test_available = false` | 降级流程：编译/测试命令不可用，需用户手动验证 |

## 使用方式

在 Step 3 的每个子步骤（3a Red 后、3b Green 后、3c Refactor 后）查此矩阵，结合当前 `{confirm_mode}` 和 `{test_available}` 决定是自动进入下一步还是等待用户确认。
