# 工作记忆

## 用户信息

- 华为内部工程师，使用 Windows 11
- 偏好结构化分步流程，要求详细文档说明
- 开发工具：OpenCode（内部平台），非 WorkBuddy/Claude Code

## 当前项目

**工程路径：** `d:/application/Google_chrome/谷歌浏览器下载/sdd-task - 2`

**项目描述：** 将 long-task-agent SDD 框架改造为符合部门 IPD/SDD 规范的开发流程范式。

### 改造状态（2026-04-16 完成）

已创建 6 个新 Skill：

| Skill | 职责 |
|-------|------|
| sdd-router | 路由器：检测 AR 目录状态 → 分发阶段 skill |
| sdd-task-requirements | 准备 + 需求澄清：读域知识 + srs.md + tasks.md |
| sdd-task-design | 设计：基于 srs.md 生成 design.md |
| sdd-task-develop | 开发：TDD 逐任务实现（基于 tasks.md）|
| sdd-task-review | 审查：子 Agent 合规性检查（S/D/C 三维）|
| sdd-task-st | ST：验收测试 + 归档 AR |

### 目录结构约定

```
component/
├── AGENTS.md（可选，有则读）
├── include/
├── src/
├── tests/
└── specs/
    ├── component-detail-design/组件_spec.md（已有，必读）
    ├── changes/ARxxx-topic/（进行中 AR：srs.md、design.md、tasks.md）
    └── archive/ARxxx-topic/（归档 AR：srs.md、design.md、st-cases.md）
```

### 关键约定

- design.md 有部门模板（用户待提供，暂用内置模板）
- srs.md 无模板，用内置格式
- tasks.md 用 Markdown 格式（非 JSON）
- AR 编号由用户提供（格式自由）
- ST 通过后：`specs/changes/ARxxx/` → `specs/archive/ARxxx/`（tasks.md 不归档）

### OpenCode 适配（2026-04-18 完成）

`.opencode/` 目录下提供完整的三维适配：

**Command（`.opencode/commands/`）**：6 个 slash command
- `/sdd` — 主入口（自动路由）
- `/sdd-req`、`/sdd-design`、`/sdd-dev [任务ID]`、`/sdd-review`、`/sdd-st` — 各阶段直连

**Agent（`.opencode/agents/`）**：2 个专属代理
- `@sdd-build` — 主流程代理（primary，全工具权限，sdd-* skill allow）
- `@sdd-reviewer` — 只读审查子代理（subagent，全工具关闭，用于 S/D/C 三维审查）

**Plugin**：不适配（OpenCode plugin 是 JS/TS 工具扩展，本流程无需新增原生工具）

使用时将 `.opencode/` 目录整体复制到目标组件工程根目录。

### skill-creator OpenCode 适配（2026-04-22 完成）

将 skill-creator 的 3 个 Python 脚本从 `claude -p` CLI 改造为 `opencode run` CLI：
- `run_eval.py`：`claude -p` → `opencode run --format json`，`.claude/` → `.opencode/`
- `improve_description.py`：`claude -p` → `opencode run --format default`
- `run_loop.py`：import 更新

### SDD Skill 高优先级 Bug 修复（2026-05-17）

**1. sdd-task-develop Step 2b：删除 long-task-guide.md 残留引用**
- 原引用：`(从 AGENTS.md 或 long-task-guide.md 或 CMakeLists.txt 读取)`
- 修改：删除 `long-task-guide.md`，改为 `(从 AGENTS.md 或 CMakeLists.txt 读取)`
- 原因：Linux 远端工程无此文件

**2. sdd-task-st Step 7b：删除 PowerShell 归档命令**
- 原内容：同时提供 PowerShell（Windows）和 bash（Linux/macOS）两套命令
- 修改：只保留 bash 版本，删除 PowerShell 部分
- 原因：远端 Linux 环境无 PowerShell，混写易导致 Agent 选错命令

### Loop Engineering 集成（2026-07-01 完成）

将 SDD 从线性指令集升级为嵌套循环系统，参考 2026 年 AI Agent 编程范式。

**新增 Skill：**
- `sdd-meta-loop` — 五层嵌套循环编排器（263 行）

**Eval 基础设施：**
- `lib/eval/protocol.md` — 统一 Eval 协议（JSON Schema、评分规则、Escalation）
- `lib/eval/requirements-eval.md`、`design-eval.md`、`develop-eval.md`、`review-eval.md`、`st-eval.md` — 5 个阶段 Eval 模板
- `lib/eval/runner.md` — Eval 执行器指南

**改造的 Skill（Phase C）：**
- sdd-task-requirements：新增 Step 8（阶段 Eval）→ 原 Step 8 改为 Step 9
- sdd-task-design：新增 Step 8（阶段 Eval）→ 原 Step 8 改为 Step 9；返工模式新增 Eval
- sdd-task-develop：新增 Step 4d（Task级+阶段级 Eval）
- sdd-task-review：Step 4 新增 4d（Eval JSON 规范化）
- sdd-task-st：Step 6 新增 6a（Eval JSON 规范化）

**升级的插件（Phase D）：**
- sdd-compaction.js v1.1.0：Loop 模式感知（检测 `eval/` 目录、注入 Eval 历史、注入 Escalation 上下文）

**启用方式：** `/sdd` 启动时 AskUserQuestion 选择 Classic 或 Loop 模式。Loop 模式下 Meta-Loop 自动驱动所有阶段。Classic 模式不受影响。
