---
name: sdd-task-develop
description: "Use when design.md exists and tasks.md has pending tasks - implement code following TDD discipline, one task per cycle"
---

# SDD 代码开发 — 按任务 TDD 实现

基于已批准的 design.md 和 tasks.md，通过 TDD 方式逐任务实现代码。

**核心原则：** 一个开发会话只完成一个任务；每个任务严格按照 design.md 实现；质量门禁不可绕过。

<HARD-GATE>
不得跳过任何任务，不得在测试未通过的情况下标记任务完成，不得绕过质量门禁。
</HARD-GATE>

## Checklist

你必须为以下每个步骤创建 TodoWrite 任务，并按顺序完成：

1. **确认模式选择（Confirm Mode）** — 首次运行时询问用户确认粒度
2. **定向（Orient）** — 读取 tasks.md、design.md，选取当前任务
3. **启动（Bootstrap）** — 确认开发环境，读取组件规范，检测测试命令可用性
4. **TDD 循环** — 3a Red（子 Agent 写测试）→ 3b Green（主 Agent 写实现）→ 3c Refactor
5. **质量门禁 + Eval** — 覆盖率验证 + Task Eval（Loop 模式）
6. **持久化（Persist）** — 更新 tasks.md，提交代码
7. **结束会话** — 输出完成摘要

---

## 路径解析规则

本 Skill 需要读取 Eval 协议和 Develop Eval 模板。按以下优先级查找：

| 文件类型 | 本地路径（组件工程） | 全局路径（回退） |
|---------|---------------------|-----------------|
| Eval 协议 | `lib/eval/protocol.md` | `~/.config/opencode/lib/eval/protocol.md` |
| Develop Eval | `lib/eval/develop-eval.md` | `~/.config/opencode/lib/eval/develop-eval.md` |
| TDD-Test Prompt | `lib/references/sdd-task-develop/tdd-test-prompt.md` | `~/.config/opencode/lib/references/sdd-task-develop/tdd-test-prompt.md` |
| 确认行为矩阵 | `lib/references/sdd-task-develop/confirm-matrix.md` | `~/.config/opencode/lib/references/sdd-task-develop/confirm-matrix.md` |
| 错误处理 | `lib/references/sdd-task-develop/error-handling.md` | `~/.config/opencode/lib/references/sdd-task-develop/error-handling.md` |

**查找逻辑：** 先检查本地路径是否存在，若不存在则读取全局路径。

---

## Step 0：确认模式选择（新增）

在首次运行 sdd-task-develop 时（Step 1 之前），通过 AskUserQuestion 询问用户确认粒度：

**问题**：「TDD 开发流程中，你希望如何确认进度？」

| 选项 | 标签 | 说明 |
|------|------|------|
| 模式 1 | 全自动模式 | 自动走完所有 task，不管 TDD 失败或缺少编译命令，最后统一确认 |
| 模式 2 | 按 task 确认（推荐） | 每个 task 的 Red+Green+Refactor 完成后，确认一次再进入下一 task |
| 模式 3 | 按阶段确认 | 每个 task 的 Red、Green、Refactor 每个阶段都确认 |

- 默认推荐**模式 2**（按 task 确认）
- 用户选择后，记录到变量 `{confirm_mode}`：
  - `auto`：全自动模式
  - `per-task`：按 task 确认
  - `per-stage`：按阶段确认
- 不需要持久化到文件，单次会话有效

---

## Step 1：定向（Orient）

### 1a. 读取当前状态

读取 `specs/changes/ARxxx-topic/tasks.md`：
- 找到所有 `status: pending` 的任务
- 按依赖关系和 ID 顺序，选取可执行的第一个任务（所有前置依赖均为 `passing`）
- 如果没有满足依赖的任务，报告循环依赖并请用户决定

记录选定的任务 ID（如 T002）。

### 1b. 读取设计文档

读取 `specs/changes/ARxxx-topic/design.md`，找到对应的设计节：
- 接口设计（§3）
- 算法/流程（§4）
- 边界条件矩阵（§5）
- 错误处理（§6）
- 测试设计（§7）

将对应的设计内容记录为 `{design_section}`，供后续 TDD 使用。

### 1c. 读取 srs.md 对应需求

读取 `specs/changes/ARxxx-topic/srs.md`，找到与当前任务关联的功能需求，提取验收标准（Given/When/Then）记录为 `{srs_section}`。

### 1d. 读取 AGENTS.md（如存在）

读取组件根目录的 AGENTS.md，确认：
- 代码风格要求
- 测试框架（如 gtest/gmock）
- 构建方式
- 其他开发约束

### 1e. 扫描相关代码

读取将要修改的现有源文件（`include/`、`src/`），理解当前实现。

**文档查找协议（Document Lookup Protocol）：**

定向完成后，手头应有：
- `{task}` — 当前任务对象（ID、描述、依赖）
- `{design_section}` — design.md 中对应的设计节全文
- `{srs_section}` — srs.md 中对应的功能需求全文
- `{confirm_mode}` — 用户选择的确认模式（`auto` / `per-task` / `per-stage`）

---

## Step 2：启动（Bootstrap）

### 2a. 开发环境检查

确认：
- 编译工具链可用（如 cmake / make / gcc / clang）
- 测试框架已安装（如 gtest/gmock）
- 如有 `init.sh` / `init.ps1`，且环境未就绪，执行一次

### 2b. 确认测试命令（关键：检测可用性）

确认以下命令可用（从 AGENTS.md 或 CMakeLists.txt 读取）：
- 编译命令
- 测试执行命令
- 覆盖率生成命令（如使用 gcov/lcov）

**记录这些命令，并判断可用性：**

1. **读取 AGENTS.md**（如存在）：提取测试编译命令和测试执行命令
2. **读取 CMakeLists.txt**（如存在）：提取测试目标名称
3. **判断**：
   - **有命令且可用** → 设置 `{test_available} = true`，走**自动化流程**
   - **无命令或不可用** → 设置 `{test_available} = false`，走**降级流程**

记录 `{test_available}` 和具体的编译/测试命令，后续 Step 3a/3b/4a 直接使用。

### 2c. 冒烟测试

运行现有测试，确认之前已通过的任务没有回归。任何失败 → **停止**，先修复再继续。

---

## Step 3：TDD 循环（3a Red → 3b Green → 3c Refactor）

严格按照 design.md 中的 `{design_section}` 实现，不得自行发明接口或逻辑。

### 确认行为矩阵（`{confirm_mode}` × `{test_available}`）

读取 `lib/references/sdd-task-develop/confirm-matrix.md`（按"路径解析规则"查找）获取完整矩阵，按当前模式决定每步确认行为。

### 3a. Red — 派发测试编写 Agent（独立子 Agent）

**主 Agent 行为**：准备上下文 + 派发子 Agent，不自己写测试。

#### 3a.1 收集测试编写上下文（主 Agent 做）

- `{design_section}`：design.md 对应节（§3 接口、§5 边界条件、§7 测试设计）
- `{srs_section}`：srs.md 对应功能需求的 Given/When/Then
- `{task}`：当前任务 ID 和描述
- `AGENTS.md`（如存在）：提取测试框架、命名规范
- `CMakeLists.txt`（如存在）：提取测试目标名称

#### 3a.2 派发 TDD-Test 子 Agent（主 Agent 做）

**子 Agent 职责**：
- 子 Agent **只写测试文件**，严格按 `{design_section}` + `{srs_section}`
- 子 Agent **不得写任何实现代码**（实现文件即使有 stub 也要删除或留空）
- 子 Agent 在测试写完后输出：修改的文件列表、测试函数清单

**派发方式**：读取 `lib/references/sdd-task-develop/tdd-test-prompt.md`（按"路径解析规则"查找），将占位符 `{ar_id}`、`{task_id}`、`{task_description}`、`{design_section}`、`{srs_section}`、`{test_framework}`、`{test_file_naming}` 替换为实际值，作为 `Agent()` 调用的 `prompt` 参数。

#### 3a.3 Red 后行为

根据 **确认行为矩阵** 中的 "Red 后" 列决定：

**自动化流程（`{test_available} = true`）**：
- 子 Agent 写测试 → 主 Agent 编译并运行测试 → 确认 Red（失败）
- 按矩阵决定是否确认后进入 3b

**降级流程（`{test_available} = false`）**：
- 子 Agent 写测试 → 告知用户测试文件路径
- `per-task` / `per-stage`：等待用户确认 Red 状态后进入 3b
- `auto`：提示用户"测试已写好，请手动验证"，自动进入 3b

### 3b. Green — 主 Agent 编写实现

收到 Step 3a 的输出后：

1. 读取 TDD-Test Agent 生成的测试文件，理解测试意图
2. 按 design.md `{design_section}` 写最少实现代码让测试通过
3. **自动化流程（`{test_available} = true`）**：编译并运行测试确认 Green
4. **降级流程（`{test_available} = false`）**：告知用户测试文件路径，请用户自行验证 Green
5. 根据**确认行为矩阵**的 "Green 后" 列决定是否确认后进入 3c

**如果测试失败超过 3 次：**
1. 收集错误信息
2. 对照 design.md 检查是否有理解偏差
3. 如果是 design.md 有歧义 → 通过 AskUserQuestion 请用户澄清，不得自行猜测
4. 记录调试过程

### 3c. Refactor — 重构提升质量

在测试仍然全部通过的前提下：
- 消除重复代码
- 改善变量/函数命名（符合 AGENTS.md 规范）
- 拆分过长函数（单一职责）
- 添加必要注释（不解释显而易见的代码，解释「为什么」）
- 不改变接口签名（design.md 已定义）

每次小重构后重新运行测试，保持 Green。

根据**确认行为矩阵**的 "Refactor 后" 列决定是否确认后进入下一 task。

---

## Step 4：质量门禁

### 4a. 测试覆盖率

**自动化流程（`{test_available} = true`）**：
- 运行覆盖率工具，检查当前任务涉及的代码
- 语句覆盖率 >= design.md §7.2 中指定的目标（无指定则 >= 80%）
- 分支覆盖率 >= design.md §7.2 中指定的目标（无指定则 >= 70%）
- 未达标时：
  - 识别未覆盖的行/分支
  - 检查是否是 design.md 中的边界条件矩阵（§5）没有写对应测试 → 补写测试
  - 不得通过注释掉代码或降低标准来通过覆盖率检查

**降级流程（`{test_available} = false`）**：
- 覆盖率验证延后，用户在验证 Green 时一并确认
- 代码规范自查仍由主 Agent 做

### 4b. 编译警告

确认无新增的编译警告（原有的忽略，新引入的必须解决）。

### 4c. 代码规范

对照 AGENTS.md 的代码规范做自查：
- 命名规范符合要求
- 文件头注释格式（如有要求）
- 包含守卫（头文件）

### 4d. 阶段/Task Eval（Loop 模式）

> Meta-Loop 模式下，Meta-Loop 的 PHASE_LOOP 也会独立运行 Eval。本节作为质量自查，两者互补不冲突。
> Classic 模式跳过。

**Task 级 Eval**（每个 task 的 Step 4 完成后）：

1. 收集 Eval 输入：测试退出码 + 覆盖率数据 + 当前 task 对应 design.md 节 + 修改文件列表
2. 派发 Eval 子 Agent：
```
Agent(
  description = "Develop Eval: Task [{task_id}]",
  prompt = """
你是一名 HarnessX Eval 评估专家。按照 develop-eval.md（按"路径解析规则"查找）评估当前 task：
- AR: {ar_id}，Task: {task_id}，描述: {task_description}
- 测试结果: {test_pass_or_fail}，覆盖率: {coverage}
- 设计参考: {design_section}，修改文件: {changed_files}
评估维度：测试通过率 / 覆盖率达标 / 设计一致性 / 代码规范
输出：JSON（按 Eval 协议格式，参见"路径解析规则"），确定性维度用传入数据判定。
"""
)
```

3. 处理结果：
   - `next` → 进入 Step 5
   - `retry` → 回到 Step 3b/3c 修正，重新 4d Eval
   - `escalate` → 向用户呈现 blocking_issues

4. 存储：`specs/changes/{ar_dir}/eval/eval-develop-{task_id}.json`

**阶段级 Eval**（所有 task 完成后）：Loop 模式自动汇总所有 task Eval 结果输出阶段结论。

---

## Step 5：持久化（Persist）

### 5a. 更新 tasks.md

将当前任务状态更新为 `passing`：

```markdown
| T002 | [任务描述] | T001 | passing | YYYY-MM-DD 完成 |
```

在 tasks.md 末尾「进度记录」节追加本会话记录：

```markdown
### YYYY-MM-DD 会话记录

- 完成任务：T002 [任务描述]
- 修改文件：[列表]
- 测试覆盖率：语句 XX%，分支 XX%（自动化流程）/ 未自动验证（降级流程）
- Red Agent：TDD-Test 子 Agent
- Green Agent：主 Agent
- 备注：[如有]
```

### 5b. 提交代码

```
git add [修改的文件]
git commit -m "feat(ARxxx): [任务描述简短标题]

- Implements: T002
- Related: srs.md §3.x
- Coverage: branch XX%, stmt XX% (自动化流程) / 未自动验证 (降级流程)"
```

---

## Step 6：结束会话

输出本次会话完成摘要：

```
任务 T002 ([任务描述]) — 完成

修改文件：
  - include/xxx.h（新增接口）
  - src/xxx.cpp（实现）
  - tests/xxx_test.cpp（X 个测试用例）

覆盖率：语句 XX%，分支 XX%（自动化流程） / 未自动验证（降级流程）

下一步：
  - [下一个 pending 任务 ID 和描述]
  - [若所有任务 passing] → 运行 sdd-task-review 进行合规性检查
```

**一个会话只完成一个任务。** 多任务自动化由外部循环脚本处理（如适用）。

若所有任务均为 `passing`，输出：
> 所有 AR 任务已完成 — 下一步进入合规性检查（sdd-task-review）。

---

## 调试规范（On Error）

读取 `lib/references/sdd-task-develop/error-handling.md`（按"路径解析规则"查找）获取完整调试规范。

---

## 关键规则

- **一个会话只完成一个任务** — 不要在一个会话中完成多个任务
- **严格按 design.md 实现** — 不得自行改变接口签名或算法
- **Red/Green 分离** — Red（写测试）和 Green（写实现）由不同 Agent 执行，防止自我验证
- **质量门禁是硬性要求** — 不得以任何理由跳过
- **发现 design.md 有歧义 → 停止，问用户** — 不得自行猜测；若设计本身有误，通知用户执行 `/sdd-design` 返工
- **发现 srs.md 验收标准不可测/需求有误 → 通过 AskUserQuestion 上报，用户确认后执行 `/sdd-req` 返工**
- **测试命令不可用 → 进入降级流程** — 让用户手动验证 Red/Green

## 开发中途返工流程

读取 `lib/references/sdd-task-develop/error-handling.md`（按"路径解析规则"查找）获取完整返工流程。

## 红旗警告

读取 `lib/references/sdd-task-develop/error-handling.md`（按"路径解析规则"查找）获取完整红旗警告列表。

## 集成说明

**调用方：** sdd-router（design.md 存在，tasks.md 有 pending 任务时）
**链接到：** sdd-task-review（所有任务 passing 后，由 sdd-router 路由）
**读取：** `specs/changes/ARxxx-topic/design.md`、`specs/changes/ARxxx-topic/srs.md`、`specs/changes/ARxxx-topic/tasks.md`、`AGENTS.md`、`include/`、`src/`
**产出：** 修改后的源文件和测试文件；更新后的 `tasks.md`

## 降级流程的边界条件

读取 `lib/references/sdd-task-develop/error-handling.md`（按"路径解析规则"查找）获取完整降级流程边界条件。

> **设计原则**：降级流程的核心价值是"测试不由写实现的人验证"。如果用户也无法跑测试，至少有两次用户参与（Red 确认 + Green 确认），仍然大幅降低了自欺风险。完全跳过验证是最后兜底选项。
