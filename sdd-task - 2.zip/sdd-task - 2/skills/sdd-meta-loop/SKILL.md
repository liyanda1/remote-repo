---
name: sdd-meta-loop
description: "SDD Loop Engineering orchestrator — runs all 5 phases as self-evaluating loops. Use when you want autonomous quality-gated execution."
---

<EXTREMELY-IMPORTANT>
你是一个 SDD Meta-Loop 编排器。你的任务是驱动 5 个阶段的循环执行，每个阶段通过 Eval 机制自评质量，达标才进入下一阶段。

这不是可商量的——你必须严格按 Loop 模式执行：
1. 启动阶段 Phase Loop
2. 等待阶段产出
3. 运行 Eval 评估
4. 根据 Eval 结果决定：下一阶段 / 重试 / 升级给人
</EXTREMELY-IMPORTANT>

---

## 路径解析规则

本 Skill 需要读取各阶段的 Eval 模板。按以下优先级查找：

| 文件类型 | 本地路径（组件工程） | 全局路径（回退） |
|---------|---------------------|-----------------|
| Eval 协议 | `lib/eval/protocol.md` | `~/.config/opencode/lib/eval/protocol.md` |
| Requirements Eval | `lib/eval/requirements-eval.md` | `~/.config/opencode/lib/eval/requirements-eval.md` |
| Design Eval | `lib/eval/design-eval.md` | `~/.config/opencode/lib/eval/design-eval.md` |
| Develop Eval | `lib/eval/develop-eval.md` | `~/.config/opencode/lib/eval/develop-eval.md` |
| Review Eval | `lib/eval/review-eval.md` | `~/.config/opencode/lib/eval/review-eval.md` |
| ST Eval | `lib/eval/st-eval.md` | `~/.config/opencode/lib/eval/st-eval.md` |
| Eval Runner | `lib/eval/runner.md` | `~/.config/opencode/lib/eval/runner.md` |

**查找逻辑：** 先检查本地路径是否存在，若不存在则读取全局路径。

---

## Step 1：加载全局配置

在运行任何阶段之前，先确认全局参数。

### 1a. 默认配置（内存中，不写入文件）

以下为 Meta-Loop 的默认配置。所有值均为内存变量，不依赖外部文件：

```
config = {
  loop_mode: true,                    // 始终为 true（Meta-Loop 激活即代表 Loop 模式）
  confirm_mode: "per-phase",          // 默认：每阶段确认
  global_max_iterations: 3,           // 每阶段最大重试次数
  quality_threshold: 80,              // Eval 最低质量标准（百分制）
  max_total_cost_usd: 20,             // 全局成本上限
  escalation_behavior: "pause",       // 升级后等待用户决策
  phases: ["requirements", "design", "develop", "review", "st"],
  current_phase: "requirements",
  eval_results: {}                    // 运行时填充
}
```

### 1b. 确认模式（默认，无需询问）

> `sdd-router` 已通过 AskUserQuestion 让用户选择了 Classic vs Loop 模式。进入 Meta-Loop 后不再重复询问确认粒度，默认使用 `per-phase`（每个阶段完成后暂停确认）。

如果需要调整，可在运行时通过对话告知 Meta-Loop 切换到 `auto` 或 `per-loop`。除此之外不做额外询问。

---

## Step 2：阶段 Loop 主循环

```
FOR phase IN phases:
  IF current_phase > phase 的索引: SKIP（已完成）
  
  result = PHASE_LOOP(phase, AR)
  
  IF result.recommendation == "escalate":
    ESCALATE(phase, result)
    IF confirm_mode == "auto" AND phase is NOT critical:
      LOG("跳过 {phase}，继续下一阶段")
      CONTINUE
    ELSE:
      等待用户决定：retry | skip | abort
  
  IF result.recommendation == "next":
    IF confirm_mode == "per-phase":
      AskUserQuestion(f"{phase} 阶段完成，Eval 评分 {result.score}。进入下一阶段？")
    IF confirm_mode == "auto":
      自动进入下一阶段
    
    CONTINUE
  
  IF result.recommendation == "archive":
    // ST 阶段完成
    执行归档操作
    RETURN "complete"
```

---

## Step 3：PHASE_LOOP 模板

每个阶段 Loop 的核心逻辑：

```
PHASE_LOOP(phase, AR):
  max_iter = config.global_max_iterations
  
  FOR iteration IN [1..max_iter]:
    // 3a: 调用阶段 Skill
    invoke_phase_skill(phase, AR, iteration)
    
    // 3b: Eval 评估
    eval_result = run_eval(phase, AR, iteration)
    
    // 3c: 存储 Eval 结果
    save_eval_result(eval_result, phase, iteration)
    
    // 3d: 决策
    IF eval_result.overall == "pass":
      mark_phase_complete(phase)
      RETURN eval_result
    
    IF eval_result.overall == "fail" AND iteration < max_iter:
      // 根据 Eval 反馈修正
      apply_corrections(eval_result)
      CONTINUE
    
    IF eval_result.overall == "fail" AND iteration == max_iter:
      RETURN {recommendation: "escalate", ...eval_result}
```

### 3a: invoke_phase_skill

| 阶段 | 调用的 Skill |
|------|-------------|
| requirements | `sdd-router:sdd-task-requirements` |
| design | `sdd-router:sdd-task-design` |
| develop | `sdd-router:sdd-task-develop` |
| review | `sdd-router:sdd-task-review` |
| st | `sdd-router:sdd-task-st` |

### 3b: run_eval

> **双重 Eval 优先级规则**：阶段 Skill（如 sdd-task-design）内部也会运行一次 Eval（质量自查），Meta-Loop 在此独立运行第二次 Eval。两次结果可能不一致。**Meta-Loop Eval 具有最终仲裁权**——当两者冲突时，以 Meta-Loop Eval 的结论为准。Skill 级 Eval 仅作为预过滤减少无意义的 Meta-Loop 迭代。

| 阶段 | Eval 类型 | Eval 模板文件（按"路径解析规则"查找） |
|------|----------|-------------|
| requirements | LLM Eval | `requirements-eval.md` |
| design | LLM Eval | `design-eval.md` |
| develop | 确定性 Eval（测试） | `develop-eval.md` |
| review | 子 Agent Eval | `review-eval.md` |
| st | 确定性 Eval（用例比对） | `st-eval.md` |

**LLM Eval 执行方式**：
- 读取 Eval 模板文件中的 prompt
- 在独立上下文中运行评估（避免主 Agent 自评 bias）
- 输出 JSON 格式结果

**确定性 Eval 执行方式**（develop/st）：
- 直接运行测试命令
- 比较测试输出与预期
- 生成 Eval 结果 JSON

### 3c: save_eval_result

```
specs/changes/{AR}/eval/
├── eval-requirements-1.json
├── eval-requirements-2.json
├── eval-design-1.json
├── eval-develop-task-T001-1.json
├── eval-develop-phase-1.json
├── eval-review-1.json
├── eval-review-2.json
├── eval-st-1.json
└── eval-st-2.json
```

### 3d: apply_corrections

当 Eval fail 时，根据 `dimensions[].fix_hint` 采取修正行动：
1. 读取 `fix_hint` 中指定的 Skill 文件
2. 定位对应 Step
3. 执行修正步骤
4. 回到 invoke_phase_skill 重新执行

---

## Step 4：Escalation 升级处理

当 `recommendation == "escalate"` 时：

```
ESCALATE(phase, result):
  输出以下信息给用户：
  
  ⚠️ 阶段 {phase} 未达标（{result.iteration}/{result.max_iterations} 次迭代）
  
  评分：{result.score}/100
  失败维度：{列出所有 failed dimensions}
  
  阻塞问题：
  {for each issue in result.blocking_issues}
  
  已完成维度：{列出所有 passed dimensions}
  
  建议操作：
  1. retry — 重新执行 {phase} 阶段（将重置迭代计数）
  2. skip — 跳过此阶段，继续下一阶段（仅非关键阶段）
  3. abort — 终止整个 HarnessX 流程
  
  你的选择？
```

---

## Step 5：阶段完成和归档

### 5a. ST 阶段通过后

```bash
# 归档 AR
cp -r specs/changes/ARxxx-topic specs/archive/ARxxx-topic
rm -rf specs/changes/ARxxx-topic
```

### 5b. 生成最终报告

```
SDD Meta-Loop 完成报告
═══════════════════════
AR: ARxxx-topic
总迭代次数: {total_iterations}
总耗时: {duration}

阶段评估摘要:
  requirements: pass (85/100, {n} iterations)
  design: pass (90/100, {n} iterations)
  develop: pass (95/100, {n} task-level iterations)
  review: pass (88/100, {n} iterations)
  st: pass (95/100, {n} iterations)

Eval 详情: specs/changes/ARxxx-topic/eval/
归档位置: specs/archive/ARxxx-topic/
```

---

## 快速参考：各阶段调用的实际 Skill

```
requirements → Skill("sdd-router:sdd-task-requirements")
design       → Skill("sdd-router:sdd-task-design")
develop      → Skill("sdd-router:sdd-task-develop")
review       → Skill("sdd-router:sdd-task-review")
st           → Skill("sdd-router:sdd-task-st")
```

> 注意：实际调用时使用对应平台的 Skill 调用方式。
> OpenCode: `/sdd-req`, `/sdd-design`, `/sdd-dev`, `/sdd-review`, `/sdd-st`
> WorkBuddy: `Skill` tool

---

## 关键规则

1. **Eval 必须在独立上下文中运行**：LLM Eval 不能在主对话中执行，必须启动独立会话评估
2. **Eval 结果必须保存到文件**：每个阶段的每次迭代的 Eval 结果写入 `specs/changes/{AR}/eval/`
3. **Escalation 不能自动跳过关键阶段**：design、develop 是关键的，escalation 后必须等用户决策
4. **Compaction 主动触发**：阶段切换时主动 compact（释放上下文）
5. **遵从 confirm_mode**：严格按用户选择的确认粒度暂停
6. **保留完整的修正参考**：修正时参考原 Skill 的步骤内容，而非凭空想象
