---
name: sdd-task-requirements
description: "Use when starting a new AR or when srs.md/tasks.md is missing - read component domain knowledge, elicit and clarify requirements, produce srs.md and tasks.md for the AR"
---

# SDD 需求准备 & 澄清 — 准备阶段 + 需求澄清

在进行任何设计或开发之前，必须完成两件事：**建立领域知识**（读懂当前工程）、**澄清 AR 需求**（理解这次要做什么）。

<HARD-GATE>
在 srs.md 和 tasks.md 未生成并得到用户确认之前，不得调用任何设计 skill、不得生成 design.md、不得编写任何代码。
</HARD-GATE>

## Checklist

你必须为以下每个步骤创建 TodoWrite 任务，并按顺序完成：

1. **建立领域知识** — 读取组件详设、AGENTS.md、代码结构
2. **获取 AR 基本信息** — AR 编号、主题、背景 SR/AR 来源
3. **需求澄清** — 通过结构化提问理解 AR 的具体需求
4. **生成 srs.md** — 需求设计说明书
5. **生成 tasks.md** — 任务分解与状态跟踪
6. **用户确认** — 呈现文档，等待用户批准
7. **保存文档** — 写入 `specs/changes/ARxxx-topic/`
8. **阶段 Eval（Loop 模式）** — 派发子 Agent 评估 srs.md 质量；不达标修正重试
9. **移交设计阶段** — 调用 `sdd-router:sdd-task-design`

**终态是调用 sdd-task-design。** 不要调用其他 skill。

---

## 路径解析规则

本 Skill 需要读取若干模板和 Eval 文件。这些文件可能位于**本地组件工程**或**全局 OpenCode 配置目录**。按以下优先级查找：

| 文件类型 | 本地路径（组件工程） | 全局路径（回退） |
|---------|---------------------|-----------------|
| SRS 模板 | `specs/templates/srs-template.md` | `~/.config/opencode/specs/templates/srs-template.md` |
| Tasks 模板 | `specs/templates/tasks-template.md` | `~/.config/opencode/specs/templates/tasks-template.md` |
| Eval 协议 | `lib/eval/protocol.md` | `~/.config/opencode/lib/eval/protocol.md` |
| Requirements Eval | `lib/eval/requirements-eval.md` | `~/.config/opencode/lib/eval/requirements-eval.md` |

**查找逻辑：** 先检查本地路径是否存在，若不存在则读取全局路径。全局路径的基准目录为 `~/.config/opencode/`（Windows 下为 `%USERPROFILE%\.config\opencode\`）。

---

## Step 1：建立领域知识（Domain Knowledge）

这是整个流程的基础。在理解需求之前，必须先理解当前工程的背景。

### 1a. 读取组件详细设计

查找并读取 `specs/component-detail-design/` 目录下的组件详设文件（`*_spec.md` 或类似名称）。

从中提取：
- 组件职责和边界
- 核心模块/子系统及其关系
- 主要数据结构和接口（如有）
- 设计约束和原则
- 现有功能模块清单

如果文件不存在：记录「组件详设缺失」，继续后续步骤，并在 srs.md 中标注。

### 1b. 读取 AGENTS.md（如存在）

读取组件根目录下的 `AGENTS.md`（如存在），提取：
- 开发规范（命名规范、代码风格、目录约定）
- AI Agent 工作约束
- 特殊构建要求

如果不存在，跳过此步骤。

### 1c. 扫描代码结构

扫描 `include/`、`src/`、`tests/` 目录结构（不需要逐行读取所有代码），理解：
- 现有头文件/接口定义（`include/`）
- 主要源文件模块（`src/`）
- 测试文件组织（`tests/`）
- 现有 specs/changes/ 中已有的 AR 目录（了解历史变更）

### 1d. 形成领域知识摘要

整理以上信息，在脑内形成：
- 组件当前的核心能力
- 主要模块的职责划分
- 代码组织方式
- 与本次 AR 相关的现有接口/模块

> **目的**：后续的需求澄清必须在这个上下文中进行，才能提出有意义的问题和判断需求的合理性。

---

## Step 2：获取 AR 基本信息

询问用户以下基本信息（可合并为一次提问）：

```
1. AR 编号是什么？（格式示例：AR001、AR-20260416）
2. AR 的主题简述（用于目录命名，如：add-retry-mechanism）
3. 这个 AR 对应的 SR 是什么？（SR 编号或简述，没有可跳过）
4. AR 的背景：为什么需要做这个需求？（用户痛点 / 系统缺陷 / 新业务场景）
```

根据回答，确定 AR 目录名称：`ARxxx-topic`（如 `AR001-add-retry-mechanism`）。

如果目录不存在，创建：`specs/changes/ARxxx-topic/`

---

## Step 3：需求澄清（Requirements Elicitation）

> 这部分复用并适配自 long-task-requirements 的结构化提问方法。

在已建立的领域知识基础上，通过多轮提问澄清 AR 需求。

**提问原则：**
- 每轮最多 4 个相关问题，避免认知过载
- 提供选项降低用户负担，但允许自由输入
- 先假设后确认（"我理解你需要 X，对吗？"）
- 立刻量化模糊词（"性能要求"→"具体响应时间阈值？"）

### Round 1：需求范围与目标

一次 AskUserQuestion 包含（最多 4 个）：
- 这个 AR 需要实现的核心功能是什么？（改什么 / 加什么 / 修什么）
- 影响的模块范围（哪些文件/接口会改动）？
- 是否有明确的性能/可靠性要求？
- 是否有不做的约束（exclusion）？

### Round 2：功能细节

针对 Round 1 揭示的核心功能，进一步澄清：
- 输入/触发条件是什么？
- 系统期望的响应/行为是什么？
- 错误/异常情况如何处理？
- 是否有具体的验收标准（Given/When/Then）？

### Round 3：接口与集成约束

- 是否需要新增或修改对外接口（头文件 / API）？
- 是否依赖外部组件或库？
- 与现有模块的集成方式有无约束？
- 是否有兼容性要求（向后兼容 / ABI 稳定性）？

### Round 4（按需）：术语与边界条件

- 是否有领域术语需要统一定义？
- 特殊边界条件或极端情况？

**停止条件：** 当你能清楚描述 AR 的每一个功能点、其验收标准、影响范围，不需要猜测时，进入**暂停点**：

> **暂停点：** Agent 向用户输出需求澄清摘要（功能点清单 + 关键约束 + 影响），并明确询问：**"以上需求理解是否完整？还有需要补充或修改的吗？"**
>
> - 用户确认无补充 → 进入 Step 4
> - 用户提出补充 → 继续澄清，满足停止条件后再次进入暂停点
> - 用户只是问了个问题但没说可以继续 → 回答问题后继续等待确认，**不得自动进入下一步**

---

## Step 4：生成 srs.md（需求设计说明书）

srs.md 是对 AR 需求的结构化描述，不是完整的系统需求规格。内容应简洁聚焦，突出「这个 AR 要做什么」。

**srs.md 模板（无部门模板时使用）：**

按"路径解析规则"查找 SRS 模板（本地 `specs/templates/srs-template.md` 或全局路径），按模板结构填写 AR 需求内容。

> 如果用户提供了部门模板，读取模板后按模板结构填写内容。

---

## Step 5：生成 tasks.md（任务状态跟踪）

tasks.md 是本次 AR 开发任务的分解与状态跟踪文件，供 `sdd-task-develop` 消费。

**任务分解原则：**
- 每个任务对应一个独立可测试的功能点
- 粒度：一个开发会话可完成 1-3 个任务
- 任务之间有依赖时明确标注

**tasks.md 格式：**

按"路径解析规则"查找 Tasks 模板（本地 `specs/templates/tasks-template.md` 或全局路径），按模板结构生成 tasks.md。

> 任务 ID 格式为 `T001`、`T002`...，按顺序分配。

---

## Step 6：用户确认

向用户呈现生成的 srs.md 和 tasks.md 草稿，逐节确认：

1. **背景与目标** — 理解是否准确？
2. **功能需求** — 覆盖全面？验收标准可测试？
3. **任务分解** — 粒度合理？依赖关系正确？

对于非简单 AR（3 个以上功能点），逐节呈现并等待反馈，逐节修改后再进行下一节。
对于简单 AR（1-2 个功能点），一次性呈现全部内容，等待一次性批准。

**收到批准后才能进入 Step 7。**

> **暂停点：** 用户反馈修改意见时，Agent 修改后继续等待确认；若用户只是提问，回答后继续等待确认，**不得自动进入 Step 7**。只有用户明确说"确认"/"没问题"/"OK"等才可继续。

---

## Step 7：保存文档

将批准的文档写入 AR 目录：

```
specs/changes/ARxxx-topic/srs.md      ← 需求设计说明书
specs/changes/ARxxx-topic/tasks.md    ← 任务跟踪文件
```

确认文件写入成功后继续。

---

## Step 8：阶段 Eval（Loop 模式）

> Meta-Loop 模式下，Meta-Loop 的 PHASE_LOOP 也会独立运行 Eval。本节作为质量自查，两者互补不冲突。
> Classic 模式跳过此节，直接进入 Step 9。

### 8a. 派发 Eval 子 Agent

使用子 Agent 独立上下文运行 requirements-eval：

```
Agent(
  description = "Requirements Eval: AR [{ar_id}]",
  prompt = """
你是一名 HarnessX Eval 评估专家。请按照 requirements-eval.md（按"路径解析规则"查找）中的评估模板，
对以下文件进行需求阶段质量评估：

- srs.md: specs/changes/{ar_dir}/srs.md
- tasks.md: specs/changes/{ar_dir}/tasks.md

评估维度（详见 requirements-eval.md）：
1. 域知识覆盖 — srs.md 是否基于组件详设和代码结构
2. 澄清完整性 — 所有功能需求是否有清晰的触发/行为/异常/验收标准
3. 需求一致性 — 需求之间无矛盾
4. 可测试性 — 每个验收标准（Given/When/Then）可独立验证
5. TBD/TODO 扫描 — srs.md 中无未解决的 TBD/TODO

请严格按照 Eval 协议（按"路径解析规则"查找）输出 JSON 格式的评估结果。
"""
)
```

### 8b. 处理 Eval 结果

解析子 Agent 输出的 JSON，根据 `recommendation` 字段决定：

| recommendation | 含义 | 主 Agent 行为 |
|----------------|------|--------------|
| `next` | Eval 通过 | 进入 Step 9（移交设计阶段） |
| `retry` | 不达标，有迭代余额 | 读取 `failed_dimensions` 的 `fix_hint`，修正 srs.md/tasks.md → 回到 8a 重评 |
| `escalate` | 迭代用尽，仍不达标 | 向用户呈现 blocking_issues + escalation 信息，等待用户决定 |

**重试规则**：最多 3 轮（默认），每次修正针对性解决 `blocking_issues` 中的问题，不修改已通过的维度。

### 8c. 存储 Eval 结果

将 Eval JSON 写入 `specs/changes/{ar_dir}/eval/eval-requirements-{iteration}.json`。

---
## Step 9：移交设计阶段

文档保存 + Eval 通过（Loop 模式）后：

1. 输出移交摘要：
   - AR 编号与主题
   - 功能需求数量
   - 任务数量
   - 关键约束和假设
   - 需要在设计阶段重点关注的技术难点
   - Eval 结果（Loop 模式）：score、通过的维度、迭代轮次

2. **必须调用：** 调用 `sdd-router:sdd-task-design` 开始 AR 详细设计

---

## 扩展指南

| AR 规模 | 功能需求 | 深度 |
|---------|---------|------|
| 小型 | 1-3 个 | 简洁 srs.md，2-4 个任务 |
| 中型 | 4-10 个 | 完整 srs.md 各节，5-10 个任务 |
| 大型 | 10 个以上 | 建议拆分为多个 AR |

## 红旗警告

| 这种想法 | 正确做法 |
|---------|---------|
| "需求很清楚，直接做设计" | 先读组件详设建立领域知识，再做需求澄清 |
| "AGENTS.md 不重要" | 里面有开发规范，必须读取 |
| "srs.md 写详细一点就够了，不用 tasks.md" | tasks.md 是 sdd-task-develop 的执行依据 |
| "先设计再澄清需求" | 需求不清就做设计等于返工 |
| "AR 很简单，一个任务就够了" | 至少拆成可独立验证的最小单元 |

## 集成说明

**调用方：** sdd-router（当 srs.md 或 tasks.md 缺失时）；sdd-task-develop（开发途中发现需求问题，用户确认后）
**链接到：** sdd-task-design（Step 9，需求确认 + Eval 通过后）
**产出：** `specs/changes/ARxxx-topic/srs.md`、`specs/changes/ARxxx-topic/tasks.md`
**Eval（Loop 模式）：** 使用 requirements-eval.md（按"路径解析规则"查找）模板，产出 `specs/changes/ARxxx-topic/eval/eval-requirements-{n}.json`
