---
name: sdd-task-design
description: "Use when srs.md exists and design.md needs to be created or modified - read component context and srs.md, produce or update design.md for the AR following department template"
---

# SDD AR 详细设计 — 生成或修改 design.md

基于已批准的 srs.md 和组件领域知识，生成或修改符合部门规范的 AR 详细设计文档（design.md）。

**两种入口模式：**
- **首次设计**（design.md 不存在）：从头生成 design.md
- **返工修改**（design.md 已存在，开发中途发现设计问题）：在现有 design.md 基础上定向修改

<HARD-GATE>
在 design.md 未生成/修改并得到用户确认之前，不得调用开发 skill，不得编写任何代码。
</HARD-GATE>

## Checklist

### 首次设计模式（design.md 不存在）

你必须为以下每个步骤创建 TodoWrite 任务，并按顺序完成：

1. **重建领域知识** — 读取组件详设、srs.md、现有代码接口
2. **分析设计输入** — 从 srs.md 提取设计驱动因素
3. **提案设计方案** — 提出 2-3 种实现方案并给出推荐
4. **生成 design.md（草稿）** — 按部门模板（或默认模板）写入文件
5. **逐节设计审批** — 用户对着生成的文件逐节确认，修改直至批准
6. **更新 tasks.md** — 确认任务分解与设计一致
7. **刷新组件详细设计** — 分析 AR 对组件详设的影响，按需更新组件_spec.md
8. **阶段 Eval（Loop 模式）** — 派发子 Agent 评估 design.md 质量；不达标修正重试
9. **移交开发阶段** — 调用 `sdd-router:sdd-task-develop`

### 返工修改模式（design.md 已存在，开发中途发现问题）

> 由 `sdd-task-develop` 在遇到设计问题时发起，用户确认后触发。

1. **读取现有 design.md** — 理解当前设计的完整内容
2. **确认返工范围** — 与用户确认要修改哪些章节/接口/算法，以及修改原因
3. **定向修改设计** — 只修改受影响的章节，其余保持不变
4. **重置受影响任务** — 将 tasks.md 中因设计变更需要重做的任务状态重置为 `pending`；已完成的无关任务保持 `passing`
5. **阶段 Eval（Loop 模式）** — 派发子 Agent 评估修改后的 design.md
6. **刷新组件详细设计** — 按 Step 7 规则判断组件详设是否需要同步更新
7. **移交开发阶段** — 调用 `sdd-router:sdd-task-develop`

**终态是调用 sdd-task-develop。** 不要调用其他 skill。

---

## 路径解析规则

本 Skill 需要读取设计模板和 Eval 文件。按以下优先级查找：

| 文件类型 | 本地路径（组件工程） | 全局路径（回退） |
|---------|---------------------|-----------------|
| 部门设计模板 | `docs/templates/design-template.md` | `~/.config/opencode/docs/templates/design-template.md` |
| 默认设计模板 | `specs/templates/design-template.md` | `~/.config/opencode/specs/templates/design-template.md` |
| Eval 协议 | `lib/eval/protocol.md` | `~/.config/opencode/lib/eval/protocol.md` |
| Design Eval | `lib/eval/design-eval.md` | `~/.config/opencode/lib/eval/design-eval.md` |
| PlantUML 指南 | `lib/references/sdd-task-design/plantuml-guide.md` | `~/.config/opencode/lib/references/sdd-task-design/plantuml-guide.md` |

**查找逻辑：** 先检查本地路径是否存在，若不存在则读取全局路径。

---

## Step 1：重建领域知识

> 每个 skill 在独立的上下文中运行，必须重新读取关键文件。

### 1a. 读取组件详细设计

读取 `specs/component-detail-design/` 下的组件详设文件，重点关注与本次 AR 相关的：
- 涉及模块的接口定义
- 相关数据结构
- 现有设计约束和架构原则

### 1b. 读取 srs.md

读取 `specs/changes/ARxxx-topic/srs.md`，提取：
- 功能需求列表（带验收标准）
- 非功能需求（性能、可靠性等）
- 约束与假设
- 影响的模块范围

### 1c. 扫描相关代码

重点读取：
- `include/` 中与本 AR 相关的头文件（接口定义）
- `src/` 中涉及修改的核心源文件（了解现有实现）
- `tests/` 中现有测试（了解测试规范）

### 1d. 检查部门设计模板

按以下优先级检查并读取 design.md 模板：

1. **优先（本地）：** `docs/templates/design-template.md` — 部门定制设计模板
2. **优先（全局）：** `~/.config/opencode/docs/templates/design-template.md` — 全局部门模板
3. **次选（本地）：** `specs/templates/design-template.md` — 框架内置通用默认模板
4. **次选（全局）：** `~/.config/opencode/specs/templates/design-template.md` — 全局默认模板
5. **无模板**：按 Step 4 中的默认章节结构直接生成（不依赖外部模板文件）

查找顺序：先本地后全局，找到即停止。

---

## Step 2：分析设计输入

从读取的材料中提取以下设计驱动因素：

| 类别 | 内容 |
|------|------|
| 功能点清单 | 来自 srs.md 的功能需求 ID 和标题 |
| 性能约束 | NFR 中的量化指标 |
| 接口约束 | 已有接口不得破坏兼容性，或必须新增的接口 |
| 架构约束 | 来自组件详设的设计原则（如分层、解耦要求）|
| 技术栈约束 | AGENTS.md 或组件详设中指定的语言/库 |

如果存在未解决的设计 Open Questions（影响架构选择），通过 AskUserQuestion 在进入 Step 3 之前解决。

> **暂停点：** 用户回答完 Open Questions 后，Agent 不得直接进入 Step 3。须输出"设计输入分析摘要"（功能点清单 + 约束 + Open Questions 结论），并询问：**"以上分析是否完整？还有补充吗？"** 只有用户确认后才进入 Step 3。

---

## Step 3：提案设计方案

针对核心实现问题，提出 **2-3 种方案**，带明确的权衡分析：

```markdown
## 方案 A：[名称]
**思路：** [1-2 句说明]
**优点：** [列表]
**缺点：** [列表]
**适合场景：** [条件]
**对 NFR 的影响：** [如何满足性能/可靠性要求]

## 方案 B：[名称]
...

## 推荐：方案 [X]
**理由：** [为什么这个最符合 srs.md 的约束和 NFR]
```

**规则：** 无法满足 srs.md 中"Must"级别 NFR 的方案不得推荐。

对于简单 AR（仅修改单个函数/模块，无架构影响），可合并为单一方案描述。

通过 **AskUserQuestion** 让用户选择方案（单选，选项为各方案名称 + "其他（自行补充）"）。用户也可在对话中直接输入自定义内容，Agent 正常接受。

---

## Step 4：生成 design.md（草稿）

根据 Step 3 用户确认的方案，**不等用户逐节审批，直接生成完整草稿文件**，写入 `specs/changes/ARxxx-topic/design.md`。

> 先生成文件，让用户在渲染后的文档中对着内容审批（流程图、时序图等 PlantUML 图表可正常渲染，效果直观）。

### 如果存在部门模板

按"路径解析规则"查找设计模板（优先部门模板，次选默认模板），按模板结构填充设计内容。保留模板的章节标题结构，将设计内容替换占位文字。

### 如果无模板文件

若上述两个路径均无模板文件，按以下默认章节结构直接生成 design.md，写入 `specs/changes/ARxxx-topic/design.md`（不加外层代码块包裹）：

1. `## 1. 设计概述` — 一段话总结方案选择和核心实现思路
2. `## 2. 模块影响分析` — 受影响的文件/模块列表（表格：文件路径 | 操作 | 说明）
3. `## 3. 接口设计` — 每个新增/修改的公开接口：函数签名（代码块）+ 参数说明表格 + 返回值/异常/前后置约束
4. `## 4. 核心算法/流程设计` — 设计思路（文字）+ 伪代码（代码块）+ 流程图（PlantUML）
5. `## 5. 边界条件矩阵` — 表格：场景 | 输入条件 | 期望行为（正常/边界/异常三类）
6. `## 6. 错误处理设计` — 表格：错误类型 | 触发条件 | 处理方式 | 错误码/异常
7. `## 7. 测试设计` — 单元测试覆盖点表格 + 覆盖率目标表格
8. `## 8. 设计决策记录` — 表格：决策点 | 选择 | 原因 | 否决的替代方案

---

## Step 5：逐节设计审批

design.md 草稿生成后，请用户**在渲染后的文档中**逐节审阅，重点确认：

1. **设计概述** — 方案选择和核心思路是否符合预期
2. **模块影响分析** — 受影响文件范围是否准确
3. **接口设计** — 函数签名、参数、返回值是否合理
4. **核心算法/流程** — 流程图（PlantUML）渲染后是否清晰正确
5. **边界条件矩阵** — 异常场景覆盖是否完整
6. **错误处理设计** — 错误码和处理策略是否符合组件规范
7. **测试设计** — 测试覆盖点和覆盖率目标是否合理

**修改循环：**
- 用户提出修改意见 → Agent 直接修改 design.md 对应章节 → 用户再次确认
- 用户只是提问（"这里为什么这样设计"等） → Agent 回答后继续等待确认，**不得自动进入 Step 6**
- 重复直至用户明确批准所有节

等待用户明确批准（"确认"/"OK"/"没问题"）后继续 Step 6。

---

## Step 6：更新 tasks.md

对比设计内容与 tasks.md 中的任务分解，确认对齐：
- 每个 srs.md 功能需求对应至少一个任务
- 任务的描述与设计的实现细节一致
- 依赖关系与实现顺序匹配

如果 tasks.md 的任务分解需要调整，更新 tasks.md（可增加任务，调整描述，但不改变已有 passing 任务）。

---

## Step 7：刷新组件详细设计

> AR 的实现可能引入新接口、新数据结构或架构调整，这些变化需要同步反映到组件整体设计文档中，以保持文档与实现的一致性。

### 7a. 影响分析

对比 design.md 与 `specs/component-detail-design/` 下的组件详设文件，识别本次 AR 是否导致以下变化：

| 变化类型 | 判断依据 | 需更新组件详设？ |
|---------|---------|--------------|
| 新增对外接口 | design.md §3 有新增的公开函数/类 | **是** |
| 接口签名变更 | design.md §3 修改了已有接口的参数或返回值 | **是** |
| 新增数据结构/枚举 | design.md 引入了新的公开数据类型 | **是** |
| 模块新增或重组 | design.md §2 的模块影响分析涉及新文件或模块拆分 | **是** |
| 架构约束或原则变化 | 本 AR 建立了新的设计模式或约束 | **是** |
| 仅修改私有实现 | 无公开接口或结构变化，仅修改 .cpp 内部逻辑 | **否** |
| 仅修改测试代码 | 不涉及接口和结构 | **否** |

### 7b. 执行更新（如有变化）

若 7a 判断需要更新，**将 design.md 中已确认的设计决策同步到组件详设**：

- 在组件详设对应章节追加或修改接口描述、数据类型、模块说明
- 保持组件详设的原有结构和风格，勿重写无关内容
- 在变更处标注 AR 来源，例如：`<!-- 引入自 AR-2026-0417：add-priority-support -->`
- 若组件详设不存在对应章节，可新增章节并说明来源

**写入格式遵循组件详设现有风格**（有代码块用代码块，有表格用表格）。

### 7c. 无需更新时

若本次 AR 仅修改内部实现，向用户说明：

```
组件详细设计无需更新。
本次 AR 修改范围：[一句话描述]
不影响组件对外接口和整体架构。
```

### 7d. 用户确认

将更新内容（或"无需更新"结论）呈现给用户确认，再进入 Step 8。

---

## Step 8：阶段 Eval（Loop 模式）

> Meta-Loop 模式下，Meta-Loop 的 PHASE_LOOP 也会独立运行 Eval。本节作为质量自查，两者互补不冲突。
> Classic 模式跳过此节，直接进入 Step 9。

### 8a. 派发 Eval 子 Agent

使用子 Agent 独立上下文运行 design-eval：

```
Agent(
  description = "Design Eval: AR [{ar_id}]",
  prompt = """
你是一名 HarnessX Eval 评估专家。请按照 design-eval.md（按"路径解析规则"查找）中的评估模板，
对以下文件进行设计阶段质量评估：

- srs.md: specs/changes/{ar_dir}/srs.md
- design.md: specs/changes/{ar_dir}/design.md
- tasks.md: specs/changes/{ar_dir}/tasks.md

评估维度（详见 design-eval.md）：
1. 需求回溯完整 — design.md 覆盖 srs.md 所有功能需求
2. 接口签名完整 — 每个公开接口有完整签名（含参数类型、返回值、错误码）
3. 数据结构定义 — 新增/修改的数据结构有完整定义
4. 模板合规 — 章节结构与部门模板一致
5. 流程图正确 — PlantUML 可渲染，逻辑与设计一致

请严格按照 Eval 协议（按"路径解析规则"查找）输出 JSON 格式的评估结果。
"""
)
```

### 8b. 处理 Eval 结果

解析子 Agent 输出的 JSON，根据 `recommendation` 字段决定：

| recommendation | 行为 |
|----------------|------|
| `next` | Eval 通过 → 进入 Step 9 |
| `retry` | 读取 `fix_hint`，修正对应章节 → 回到 8a 重评 |
| `escalate` | 向用户呈现 blocking_issues + escalation → 等待用户决定 |

**重试规则**：最多 3 轮，每次针对 `blocking_issues` 做定向修改。

### 8c. 存储 Eval 结果

将 Eval JSON 写入 `specs/changes/{ar_dir}/eval/eval-design-{iteration}.json`。

---
## Step 9：移交开发阶段

design.md、tasks.md 和组件详设（如有更新）保存 + Eval 通过（Loop 模式）后：

1. 输出移交摘要：
   - AR 编号与主题
   - 选定的设计方案
   - 受影响的文件清单
   - 任务数量与开发顺序建议
   - 组件详设更新情况（已更新哪些章节 / 无需更新及原因）
   - 注意事项（特殊约束、已知风险）
   - Eval 结果（Loop 模式）：score、通过的维度、迭代轮次

2. **必须调用：** 调用 `sdd-router:sdd-task-develop` 开始代码开发

---

## 图表规范

读取 `lib/references/sdd-task-design/plantuml-guide.md`（按"路径解析规则"查找）获取完整 PlantUML 图表规范、常用语法速查和设计节对应关系。

---

## 扩展指南

| AR 规模 | 功能点数 | 设计深度 |
|---------|---------|---------|
| 小型 | 1-3 | 简洁设计，重点描述接口和算法 |
| 中型 | 4-10 | 完整各节，逐节审批 |
| 大型 | 10+ | 建议拆分 AR |

## 红旗警告

| 这种想法 | 正确做法 |
|---------|---------|
| "srs.md 很清楚了，直接写代码" | srs.md 说 WHAT，design.md 说 HOW，两者都需要 |
| "设计太细了，浪费时间" | 设计越细，开发越顺，review 越快 |
| "一种方案就够了" | 提出 2-3 种方案，让用户做知情选择 |
| "边界条件在开发时再想" | 边界条件必须在设计时明确，否则测试无依据 |
| "不需要流程图" | 有分支逻辑的功能必须有流程图 |

## 集成说明

**调用方：** sdd-router（srs.md 存在，design.md 缺失时）；sdd-task-develop（开发途中发现设计问题，用户确认后）
**链接到：** sdd-task-develop（Step 9，设计确认 + Eval 通过后）
**产出：** `specs/changes/ARxxx-topic/design.md`（更新 `tasks.md`）；如有接口/架构变化，同步更新 `specs/component-detail-design/组件_spec.md`
**读取：** `specs/component-detail-design/组件_spec.md`、`specs/changes/ARxxx-topic/srs.md`、`include/`、`src/`
**Eval（Loop 模式）：** 使用 design-eval.md（按"路径解析规则"查找）模板，产出 `eval/eval-design-{n}.json`
