#!/bin/bash
# HarnessX Framework — Global Install Script
# Installs SDD framework to ~/.config/opencode/ for global availability across all projects
#
# Usage:
#   bash deploy.sh              # Install to default global directory
#   bash deploy.sh --user       # Install to current user's global directory (same as default)
#   bash deploy.sh --local      # Install to current directory (local mode, deprecated)
#
# After installation, restart OpenCode to load the globally installed skills/commands/agents.

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Determine global install directory
# OpenCode global config is at ~/.config/opencode/ (same as git, vim, etc.)
GLOBAL_DIR="$HOME/.config/opencode"

# Parse arguments
MODE="global"
if [ "$1" = "--local" ]; then
    MODE="local"
    TARGET_DIR="$(cd "$(dirname "$0")" && pwd)"
    echo -e "${YELLOW}⚠️  Local mode is deprecated. Use global install instead.${NC}"
elif [ "$1" = "--user" ] || [ "$1" = "" ]; then
    MODE="global"
    TARGET_DIR="$GLOBAL_DIR"
else
    echo -e "${RED}Usage: bash deploy.sh [--global|--user|--local]${NC}"
    echo "  --global / --user: Install to $GLOBAL_DIR (default)"
    echo "  --local: Install to current directory (deprecated)"
    exit 1
fi

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  HarnessX Framework — Global Install${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo ""
echo -e "Source : ${GREEN}$SOURCE_DIR${NC}"
echo -e "Target : ${GREEN}$TARGET_DIR${NC}"
echo -e "Mode   : ${GREEN}$MODE${NC}"
echo ""

# Step 1: Verify source files exist
echo -e "${YELLOW}[1/4]${NC} Verifying source files..."

ERRORS=0

# Check skills (7)
for skill in sdd-router sdd-task-requirements sdd-task-design sdd-task-develop sdd-task-review sdd-task-st sdd-meta-loop; do
    if [ ! -f "$SOURCE_DIR/skills/$skill/SKILL.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: skills/$skill/SKILL.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check commands (6)
for cmd in sdd sdd-req sdd-design sdd-dev sdd-review sdd-st; do
    if [ ! -f "$SOURCE_DIR/commands/$cmd.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: commands/$cmd.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check agents (2)
for agent in sdd-build sdd-reviewer; do
    if [ ! -f "$SOURCE_DIR/agents/$agent.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: agents/$agent.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check prompts (3)
for prompt in review-dimensions review-single-model review-multi-model; do
    if [ ! -f "$SOURCE_DIR/.opencode/prompts/$prompt.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: .opencode/prompts/$prompt.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check templates (4)
for tmpl in srs-template tasks-template design-template st-cases-template; do
    if [ ! -f "$SOURCE_DIR/specs/templates/$tmpl.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: specs/templates/$tmpl.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check references (2)
REF_COUNT=$(find "$SOURCE_DIR/lib/references" -name "*.md" 2>/dev/null | wc -l)
if [ "$REF_COUNT" -eq 0 ]; then
    echo -e "  ${RED}✗${NC} Missing: lib/references/ (no .md files)"
    ERRORS=$((ERRORS + 1))
else
    echo -e "  ${GREEN}✓${NC} References: $REF_COUNT file(s)"
fi

# Check eval (7)
for eval in protocol requirements-eval design-eval develop-eval review-eval st-eval runner; do
    if [ ! -f "$SOURCE_DIR/lib/eval/$eval.md" ]; then
        echo -e "  ${RED}✗${NC} Missing: lib/eval/$eval.md"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check plugin (1)
if [ ! -f "$SOURCE_DIR/plugins/sdd-compaction.js" ]; then
    echo -e "  ${RED}✗${NC} Missing: plugins/sdd-compaction.js"
    ERRORS=$((ERRORS + 1))
fi

if [ $ERRORS -gt 0 ]; then
    echo -e "${RED}✗${NC} $ERRORS source file(s) missing. Abort."
    exit 1
fi

echo -e "${GREEN}✓${NC} All source files verified (30+ files)"

# Step 2: Confirm
echo ""
echo -e "${YELLOW}[2/4]${NC} Confirm installation"
echo ""
echo "This will install SDD framework to:"
echo -e "  ${GREEN}$TARGET_DIR${NC}"
echo ""
echo "The following directories will be created/updated:"
echo "  $TARGET_DIR/skills/         (7 skills)"
echo "  $TARGET_DIR/commands/       (6 commands)"
echo "  $TARGET_DIR/agents/         (2 agents)"
echo "  $TARGET_DIR/prompts/        (3 prompt templates)"
echo "  $TARGET_DIR/specs/templates/  (4 doc templates)"
echo "  $TARGET_DIR/lib/eval/       (7 eval files)"
echo "  $TARGET_DIR/lib/references/ (reference files)"
echo "  $TARGET_DIR/plugins/        (1 plugin)"
echo ""

read -p "Proceed with installation? (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
    echo -e "${YELLOW}Installation cancelled.${NC}"
    exit 0
fi

# Step 3: Install
echo ""
echo -e "${YELLOW}[3/4]${NC} Installing..."

# Create target directories
mkdir -p "$TARGET_DIR/skills"
mkdir -p "$TARGET_DIR/commands"
mkdir -p "$TARGET_DIR/agents"
mkdir -p "$TARGET_DIR/prompts"
mkdir -p "$TARGET_DIR/specs/templates"
mkdir -p "$TARGET_DIR/lib/eval"
mkdir -p "$TARGET_DIR/plugins"
mkdir -p "$TARGET_DIR/docs/templates"  # Department design template

# Install skills (7)
echo "  Installing skills..."
for skill in sdd-router sdd-task-requirements sdd-task-design sdd-task-develop sdd-task-review sdd-task-st sdd-meta-loop; do
    mkdir -p "$TARGET_DIR/skills/$skill"
    cp "$SOURCE_DIR/skills/$skill/SKILL.md" "$TARGET_DIR/skills/$skill/SKILL.md"
    # Copy evals if exists
    if [ -d "$SOURCE_DIR/skills/$skill/evals" ]; then
        mkdir -p "$TARGET_DIR/skills/$skill/evals"
        cp "$SOURCE_DIR/skills/$skill/evals/"* "$TARGET_DIR/skills/$skill/evals/" 2>/dev/null || true
    fi
    echo -e "    ${GREEN}✓${NC} $skill"
done

# Install commands (6)
echo "  Installing commands..."
for cmd in sdd sdd-req sdd-design sdd-dev sdd-review sdd-st; do
    cp "$SOURCE_DIR/commands/$cmd.md" "$TARGET_DIR/commands/$cmd.md"
    echo -e "    ${GREEN}✓${NC} $cmd"
done

# Install agents (2)
echo "  Installing agents..."
for agent in sdd-build sdd-reviewer; do
    cp "$SOURCE_DIR/agents/$agent.md" "$TARGET_DIR/agents/$agent.md"
    echo -e "    ${GREEN}✓${NC} $agent"
done

# Install prompts (3)
echo "  Installing prompts..."
for prompt in review-dimensions review-single-model review-multi-model; do
    cp "$SOURCE_DIR/.opencode/prompts/$prompt.md" "$TARGET_DIR/prompts/$prompt.md"
    echo -e "    ${GREEN}✓${NC} $prompt"
done

# Install templates (4 + 1 department)
echo "  Installing templates..."
for tmpl in srs-template tasks-template design-template st-cases-template; do
    cp "$SOURCE_DIR/specs/templates/$tmpl.md" "$TARGET_DIR/specs/templates/$tmpl.md"
    echo -e "    ${GREEN}✓${NC} $tmpl"
done
# Install department design template if exists
if [ -f "$SOURCE_DIR/docs/templates/design-template.md" ]; then
    cp "$SOURCE_DIR/docs/templates/design-template.md" "$TARGET_DIR/docs/templates/design-template.md"
    echo -e "    ${GREEN}✓${NC} department design-template (docs/templates/)"
fi

# Install eval (7)
echo "  Installing eval..."
for eval in protocol requirements-eval design-eval develop-eval review-eval st-eval runner; do
    cp "$SOURCE_DIR/lib/eval/$eval.md" "$TARGET_DIR/lib/eval/$eval.md"
    echo -e "    ${GREEN}✓${NC} $eval"
done

# Install references
echo "  Installing references..."
mkdir -p "$TARGET_DIR/lib/references"
cp -r "$SOURCE_DIR/lib/references/"* "$TARGET_DIR/lib/references/" 2>/dev/null && echo -e "    ${GREEN}✓${NC} references/" || echo -e "    ${YELLOW}⚠${NC} No references to install"

# Install plugin (1)
echo "  Installing plugins..."
cp "$SOURCE_DIR/plugins/sdd-compaction.js" "$TARGET_DIR/plugins/sdd-compaction.js"
echo -e "    ${GREEN}✓${NC} sdd-compaction.js"

echo ""
echo -e "${GREEN}✓${NC} Installation complete!"

# Step 4: Verify
echo ""
echo -e "${YELLOW}[4/4]${NC} Verifying..."

VERIFY_ERRORS=0

# Verify skills
for skill in sdd-router sdd-task-requirements sdd-task-design sdd-task-develop sdd-task-review sdd-task-st sdd-meta-loop; do
    if [ ! -f "$TARGET_DIR/skills/$skill/SKILL.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: skills/$skill/SKILL.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify commands
for cmd in sdd sdd-req sdd-design sdd-dev sdd-review sdd-st; do
    if [ ! -f "$TARGET_DIR/commands/$cmd.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: commands/$cmd.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify agents
for agent in sdd-build sdd-reviewer; do
    if [ ! -f "$TARGET_DIR/agents/$agent.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: agents/$agent.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify prompts
for prompt in review-dimensions review-single-model review-multi-model; do
    if [ ! -f "$TARGET_DIR/prompts/$prompt.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: prompts/$prompt.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify templates
for tmpl in srs-template tasks-template design-template st-cases-template; do
    if [ ! -f "$TARGET_DIR/specs/templates/$tmpl.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: specs/templates/$tmpl.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify eval
for eval in protocol requirements-eval design-eval develop-eval review-eval st-eval runner; do
    if [ ! -f "$TARGET_DIR/lib/eval/$eval.md" ]; then
        echo -e "  ${RED}✗${NC} Verify failed: lib/eval/$eval.md"
        VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
    fi
done

# Verify plugin
if [ ! -f "$TARGET_DIR/plugins/sdd-compaction.js" ]; then
    echo -e "  ${RED}✗${NC} Verify failed: plugins/sdd-compaction.js"
    VERIFY_ERRORS=$((VERIFY_ERRORS + 1))
fi

# Verify references
REF_COUNT=$(find "$TARGET_DIR/lib/references" -name "*.md" 2>/dev/null | wc -l)
if [ "$REF_COUNT" -eq 0 ]; then
    echo -e "  ${YELLOW}⚠${NC} Verify warning: lib/references/ has no .md files"
else
    echo -e "  ${GREEN}✓${NC} References: $REF_COUNT file(s)"
fi

if [ $VERIFY_ERRORS -gt 0 ]; then
    echo -e "${RED}✗${NC} $VERIFY_ERRORS file(s) failed to install. Please check."
    exit 1
fi

echo -e "${GREEN}✓${NC} All files verified (30+ files)"

# Done
echo ""
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}  ✅ HarnessX Framework installed successfully!${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo ""
echo "Next steps:"
echo ""
echo -e "  1. ${BLUE}Restart OpenCode${NC} to load the globally installed skills"
echo -e "     ${YELLOW}opencode run${NC}"
echo ""
echo -e "  2. ${BLUE}In any component project${NC}, run:"
echo -e "     ${YELLOW}/sdd${NC}"
echo ""
echo -e "  3. ${BLUE}To customize department template${NC}, create:"
echo -e "     ${YELLOW}~/.config/opencode/docs/templates/design-template.md${NC}"
echo ""
echo -e "  ${GREEN}Global install directory:${NC} $TARGET_DIR"
echo ""
